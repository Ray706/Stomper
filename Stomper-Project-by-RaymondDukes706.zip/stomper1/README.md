# Stomper — No-Build Preact Port

A faithful JavaScript port of the Godot platformer **Stomper** by Ansimuz.
Runs entirely in the browser via Preact + Canvas 2D, with **no build step** —
just open the `index.html` through any static server.

## Quick Start

```bash
# From this directory:
node serve.js            # serves on http://localhost:8080
# or specify a port:
node serve.js 3000

# Then open the URL in any modern browser.
```

> A static server is required because ES modules + `fetch()` for audio don't
> work from `file://` in most browsers. The included `serve.js` is a zero-
> dependency Node.js static server.

Alternatively, any static server works:
```bash
python3 -m http.server 8080
php -S localhost:8080
```

## Mobile / Touch Devices

Open the URL on your phone (same Wi-Fi as the host machine). The game uses
`viewport-fit=cover` and respects iOS safe areas. Touch controls appear
automatically:

- **Left side:** D-pad (left/right)
- **Right side:** Jump (large), Duck/Stomp (small)
- **Top-right:** Reload button

Audio unlocks on first tap (required by iOS Safari).

## Controls

| Action | Keyboard | Touch / Mouse |
|---|---|---|
| Move left / right | ← → / A D | Left / right D-pad buttons |
| Jump | Space / Enter | Jump button (or tap canvas) |
| Duck | ↓ / S | Duck button |
| Stomp (in air) | ↓ / S (just pressed) | Duck button |
| Dash | Double-tap ← / → | Double-tap D-pad |
| Blast | Hold Duck + Jump | Hold Duck → tap Jump |
| Wall jump | Jump while on wall | Jump button near wall |
| Reload level | R | Reload button |
| Mute | M | Mute button (top-right) |
| Back / cancel | Esc | Tap outside menu |

## Cross-Platform Compatibility

| OS | Browser | Status |
|---|---|---|
| iOS 16.4+ | Safari | ✅ |
| iOS 16.4+ | Chrome / Edge (iOS) | ✅ |
| Android | Chrome | ✅ |
| Android | Firefox | ✅ |
| Linux | Firefox | ✅ |
| Linux | Chrome / Chromium | ✅ |
| macOS | Safari 16.4+ | ✅ |
| macOS | Chrome / Firefox / Edge | ✅ |
| Windows | Edge / Chrome / Firefox | ✅ |

Requirements: a browser supporting **ES modules + import maps**
(Chrome 89+, Firefox 108+, Safari 16.4+, Edge 89+). For older Safari, audio
may fall back from WebAudio OGG decoding to HTMLAudioElement clones.

## Architecture

```
index.html                # Entry: import map (Preact from esm.sh) + module script
serve.js                  # Zero-dep Node static server
src/
├── main.js               # Mounts <App/> into #app
├── App.js                # Screen routing (title/about/playing/win)
├── components/           # Preact UI components
│   ├── TouchControls.js  # Mobile-first D-pad + action buttons (touch+mouse)
│   ├── HUD.js            # Gems meter, time, level
│   ├── StartScreen.js
│   ├── AboutScreen.js
│   ├── GameOverScreen.js
│   └── FadeOverlay.js
└── game/                 # Game engine (no Preact dependency)
    ├── engine.js         # Fixed-timestep game loop, world lifecycle
    ├── world.js          # Level loader + entity registry + draw
    ├── player.js         # Player + 10-state machine (Idle/Run/Air/Duck/Dash/
    │                     #                     Stomp/WallJump/Blast/Hurt/Win)
    ├── enemies.js        # WalkingEnemy, FlyingEnemy
    ├── objects.js        # Gem, Crate, Door, Spikes, SpikesBlock,
    │                     # ShootingBlock, SlipperyBlock, Star, Box, Shoot, Brick
    ├── effects.js        # Dust / trace particle system
    ├── physics.js        # AABB tile collision with slide + one-way platforms
    ├── camera.js         # Camera2D with screen-shake
    ├── input.js          # Unified keyboard + touch + mouse input manager
    ├── audio.js          # WebAudio (BGM + 8 SFX) with HTMLAudio fallback
    ├── sprites.js        # Image cache + Animator
    ├── events.js         # Signal bus (ports Godot's Events autoload)
    ├── constants.js      # All physics/tuning constants ported from GDScript
    └── levels-data.js    # 15 levels parsed from original .tscn files
assets/
├── audio/                # musicbox.ogg + 8 fx/*.wav
└── sprites/              # All PNGs (player, enemies, tiles, effects, etc.)
```

## Original Source

This port is based on the original **Stomper** Godot 3 project by Ansimuz
(public domain / CC0). Title art by Somepixel. All assets, audio, music, and
level layouts are preserved 1:1 from the original game.
