// TouchControls.js — Mobile-first on-screen controls.

import { h } from 'preact';
import { useRef, useEffect } from 'preact/hooks';
import { input } from '../game/input.js';

export function TouchControls({ inputMethod = 'auto' }) {
  const isTouchDevice = typeof window !== 'undefined' &&
    (window.matchMedia?.('(pointer: coarse)').matches || 'ontouchstart' in window);
  const visible = isTouchDevice || inputMethod === 'touch' || inputMethod === 'auto';
  if (!visible) return null;

  const bindBtn = (name) => ({
    onTouchStart: (e) => { e.preventDefault(); e.stopPropagation(); input.setVirtualButton(name, true); },
    onTouchEnd:   (e) => { e.preventDefault(); e.stopPropagation(); input.setVirtualButton(name, false); },
    onTouchCancel:(e) => { e.preventDefault(); e.stopPropagation(); input.setVirtualButton(name, false); },
    onMouseDown:  (e) => { e.preventDefault(); e.stopPropagation(); input.setVirtualButton(name, true); },
    onMouseUp:    (e) => { e.preventDefault(); e.stopPropagation(); input.setVirtualButton(name, false); },
    onMouseLeave: (e) => { input.setVirtualButton(name, false); },
  });

  const bindPulse = (name) => ({
    onTouchStart: (e) => { e.preventDefault(); e.stopPropagation(); input.pulseVirtual(name); },
    onMouseDown:  (e) => { e.preventDefault(); e.stopPropagation(); input.pulseVirtual(name); },
  });

  return (
    h('div', { class: 'touch-controls', 'aria-hidden': true },
      h('div', { class: 'dpad' },
        h('button', {
          ...bindBtn('left'),
          class: 'ctrl-btn ctrl-left',
          'aria-label': 'Move left',
        }, h('svg', { viewBox: '0 0 24 24', width: 32, height: 32 }, h('path', { d: 'M14 6l-6 6 6 6V6z', fill: 'currentColor' }))),
        h('button', {
          ...bindBtn('right'),
          class: 'ctrl-btn ctrl-right',
          'aria-label': 'Move right',
        }, h('svg', { viewBox: '0 0 24 24', width: 32, height: 32 }, h('path', { d: 'M10 6l6 6-6 6V6z', fill: 'currentColor' }))),
      ),
      h('div', { class: 'actions' },
        h('button', {
          ...bindBtn('jump'),
          class: 'ctrl-btn ctrl-jump',
          'aria-label': 'Jump',
        }, 'JUMP'),
        h('button', {
          ...bindBtn('down'),
          class: 'ctrl-btn ctrl-duck',
          'aria-label': 'Duck / Stomp',
        }, h('svg', { viewBox: '0 0 24 24', width: 24, height: 24 }, h('path', { d: 'M6 10l6 6 6-6H6z', fill: 'currentColor' }))),
      ),
      h('div', { class: 'util-buttons' },
        h('button', {
          ...bindPulse('reload'),
          class: 'util-btn',
          'aria-label': 'Reload level',
          title: 'Reload (R)',
        }, h('svg', { viewBox: '0 0 24 24', width: 20, height: 20 }, h('path', { d: 'M17.65 6.35A7.96 7.96 0 0012 4a8 8 0 108 8h-2a6 6 0 11-6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z', fill: 'currentColor' }))),
      ),
      h('style', null, `
        .touch-controls {
          position: absolute; inset: 0;
          pointer-events: none;
          z-index: 10;
          user-select: none; -webkit-user-select: none;
        }
        .dpad, .actions, .util-buttons {
          position: absolute;
          pointer-events: none;
        }
        .dpad { left: 12px; bottom: 16px; display: flex; gap: 8px; }
        .actions { right: 12px; bottom: 16px; display: flex; flex-direction: column; gap: 8px; align-items: flex-end; }
        .util-buttons { left: 50%; transform: translateX(-50%); top: 12px; display: flex; gap: 6px; }
        .ctrl-btn, .util-btn {
          pointer-events: auto;
          -webkit-tap-highlight-color: transparent;
          -webkit-touch-callout: none;
          user-select: none;
          background: rgba(0,0,0,0.55);
          color: rgba(255,255,255,0.85);
          border: 2px solid rgba(255,255,255,0.25);
          border-radius: 14px;
          font-family: 'Pixel', 'Courier New', monospace;
          font-size: 10px; font-weight: bold; letter-spacing: 1px;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          backdrop-filter: blur(4px);
          -webkit-backdrop-filter: blur(4px);
          transition: transform 0.05s ease, background 0.05s ease;
        }
        .ctrl-btn:active, .util-btn:active {
          background: rgba(255,255,255,0.35);
          transform: scale(0.94);
        }
        .ctrl-left, .ctrl-right { width: 64px; height: 64px; }
        .ctrl-jump {
          width: 84px; height: 84px;
          font-size: 12px;
          background: rgba(40,80,160,0.55);
          border-color: rgba(120,180,255,0.5);
        }
        .ctrl-jump:active { background: rgba(80,140,240,0.75); }
        .ctrl-duck {
          width: 56px; height: 56px;
          background: rgba(80,40,80,0.55);
          border-color: rgba(200,120,200,0.4);
        }
        .ctrl-duck:active { background: rgba(160,80,160,0.75); }
        .util-btn { width: 36px; height: 36px; background: rgba(0,0,0,0.6); }
        @media (pointer: fine) {
          .touch-controls { opacity: 0.4; }
          .touch-controls:hover { opacity: 1; }
        }
        @supports (padding: env(safe-area-inset-bottom)) {
          .dpad, .actions { bottom: calc(16px + env(safe-area-inset-bottom)); }
          .util-buttons { top: calc(12px + env(safe-area-inset-top)); }
        }
      `)
    )
  );
}
