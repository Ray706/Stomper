// AboutScreen.js — Credits screen.

import { h } from 'preact';
import { useEffect } from 'preact/hooks';

export function AboutScreen({ onBack }) {
  useEffect(() => {
    const onKey = (e) => {
      if (e.code === 'Space' || e.code === 'Enter' || e.code === 'Escape' || e.code === 'NumpadEnter') {
        e.preventDefault();
        onBack();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    h('div', { class: 'about-screen', onClick: onBack },
      h('h1', null, 'STOMPER'),
      h('p', { class: 'tagline' }, 'A pixel-art platformer'),
      h('div', { class: 'credit-block' },
        h('h2', null, 'ORIGINAL GAME'),
        h('p', null, 'Design & code: Ansimuz'),
        h('p', null, 'Title art: Somepixel'),
        h('p', null, 'Engine: Godot 3'),
      ),
      h('div', { class: 'credit-block' },
        h('h2', null, 'PREACT PORT'),
        h('p', null, 'No-build Preact + Canvas 2D'),
        h('p', null, 'Cross-platform: iOS, Linux, Mac, Windows'),
        h('p', null, 'Cross-browser: Safari, Chrome, Chromium, Firefox, Edge'),
      ),
      h('div', { class: 'credit-block' },
        h('h2', null, 'CONTROLS'),
        h('p', null, 'Arrows / WASD — Move'),
        h('p', null, 'Space / Enter — Jump'),
        h('p', null, 'Down — Duck / Stomp (in air)'),
        h('p', null, 'Double-tap Left/Right — Dash'),
        h('p', null, 'Hold Down + Jump — Blast'),
        h('p', null, 'R — Reload level  •  Esc — Back'),
      ),
      h('div', { class: 'license' },
        h('p', null, 'Released under public domain (CC0).'),
        h('p', null, 'See public-license.txt in asset pack.'),
      ),
      h('button', { class: 'back-btn', onClick: onBack }, 'BACK TO MENU'),
      h('style', null, `
        .about-screen {
          position: absolute; inset: 0;
          background: #0a0c1c;
          color: #fff;
          font-family: 'Pixel', 'Courier New', monospace;
          display: flex; flex-direction: column;
          align-items: center; justify-content: flex-start;
          gap: 8px; padding: 24px 16px;
          overflow-y: auto;
          cursor: pointer;
        }
        h1 { font-size: 28px; color: #ffcc00; text-shadow: 2px 2px 0 #000; margin: 8px 0; }
        .tagline { color: #888; font-size: 10px; margin-bottom: 16px; }
        .credit-block {
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,204,0,0.2);
          padding: 12px 20px;
          border-radius: 8px;
          max-width: 480px; width: 100%;
          text-align: center;
          margin-bottom: 8px;
        }
        .credit-block h2 { color: #ffcc00; font-size: 12px; margin-bottom: 8px; letter-spacing: 2px; }
        .credit-block p { color: #ccc; font-size: 10px; margin: 4px 0; }
        .license { font-size: 8px; color: #556; margin-top: 12px; text-align: center; }
        .back-btn {
          margin-top: 16px;
          padding: 8px 24px;
          background: rgba(255,204,0,0.2);
          color: #ffcc00;
          border: 2px solid #ffcc00;
          border-radius: 6px;
          font-family: 'Pixel', 'Courier New', monospace;
          font-size: 12px;
          cursor: pointer;
        }
        .back-btn:active { background: rgba(255,204,0,0.4); }
      `)
    )
  );
}
