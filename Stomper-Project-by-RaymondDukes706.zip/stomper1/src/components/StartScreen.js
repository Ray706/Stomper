// StartScreen.js — Title screen.

import { h } from 'preact';
import { useState, useEffect, useRef } from 'preact/hooks';

export function StartScreen({ onStart, onAbout }) {
  const [selected, setSelected] = useState(0);
  const selectedRef = useRef(0);
  selectedRef.current = selected;

  useEffect(() => {
    const onKey = (e) => {
      if (e.code === 'ArrowUp' || e.code === 'KeyW') { setSelected(0); e.preventDefault(); }
      else if (e.code === 'ArrowDown' || e.code === 'KeyS') { setSelected(1); e.preventDefault(); }
      else if (e.code === 'Space' || e.code === 'Enter' || e.code === 'NumpadEnter') {
        e.preventDefault();
        if (selectedRef.current === 0) onStart();
        else onAbout();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const choose = (index, action) => {
    setSelected(index);
    setTimeout(action, 100);
  };
  const bindOption = (index, action) => ({
    onTouchEnd: (e) => { e.preventDefault(); e.stopPropagation(); choose(index, action); },
    onMouseDown: (e) => { e.stopPropagation(); setSelected(index); },
    onClick: (e) => { e.stopPropagation(); choose(index, action); },
  });
  const bindScreen = {
    onTouchEnd: (e) => { e.preventDefault(); choose(selectedRef.current, selectedRef.current === 0 ? onStart : onAbout); },
  };

  return (
    h('div', { class: 'start-screen', onClick: () => selectedRef.current === 0 ? onStart() : onAbout(), ...bindScreen },
      h('div', { class: 'logo-container' },
        h('img', {
          src: './assets/sprites/levels/title.png',
          class: 'logo',
          alt: 'Stomper',
          draggable: false,
        }),
      ),
      h('div', { class: 'menu' },
        h('div', {
          class: 'menu-item' + (selected === 0 ? ' selected' : ''),
          ...bindOption(0, onStart),
        },
          h('span', { class: 'pointer' + (selected === 0 ? ' visible' : '') }, '◆'),
          h('span', null, 'NEW GAME'),
        ),
        h('div', {
          class: 'menu-item' + (selected === 1 ? ' selected' : ''),
          ...bindOption(1, onAbout),
        },
          h('span', { class: 'pointer' + (selected === 1 ? ' visible' : '') }, '◆'),
          h('span', null, 'ABOUT'),
        ),
      ),
      h('div', { class: 'credits' },
        h('div', null, 'A SHORT GAME BY ANSIMUZ'),
        h('div', null, 'TITLE BY SOMEPIXEL'),
        h('div', { class: 'port-credit' }, 'Preact port • keyboard / touch / mouse'),
      ),
      h('div', { class: 'controls-hint' },
        h('div', null, 'ARROWS / WASD: MOVE  •  SPACE: JUMP  •  DOWN: DUCK/STOMP'),
        h('div', null, 'DOUBLE-TAP LEFT/RIGHT: DASH  •  HOLD DOWN + JUMP: BLAST'),
        h('div', null, 'R: RELOAD LEVEL  •  M: MUTE'),
      ),
      h('style', null, `
        .start-screen {
          position: absolute; inset: 0;
          background: linear-gradient(180deg, #1a1c2c 0%, #0a0c1c 100%);
          display: flex; flex-direction: column;
          align-items: center; justify-content: center;
          gap: 16px; padding: 16px;
          font-family: 'Pixel', 'Courier New', monospace;
          color: #fff;
          cursor: pointer;
          overflow-y: auto;
        }
        .logo-container { margin-top: 20px; }
        .logo {
          max-width: min(80vw, 320px);
          image-rendering: pixelated;
          image-rendering: -moz-crisp-edges;
          image-rendering: crisp-edges;
          filter: drop-shadow(2px 2px 0 #000);
          animation: logo-drop 0.6s ease-out;
        }
        @keyframes logo-drop {
          0% { transform: translateY(-40px); opacity: 0; }
          100% { transform: translateY(0); opacity: 1; }
        }
        .menu { display: flex; flex-direction: column; gap: 8px; margin-top: 20px; }
        .menu-item {
          display: flex; align-items: center; gap: 12px;
          padding: 8px 24px;
          color: #ffcc00;
          font-size: 14px;
          cursor: pointer;
          transition: color 0.1s;
        }
        .menu-item.selected { color: #fff; }
        .pointer { width: 12px; color: #ff6644; opacity: 0; transition: opacity 0.1s; }
        .pointer.visible { opacity: 1; }
        .credits {
          position: absolute; bottom: 12px; left: 12px;
          font-size: 8px; color: #888;
          text-align: left;
        }
        .credits .port-credit { color: #556; margin-top: 4px; }
        .controls-hint {
          position: absolute; bottom: 12px; right: 12px;
          font-size: 8px; color: #556;
          text-align: right;
          max-width: 50%;
        }
        @media (max-width: 480px) {
          .credits, .controls-hint {
            position: static; text-align: center; max-width: 100%;
            margin-top: 8px;
          }
          .controls-hint { font-size: 7px; }
        }
      `)
    )
  );
}
