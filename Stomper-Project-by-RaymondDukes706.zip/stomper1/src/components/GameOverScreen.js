// GameOverScreen.js — Final win screen.

import { h } from 'preact';
import { useEffect } from 'preact/hooks';

export function GameOverScreen({ time, stars, onRestart }) {
  const mins = Math.floor(time / 60);
  const secs = Math.floor(time % 60);
  const timeStr = `${mins.toString().padStart(2,'0')}:${secs.toString().padStart(2,'0')}`;

  useEffect(() => {
    const onKey = (e) => {
      if (e.code === 'Space' || e.code === 'Enter' || e.code === 'Escape' || e.code === 'NumpadEnter') {
        e.preventDefault();
        onRestart();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    h('div', { class: 'game-over-screen', onClick: onRestart },
      h('h1', null, 'THANKS FOR'),
      h('h1', null, 'PLAYING!'),
      h('div', { class: 'stats' },
        h('div', { class: 'stat-row' },
          h('span', { class: 'stat-label' }, 'TIME TO COMPLETE:'),
          h('span', { class: 'stat-value' }, timeStr),
        ),
        h('div', { class: 'stat-row' },
          h('span', { class: 'stat-label' }, 'ZAPHIRES:'),
          h('span', { class: 'stat-value' }, 'x ' + stars),
        ),
      ),
      h('p', { class: 'thanks' },
        'You\'ve reached the end of Stomper. We hope you enjoyed the journey ',
        'through all 15 levels — from the first jump to the final stomp.'
      ),
      h('button', { class: 'restart-btn', onClick: onRestart }, 'PLAY AGAIN'),
      h('style', null, `
        .game-over-screen {
          position: absolute; inset: 0;
          background: linear-gradient(180deg, #1a1c2c 0%, #2a1c0c 100%);
          color: #fff;
          font-family: 'Pixel', 'Courier New', monospace;
          display: flex; flex-direction: column;
          align-items: center; justify-content: center;
          gap: 8px; padding: 24px;
          overflow-y: auto;
          cursor: pointer;
        }
        h1 {
          font-size: clamp(24px, 8vw, 48px);
          color: #ffcc00;
          text-shadow: 3px 3px 0 #000;
          margin: 4px 0;
          text-align: center;
        }
        .stats {
          margin: 24px 0;
          display: flex; flex-direction: column; gap: 8px;
          background: rgba(0,0,0,0.4);
          padding: 16px 32px;
          border-radius: 8px;
          border: 1px solid rgba(255,204,0,0.3);
        }
        .stat-row { display: flex; gap: 12px; justify-content: space-between; align-items: center; }
        .stat-label { color: #888; font-size: 10px; }
        .stat-value { color: #ffcc00; font-size: 14px; }
        .thanks {
          color: #ccc; font-size: 10px; max-width: 480px;
          text-align: center; line-height: 1.5; margin: 8px 0;
        }
        .restart-btn {
          margin-top: 16px;
          padding: 10px 32px;
          background: rgba(255,204,0,0.2);
          color: #ffcc00;
          border: 2px solid #ffcc00;
          border-radius: 6px;
          font-family: 'Pixel', 'Courier New', monospace;
          font-size: 12px;
          cursor: pointer;
        }
        .restart-btn:active { background: rgba(255,204,0,0.4); transform: scale(0.98); }
      `)
    )
  );
}
