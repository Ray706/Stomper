// HUD.js — Heads-up display overlay.

import { h } from 'preact';

export function HUD({ gems_collected, gems_required, time, level, state, muted, onToggleMute }) {
  const filled = Math.min(gems_collected, gems_required);
  const slots = [];
  for (let i = 0; i < gems_required; i++) slots.push(i < filled ? 'filled' : 'empty');
  const mins = Math.floor(time / 60);
  const secs = Math.floor(time % 60);
  const timeStr = `${mins.toString().padStart(2,'0')}:${secs.toString().padStart(2,'0')}`;

  return (
    h('div', { class: 'hud' },
      h('div', { class: 'hud-left' },
        h('div', { class: 'hud-row' },
          h('span', { class: 'hud-label' }, 'GEMS'),
          h('div', { class: 'gem-meter' },
            slots.map((s, i) => h('div', { class: 'gem-slot gem-' + s, key: i }))
          ),
        ),
        h('div', { class: 'hud-row' },
          h('span', { class: 'hud-label' }, 'TIME'),
          h('span', { class: 'hud-value' }, timeStr),
        ),
      ),
      h('div', { class: 'hud-right' },
        h('div', { class: 'hud-level' }, 'L' + level),
        h('button', {
          class: 'hud-mute-btn',
          onClick: onToggleMute,
          'aria-label': 'Mute / unmute',
          title: 'Mute (M)',
        }, muted ? '🔇' : '🔊'),
      ),
      h('style', null, `
        .hud {
          position: absolute; top: 0; left: 0; right: 0;
          padding: 8px 12px;
          display: flex; justify-content: space-between; align-items: flex-start;
          pointer-events: none;
          font-family: 'Pixel', 'Courier New', monospace;
          color: #fff;
          text-shadow: 1px 1px 0 #000, -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000;
          z-index: 5; font-size: 10px;
        }
        .hud-left, .hud-right { display: flex; flex-direction: column; gap: 4px; }
        .hud-right { align-items: flex-end; }
        .hud-row { display: flex; align-items: center; gap: 6px; }
        .hud-label { color: #ffcc00; font-size: 10px; }
        .hud-value { color: #fff; }
        .gem-meter { display: flex; gap: 1px; min-height: 10px; }
        .gem-slot {
          width: 10px; height: 10px;
          image-rendering: pixelated;
          background-size: contain; background-repeat: no-repeat; background-position: center;
        }
        .gem-filled { background-image: url('./assets/sprites/gems/gem-taken.png'); }
        .gem-empty { background-image: url('./assets/sprites/gems/gem-empty.png'); opacity: 0.55; }
        .hud-level {
          background: rgba(0,0,0,0.5);
          padding: 2px 8px;
          border-radius: 6px;
          color: #ffcc00;
          font-size: 11px;
        }
        .hud-mute-btn {
          pointer-events: auto;
          background: rgba(0,0,0,0.5);
          border: 1px solid rgba(255,255,255,0.3);
          color: #fff;
          width: 28px; height: 28px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          padding: 0;
          display: flex; align-items: center; justify-content: center;
        }
        .hud-mute-btn:active { background: rgba(255,255,255,0.2); }
        @supports (padding: env(safe-area-inset-top)) {
          .hud { padding-top: calc(8px + env(safe-area-inset-top)); }
        }
      `)
    )
  );
}
