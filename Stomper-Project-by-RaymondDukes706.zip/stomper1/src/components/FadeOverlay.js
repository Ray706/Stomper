// FadeOverlay.js — Full-screen black fade for scene transitions.

import { h } from 'preact';

export function FadeOverlay({ alpha = 0 }) {
  if (alpha <= 0) return null;
  return (
    h('div', {
      class: 'fade-overlay',
      style: { opacity: alpha },
    },
      h('style', null, `
        .fade-overlay {
          position: absolute; inset: 0;
          background: #000;
          pointer-events: none;
          z-index: 100;
          transition: opacity 0.05s linear;
        }
      `)
    )
  );
}
