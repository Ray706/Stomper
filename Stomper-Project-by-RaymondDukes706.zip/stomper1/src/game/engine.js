// engine.js — Game loop with fixed-timestep physics.

import { FIXED_DT, VIEW_W, VIEW_H, LAST_GAMEPLAY_LEVEL } from './constants.js';
import { World } from './world.js';
import { camera } from './camera.js';
import { bus, SIGNALS } from './events.js';
import { audio } from './audio.js';
import { input } from './input.js';
import { preloadAllSprites } from './sprites.js';

class Engine {
  constructor() {
    this.canvas = null;
    this.ctx = null;
    this.world = null;
    this.running = false;
    this.rafId = 0;
    this.lastTime = 0;
    this.accumulator = 0;
    this.maxFrameDelta = 0.1;
    this.global = { current_level: 1, gems_taken: 0, MAX_GEMS: 0, time: 0, stars_taken: 0 };
    this._listeners = { frame: [] };
    this._onLevelComplete = null;
    this._onStarCollected = null;
    this._fadeState = null;
    this._fadeAlpha = 0;
    this._fadeCallback = null;
    this._bindSignals();
  }

  _bindSignals() {
    bus.on('__level_complete__', (levelNum) => { this._onLevelComplete && this._onLevelComplete(levelNum); });
    bus.on('__star_collected__', () => { this.global.stars_taken++; this._onStarCollected && this._onStarCollected(); });
  }

  on(event, cb) {
    if (event === 'frame') this._listeners.frame.push(cb);
    else if (event === 'level_complete') this._onLevelComplete = cb;
    else if (event === 'star') this._onStarCollected = cb;
  }

  async init(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.ctx.imageSmoothingEnabled = false;
    canvas.width = VIEW_W;
    canvas.height = VIEW_H;
    await audio.init();
    await preloadAllSprites();
    camera.bind();
  }

  loadLevel(levelNum) {
    if (this.world) { this.world.destroy(); if (this.world.door) this.world.door.destroy(); }
    this.global.current_level = levelNum;
    this.global.gems_taken = 0;
    this.global.time = 0;
    if (levelNum > LAST_GAMEPLAY_LEVEL) {
      this.world = null;
      return;
    }
    this.world = new World(levelNum);
    this.global.MAX_GEMS = this.world.gems_required;
    bus.emit(SIGNALS.UPDATE_UI, this.world.gems_required);
    this.global.time = 0;
  }

  reloadLevel() {
    if (this.world) this.loadLevel(this.global.current_level);
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.lastTime = performance.now();
    this.accumulator = 0;
    const loop = (t) => {
      if (!this.running) return;
      let dt = (t - this.lastTime) / 1000;
      this.lastTime = t;
      if (dt > this.maxFrameDelta) dt = this.maxFrameDelta;
      this.accumulator += dt;
      let steps = 0;
      while (this.accumulator >= FIXED_DT && steps < 5) {
        this._fixedUpdate(FIXED_DT);
        this.accumulator -= FIXED_DT;
        steps++;
      }
      this._render();
      for (const cb of this._listeners.frame) cb(this.snapshot());
      this.rafId = requestAnimationFrame(loop);
    };
    this.rafId = requestAnimationFrame(loop);
  }

  stop() {
    this.running = false;
    if (this.rafId) cancelAnimationFrame(this.rafId);
  }

  _fixedUpdate(dt) {
    if (!this.world) return;
    this.world.update(dt, input);
    this.global.time += dt;
    const mins = Math.floor(this.global.time / 60);
    const secs = Math.floor(this.global.time % 60);
    bus.emit(SIGNALS.UPDATE_TIME, `${mins.toString().padStart(2,'0')}:${secs.toString().padStart(2,'0')}`);
    if (input.reload) this.reloadLevel();
    if (input.mute) this.toggleMute();
    input.endFrame();
  }

  _render() {
    const ctx = this.ctx;
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    if (this.world) this.world.draw(ctx);
    if (this._fadeAlpha > 0) {
      ctx.fillStyle = `rgba(0,0,0,${this._fadeAlpha})`;
      ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    }
  }

  snapshot() {
    if (!this.world) {
      return {
        level: this.global.current_level, gems_collected: 0, gems_required: 0,
        time: this.global.time, state: '', stars: this.global.stars_taken, muted: audio.isMuted(),
      };
    }
    return {
      level: this.global.current_level,
      gems_collected: this.world.gems_collected,
      gems_required: this.world.gems_required,
      time: this.global.time,
      state: this.world.player ? this.world.player.current_state : '',
      stars: this.global.stars_taken,
      muted: audio.isMuted(),
    };
  }

  fadeOut(duration = 0.6, cb) {
    this._fadeState = 'out';
    this._fadeAlpha = 0;
    const start = performance.now();
    const step = () => {
      const elapsed = (performance.now() - start) / 1000;
      this._fadeAlpha = Math.min(1, elapsed / duration);
      if (this._fadeAlpha < 1) requestAnimationFrame(step);
      else { cb && cb(); this.fadeIn(duration); }
    };
    requestAnimationFrame(step);
  }

  fadeIn(duration = 0.6) {
    this._fadeState = 'in';
    this._fadeAlpha = 1;
    const start = performance.now();
    const step = () => {
      const elapsed = (performance.now() - start) / 1000;
      this._fadeAlpha = Math.max(0, 1 - elapsed / duration);
      if (this._fadeAlpha > 0) requestAnimationFrame(step);
      else this._fadeState = null;
    };
    requestAnimationFrame(step);
  }

  toggleMute() {
    return audio.toggleMute();
  }
}

export const engine = new Engine();
