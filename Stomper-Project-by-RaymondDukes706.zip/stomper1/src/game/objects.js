// objects.js — Interactive level objects.

import {
  TILE, GEM_ANIMS, DOOR_ANIMS, STAR_ANIMS, SHOOT_ANIMS,
  BOX, CRATE, VIEW_W, VIEW_H,
} from './constants.js';
import { sprites, Animator } from './sprites.js';
import { moveAndSlide, collideTilemapAt, aabbOverlap } from './physics.js';
import { bus, SIGNALS } from './events.js';
import { audio } from './audio.js';
import { States } from './player.js';

// ---------- Gem ----------
export class Gem {
  constructor(x, y, world, take_flag = false) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.motion = { x: 0, y: 0 };
    this.take_flag = take_flag;
    this.animator = new Animator(sprites, GEM_ANIMS.spin);
    this.dead = false;
    this.start_timer = 0;
    this.half_w = 4;
    this.half_h = 4;
  }
  setInitialVelocity(vx, vy) {
    this.motion.x = vx;
    this.motion.y = vy;
    this.take_flag = false;
    this.start_timer = 1.0;
  }
  get collider() {
    return { x: this.x - this.half_w, y: this.y - this.half_h, w: this.half_w * 2, h: this.half_h * 2 };
  }
  update(dt) {
    if (this.dead) return;
    if (this.start_timer > 0) {
      this.start_timer -= dt;
      if (this.start_timer <= 0) this.take_flag = true;
    }
    this.motion.y += 400 * dt;
    if (this.motion.y > 200) this.motion.y = 200;
    const box = this.collider;
    const result = moveAndSlide(box, this.motion.x * dt, this.motion.y * dt,
      this.world.tilemap, this.world.solids, {});
    this.x = box.x + box.w / 2;
    this.y = box.y + box.h / 2;
    if (result.hitX) this.motion.x = -this.motion.x * 0.5;
    if (result.hitY) this.motion.y = -this.motion.y * 0.3;
    this.motion.x *= 0.99;
    if (this.x < 0) this.x = VIEW_W;
    if (this.x > VIEW_W) this.x = 0;
    if (this.take_flag && this.world.player) {
      if (aabbOverlap(this.world.player.collider, this.collider)) this.take_gem();
    }
    this.animator.update(dt);
  }
  take_gem() {
    if (this.dead) return;
    bus.emit(SIGNALS.UPDATE_GEM, 1);
    this.world.effects.gemFeedback(this.x, this.y);
    audio.play_Pick();
    this.dead = true;
  }
  draw(ctx) {
    if (this.dead) return;
    this.animator.draw(ctx, this.x, this.y, { ox: -8, oy: -8 });
  }
}

// ---------- Crate (destructible block) ----------
export class Crate {
  constructor(x, y, world, gems_spawn = CRATE.DEFAULT_GEMS) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.gems_spawn = gems_spawn;
    this.dead = false;
    this.w = 16;
    this.h = 16;
  }
  get collider() { return { x: this.x - 8, y: this.y - 16, w: 16, h: 16 }; }
  kill() {
    if (this.dead) return;
    this.dead = true;
    const offsets = [[-4, -8], [4, -8], [-4, 4], [4, 4]];
    const rots = [-1, 1, 1, -1];
    for (let i = 0; i < offsets.length; i++) {
      const [ox, oy] = offsets[i];
      this.world.addBrick(new Brick(this.x + ox, this.y + oy, rots[i]));
    }
    if (this.gems_spawn > 0) this.world.spawnGemsPattern(this.x, this.y - 8, this.gems_spawn, 1);
  }
  update(dt) {}
  draw(ctx) {
    if (this.dead) return;
    sprites.draw(ctx, 'crates/crate.png', this.x - 8, this.y - 16);
  }
}

// ---------- Brick (crate fragment) ----------
export class Brick {
  constructor(x, y, rot) {
    this.x = x;
    this.y = y;
    this.rot = rot;
    this.angle = 0;
    this.motion = { x: rot > 0 ? 30 : -30, y: -200 };
    this.dead = false;
    this.life = 3.0;
  }
  update(dt) {
    this.life -= dt;
    if (this.life <= 0) { this.dead = true; return; }
    this.motion.y += 1200 * dt;
    this.x += this.motion.x * dt;
    this.y += this.motion.y * dt;
    this.angle += 0.2 * this.rot;
    if (this.y > VIEW_H + 100) this.dead = true;
  }
  draw(ctx) {
    ctx.save();
    ctx.translate(Math.round(this.x), Math.round(this.y));
    ctx.rotate(this.angle);
    const img = sprites.get('crates/brick.png');
    if (img && img.complete) ctx.drawImage(img, 0, 0, 10, 5, -5, -2, 10, 5);
    ctx.restore();
  }
}

// ---------- Door (level goal) ----------
export class Door {
  constructor(x, y, world) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.active = false;
    this.completed = false;
    this.animator = new Animator(sprites, DOOR_ANIMS.closed);
    this._onOpen = () => {
      this.active = true;
      this.animator = new Animator(sprites, DOOR_ANIMS.active);
    };
    bus.on(SIGNALS.OPEN_DOOR, this._onOpen);
  }
  update(dt) {
    this.animator.update(dt);
    if (this.active && !this.completed && this.world.player) {
      const pc = this.world.player.collider;
      const dc = { x: this.x - 8, y: this.y - 24, w: 16, h: 24 };
      if (aabbOverlap(pc, dc)) this.complete_level();
    }
  }
  complete_level() {
    if (this.completed) return;
    this.completed = true;
    bus.emit(SIGNALS.LEVEL_PASSED);
    setTimeout(() => { bus.emit('__level_complete__', this.world.levelNum); }, 100);
  }
  destroy() { bus.off(SIGNALS.OPEN_DOOR, this._onOpen); }
  draw(ctx) { this.animator.draw(ctx, this.x, this.y, { ox: -8, oy: -24 }); }
}

// ---------- Spikes (static) ----------
export class Spikes {
  constructor(x, y, world) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.collider = { x: x - 8, y: y - 8, w: 16, h: 8 };
    this.frame = 1;
  }
  update(dt) {
    if (this.world.player && !this.world.player.invincible_flag) {
      if (aabbOverlap(this.world.player.collider, this.collider)) {
        bus.emit(SIGNALS.HURT_PLAYER);
      }
    }
  }
  draw(ctx) {
    const img = sprites.get('spikes/spikes.png');
    if (img && img.complete && img.naturalWidth > 0) {
      const fw = img.naturalWidth / 2;
      ctx.drawImage(img, this.frame * fw, 0, fw, img.naturalHeight,
        this.x - 8, this.y - 16, fw, img.naturalHeight);
    }
  }
}

// ---------- SpikesBlock (retractable) ----------
export class SpikesBlock {
  constructor(x, y, world) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.spikes_out = false;
    this.timer = 0;
    this.cycle_duration = 2.0;
    this.collider = { x: x - 8, y: y - 4, w: 16, h: 8 };
    this.frame = 0;
  }
  update(dt) {
    this.timer += dt;
    if (this.timer > this.cycle_duration) this.timer -= this.cycle_duration;
    if (this.timer < 1.1) { this.spikes_out = false; this.frame = 0; }
    else { this.spikes_out = true; this.frame = 1; }
    if (this.spikes_out && this.world.player && !this.world.player.invincible_flag) {
      if (aabbOverlap(this.world.player.collider, this.collider)) {
        bus.emit(SIGNALS.HURT_PLAYER);
      }
    }
  }
  draw(ctx) {
    sprites.draw(ctx, 'spikes/spike-block.png', this.x - 8, this.y - 16);
    const img = sprites.get('spikes/spikes.png');
    if (img && img.complete && img.naturalWidth > 0) {
      const fw = img.naturalWidth / 2;
      ctx.drawImage(img, this.frame * fw, 0, fw, img.naturalHeight,
        this.x - 8, this.y - 16, fw, img.naturalHeight);
    }
  }
}

// ---------- ShootingBlock (cannon) ----------
export class ShootingBlock {
  constructor(x, y, world, shoot_speed = -1.5) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.shoot_speed = shoot_speed;
    this.timer = 0;
    this.cycle = 3.0;
    this.shoot_at = 1.5;
    this.shot_fired = false;
    this.facing = shoot_speed < 0 ? -1 : 1;
  }
  update(dt) {
    this.timer += dt;
    if (this.timer >= this.cycle) { this.timer = 0; this.shot_fired = false; }
    if (!this.shot_fired && this.timer >= this.shoot_at) {
      this.shot_fired = true;
      this.shoot();
    }
  }
  shoot() {
    const offsetY = 8;
    const offsetX = this.shoot_speed < 0 ? -8 : 24;
    this.world.addShoot(new Shoot(this.x + offsetX, this.y + offsetY - 16, this.world, this.shoot_speed * 60));
  }
  draw(ctx) {
    sprites.draw(ctx, 'shooting/shooting-head.png', this.x - 8, this.y - 16, { flipX: this.facing < 0 });
  }
}

// ---------- Shoot (projectile) ----------
export class Shoot {
  constructor(x, y, world, speed) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.dead = false;
    this.animator = new Animator(sprites, SHOOT_ANIMS.fly);
    this.facing = speed < 0 ? -1 : 1;
    this.collider = { x: x - 4, y: y - 4, w: 8, h: 8 };
  }
  update(dt) {
    if (this.dead) return;
    this.x += this.speed * dt;
    this.collider = { x: this.x - 4, y: this.y - 4, w: 8, h: 8 };
    if (this.x < -16 || this.x > VIEW_W + 16) { this.dead = true; return; }
    const probe = { x: this.x - 4, y: this.y - 4, w: 8, h: 8 };
    if (collideTilemapAt(this.world.tilemap, probe, [], {})) { this.kill(); return; }
    if (this.world.player) {
      if (aabbOverlap(this.world.player.collider, this.collider)) {
        if (this.world.player.current_state !== States.DUCK && !this.world.player.invincible_flag) {
          bus.emit(SIGNALS.HURT_PLAYER);
        }
        this.kill();
        return;
      }
    }
    this.animator.update(dt);
  }
  kill() {
    if (this.dead) return;
    this.dead = true;
    this.world.effects.hitFeedback(this.x, this.y);
  }
  draw(ctx) {
    if (this.dead) return;
    this.animator.draw(ctx, this.x, this.y, { flipX: this.facing < 0, ox: -4, oy: -4 });
  }
}

// ---------- SlipperyBlock ----------
export class SlipperyBlock {
  constructor(x, y, world) {
    this.world = world;
    this.x = x - 8;
    this.y = y - 16;
    this.w = 16;
    this.h = 16;
    this.slippery = true;
  }
  get collider() { return this; }
  update(dt) {}
  draw(ctx) { sprites.draw(ctx, 'slippery/slime-block.png', this.x, this.y); }
}

// ---------- Star (zaphire) ----------
export class Star {
  constructor(x, y, world) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.dead = false;
    this.animator = new Animator(sprites, STAR_ANIMS.spin);
    this.collider = { x: x - 8, y: y - 8, w: 16, h: 16 };
  }
  update(dt) {
    if (this.dead) return;
    if (this.world.player) {
      if (aabbOverlap(this.world.player.collider, this.collider)) this.kill();
    }
    this.animator.update(dt);
  }
  kill() {
    if (this.dead) return;
    this.dead = true;
    audio.play_door();
    bus.emit('__star_collected__');
  }
  draw(ctx) {
    if (this.dead) return;
    this.animator.draw(ctx, this.x, this.y, { ox: -8, oy: -8 });
  }
}

// ---------- Box (pushable) ----------
export class Box {
  constructor(x, y, world) {
    this.world = world;
    this.x = x - 8;
    this.y = y - 16;
    this.w = 16;
    this.h = 16;
    this.motion = { x: 0, y: 0 };
    this.dead = false;
  }
  get collider() { return this; }
  push(direction) { this.motion.x = direction * BOX.PUSH_SPEED; }
  update(dt) {
    this.motion.y += BOX.GRAVITY * dt;
    if (this.motion.y > 300) this.motion.y = 300;
    const box = { x: this.x, y: this.y, w: this.w, h: this.h };
    const result = moveAndSlide(box, this.motion.x * dt, this.motion.y * dt,
      this.world.tilemap, [], {});
    this.x = box.x;
    this.y = box.y;
    if (result.hitX) this.motion.x = 0;
    if (result.hitY) this.motion.y = 0;
    this.motion.x = 0;
  }
  draw(ctx) { sprites.draw(ctx, 'crates/crate.png', this.x, this.y); }
}
