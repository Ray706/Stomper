// player.js — Player entity + 10-state finite state machine.

import {
  PHYSICS, PLAYER_COLLIDER, PLAYER_ANIMS, WRAP, VIEW_W, VIEW_H,
} from './constants.js';
import { sprites, Animator } from './sprites.js';
import { moveAndSlide, collideTilemapAt } from './physics.js';
import { bus, SIGNALS } from './events.js';
import { audio } from './audio.js';
import { input as sharedInput } from './input.js';

export const States = {
  IDLE: 'Idle', RUN: 'Run', AIR: 'Air', DUCK: 'Duck',
  DASH: 'Dash', STOMP: 'Stomp', WALL_JUMP: 'WallJump',
  BLAST: 'Blast', HURT: 'Hurt', WIN: 'Win',
};

const KILL_STATES = new Set([States.STOMP, States.WALL_JUMP, States.DASH, States.BLAST]);

function lerp(a, b, t) { return a + (b - a) * t; }

export class Player {
  constructor(x, y, world) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.motion = { x: 0, y: 0 };
    this.facing = 1;
    this.is_grounded = false;
    this.is_on_slippery = false;
    this.invincible_flag = false;
    this.invincible_counter = 0;
    this.invincible_max = PHYSICS.INVINCIBLE_MAX_FRAMES;
    this.level_passed = false;
    this.current_state = States.IDLE;
    this.dash_jump_timer = 0;
    this.coyote_timer = 0;
    this.dust_walk_timer = 0;
    this.wall_dust_timer = 0;
    this.trace_timer = 0;
    this.blink_visible = true;
    this.sprite_visible = true;
    this.animator = new Animator(sprites, PLAYER_ANIMS.idle);
    this.state = null;
    this.state_ctx = {
      dash_direction: 0, dash_flag: false, dash_last_direction: 0,
      key_time: 0, duck_count: 0, blast_init_y: 0, wall_jump_x: 0, hurt_gems_dropped: 0,
    };
    this._subs = [];
    this._subs.push(bus.on(SIGNALS.HIT, () => this._on_hit()));
    this._subs.push(bus.on(SIGNALS.HURT_PLAYER, () => this._on_hurt_player()));
    this._subs.push(bus.on(SIGNALS.LEVEL_PASSED, () => this._on_level_passed()));
    this._transitionTo(States.IDLE, {});
  }

  destroy() { for (const off of this._subs) off(); this._subs.length = 0; }

  get collider() {
    return {
      x: this.x - PLAYER_COLLIDER.HALF_W,
      y: this.y - PLAYER_COLLIDER.HALF_H * 2,
      w: PLAYER_COLLIDER.HALF_W * 2,
      h: PLAYER_COLLIDER.HALF_H * 2,
    };
  }

  getSolids() { return this.world.solids; }

  get_input_vector() { return { x: sharedInput.getInputVectorX() }; }

  apply_horizontal_force(input_vector, delta) {
    const accel = this.is_grounded ? PHYSICS.ACCELERATION_GROUND : PHYSICS.ACCELERATION_AIR;
    this.motion.x += input_vector.x * accel * delta;
    const max = PHYSICS.MAX_SPEED_X;
    if (this.motion.x > max) this.motion.x = max;
    if (this.motion.x < -max) this.motion.x = -max;
  }
  apply_friction(input_vector) {
    if (this.is_on_slippery) return;
    if (input_vector.x === 0) this.motion.x = lerp(this.motion.x, 0, PHYSICS.FRICTION);
  }
  apply_gravity(delta) {
    if (this.motion.y > 0) this.motion.y += (PHYSICS.GRAVITY + 200) * delta;
    else this.motion.y += PHYSICS.GRAVITY * delta;
    const maxY = PHYSICS.MAX_SPEED_Y;
    if (this.motion.y > maxY) this.motion.y = maxY;
    if (this.motion.y < -maxY) this.motion.y = -maxY;
  }
  apply_gravity_wall(delta) {
    this.motion.y += PHYSICS.GRAVITY_WALL * delta;
    if (this.motion.y > PHYSICS.WALL_SLIDE_MAX) this.motion.y = PHYSICS.WALL_SLIDE_MAX;
    if (this.motion.y < -PHYSICS.WALL_SLIDE_MAX) this.motion.y = -PHYSICS.WALL_SLIDE_MAX;
  }
  apply_jump_friction() { this.motion.x = lerp(this.motion.x, 0, 0.05); }

  jump_check() {
    if (this.is_grounded && sharedInput.jumpPressed) {
      this.motion.y = -PHYSICS.JUMP_FORCE;
      audio.play_jump();
    }
    if (!sharedInput.jump && this.motion.y < -PHYSICS.JUMP_FORCE / 2) {
      this.motion.y = -PHYSICS.JUMP_FORCE / 2;
    }
  }
  cancel_jump_check() {
    if (!sharedInput.jump && this.motion.y < -PHYSICS.JUMP_FORCE / 2) {
      this.motion.y = -PHYSICS.JUMP_FORCE / 2;
    }
  }
  bounce() { this.motion.y = 0; this.motion.y = -PHYSICS.JUMP_FORCE; }

  move() {
    const box = this.collider;
    const prevBottom = box.y + box.h;
    const result = moveAndSlide(box, this.motion.x * (1/60), this.motion.y * (1/60),
      this.world.tilemap, this.getSolids(), {
        dy: this.motion.y * (1/60), prevBottom,
      });
    this.x = box.x + box.w / 2;
    this.y = box.y + box.h;
    this.is_grounded = result.onFloor;
    this.is_on_slippery = result.onSlippery;
    if (result.hitX) this.motion.x = 0;
    if (result.hitY) this.motion.y = 0;
    this.wrap_around();
    return result;
  }

  wrap_around() {
    if (this.x < WRAP.LEFT) this.x = VIEW_W;
    if (this.x > VIEW_W) this.x = WRAP.LEFT;
    if (this.y < WRAP.TOP_CEIL) this.y = WRAP.TOP_CEIL;
    if (this.y > VIEW_H) this.y = WRAP.BOTTOM_WRAP;
  }

  check_grounded() {
    if (this.motion.y < 0) return false;
    for (const offX of [PLAYER_COLLIDER.RAY_LEFT_X, PLAYER_COLLIDER.RAY_CENTER_X, PLAYER_COLLIDER.RAY_RIGHT_X]) {
      const px = this.x + offX;
      const py = this.y;
      const tx = Math.floor(px / 16);
      const ty = Math.floor((py + 4) / 16);
      const tile = this.world.tilemap.get(tx, ty);
      if (tile !== 0 && tile !== 26) {
        const tileTop = ty * 16;
        if (tileTop >= py - 0.5) return true;
      } else if (tile === 26) {
        const tileTop = ty * 16;
        if (tileTop >= py - 0.5) return true;
      }
      for (const s of this.getSolids()) {
        if (px >= s.x && px < s.x + s.w && py + 4 >= s.y && py < s.y + s.h) return true;
      }
    }
    return false;
  }

  check_slippery() {
    for (const offX of [PLAYER_COLLIDER.RAY_LEFT_X, PLAYER_COLLIDER.RAY_CENTER_X, PLAYER_COLLIDER.RAY_RIGHT_X]) {
      const px = this.x + offX;
      const py = this.y;
      for (const s of this.world.slipperyBlocks) {
        if (px >= s.x && px < s.x + s.w && py + 4 >= s.y && py < s.y + s.h) return true;
      }
    }
    return false;
  }

  check_wall_direction() {
    const solids = this.getSolids();
    const wy = this.y + PLAYER_COLLIDER.WALL_RAY_Y;
    const rightProbe = { x: this.x, y: wy - 4, w: PLAYER_COLLIDER.WALL_RAY_OFFSET + 2, h: 8 };
    const leftProbe  = { x: this.x - PLAYER_COLLIDER.WALL_RAY_OFFSET - 2, y: wy - 4, w: PLAYER_COLLIDER.WALL_RAY_OFFSET + 2, h: 8 };
    const hitRight = collideTilemapAt(this.world.tilemap, rightProbe, solids, {});
    const hitLeft  = collideTilemapAt(this.world.tilemap, leftProbe, solids, {});
    if (hitLeft && !hitRight) return -1;
    if (hitRight && !hitLeft) return 1;
    return 0;
  }

  coyote_jump_check() {
    if ((this.coyote_timer > 0 || this.dash_jump_timer > 0) && sharedInput.jumpPressed) {
      this.motion.y = -PHYSICS.JUMP_FORCE;
      audio.play_jump();
      this.coyote_timer = 0;
      this.dash_jump_timer = 0;
    }
  }
  wall_jump_check() {
    const wallDir = this.check_wall_direction();
    if (wallDir !== 0 && sharedInput.jumpPressed) {
      this.motion.y = PHYSICS.WALL_JUMP_VEL_Y;
      const vx = -wallDir * PHYSICS.WALL_JUMP_VEL_X;
      this._transitionTo(States.WALL_JUMP, { x: vx });
      return true;
    }
    return false;
  }
  stomp_check() {
    if (sharedInput.downPressed) {
      this._transitionTo(States.STOMP, {});
      return true;
    }
    return false;
  }

  check_attack(direction) {
    const range = direction === 'down' || direction === 'up'
      ? PLAYER_COLLIDER.ATTACK_DOWN_RANGE : PLAYER_COLLIDER.ATTACK_RANGE;
    let probe;
    const c = this.collider;
    if (direction === 'right') probe = { x: c.x + c.w, y: c.y + 2, w: range, h: c.h - 4 };
    else if (direction === 'left') probe = { x: c.x - range, y: c.y + 2, w: range, h: c.h - 4 };
    else if (direction === 'up') probe = { x: c.x + 2, y: c.y - range, w: c.w - 4, h: range };
    else probe = { x: c.x + 2, y: c.y + c.h, w: c.w - 4, h: range };
    for (const cr of this.world.crates) {
      if (cr.dead) continue;
      if (probe.x < cr.x + cr.w && probe.x + probe.w > cr.x &&
          probe.y < cr.y + cr.h && probe.y + probe.h > cr.y) {
        cr.kill();
        return true;
      }
    }
    for (const e of this.world.enemies) {
      if (!e.is_alive) continue;
      const eb = e.collider;
      if (probe.x < eb.x + eb.w && probe.x + probe.w > eb.x &&
          probe.y < eb.y + eb.h && probe.y + probe.h > eb.y) {
        e.kill();
        return true;
      }
    }
    return false;
  }

  check_box_collision(motion) {
    const c = this.collider;
    for (const box of this.world.boxes) {
      if (box.dead) continue;
      if (motion.x > 0) {
        if (c.x + c.w >= box.x && c.x + c.w <= box.x + 4 &&
            c.y + c.h > box.y && c.y < box.y + box.h) {
          if (box.y > this.y) box.push(this.facing);
        }
      } else if (motion.x < 0) {
        if (c.x <= box.x + box.w && c.x >= box.x + box.w - 4 &&
            c.y + c.h > box.y && c.y < box.y + box.h) {
          if (box.y > this.y) box.push(this.facing);
        }
      }
    }
  }

  make_invincible() {
    this.invincible_flag = true;
    this.invincible_counter = 0;
  }
  invincible_controller() {
    if (!this.invincible_flag) return;
    this.invincible_counter++;
    if (this.invincible_counter % PHYSICS.INVINCIBLE_BLINK_FRAMES === 0) {
      this.sprite_visible = !this.sprite_visible;
    }
    if (this.invincible_counter > this.invincible_max) {
      this.invincible_flag = false;
      this.invincible_counter = 0;
      this.sprite_visible = true;
    }
  }

  _on_hurt_player() {
    if (this.invincible_flag) return;
    if (this.current_state === States.WIN) return;
    this._transitionTo(States.HURT, {});
  }
  _on_hit() {
    if (this.motion.y > 10) { this.bounce(); audio.play_hit(); }
  }
  _on_level_passed() { this.level_passed = true; }

  _transitionTo(name, msg) {
    if (this.state && this.state.exit) this.state.exit();
    this.current_state = name;
    const StateClass = STATE_CLASSES[name];
    if (!StateClass) { console.error('Unknown state', name); return; }
    this.state = new StateClass(this);
    if (this.state.enter) this.state.enter(msg || {});
  }

  update(dt, input) {
    if (this.coyote_timer > 0) this.coyote_timer -= dt;
    if (this.dash_jump_timer > 0) this.dash_jump_timer -= dt;
    if (this.state_ctx.key_time > 0) this.state_ctx.key_time--;
    if (this.state && this.state.physics_process) this.state.physics_process(dt);
    this.invincible_controller();
    this.animator.update(dt);
    const iv = this.get_input_vector();
    if (iv.x !== 0 && (this.current_state === States.RUN || this.current_state === States.IDLE)) {
      this.facing = iv.x;
    }
  }

  play_anim(name) {
    if (this.animator && this.animator.frames === PLAYER_ANIMS[name].frames) return;
    this.animator = new Animator(sprites, PLAYER_ANIMS[name]);
  }

  draw(ctx) {
    if (!this.sprite_visible && this.invincible_flag) return;
    const flip = this.facing < 0;
    this.animator.draw(ctx, this.x, this.y, { flipX: flip, ox: -8, oy: -16 });
  }
}

// ---------- State classes ----------
class IdleState {
  constructor(p) { this.p = p; }
  enter(msg) {
    this.p.play_anim('idle');
    this.p.state_ctx.dash_flag = false;
    if (msg.time > 90) {
      this.p.state_ctx.dash_flag = true;
      this.p.state_ctx.dash_last_direction = msg.direction || 0;
      this.p.state_ctx.key_time = 100;
    }
  }
  physics_process(dt) {
    if (this.p.level_passed) { this.p._transitionTo(States.WIN, {}); return; }
    const iv = this.p.get_input_vector();
    const ctx = this.p.state_ctx;
    if (ctx.dash_flag && iv.x !== 0 && ctx.key_time > 80 && iv.x === ctx.dash_last_direction) {
      this.p._transitionTo(States.DASH, { direction: iv.x });
      return;
    }
    if (iv.x !== 0) { this.p._transitionTo(States.RUN, {}); return; }
    this.p.apply_friction(iv);
    this.p.apply_gravity(dt);
    this.p.jump_check();
    this.p.move();
    this.p.is_grounded = this.p.check_grounded();
    this.p.is_on_slippery = this.p.check_slippery();
    if (!this.p.is_grounded) { this.p._transitionTo(States.AIR, {}); return; }
    if (sharedInput.down) { this.p._transitionTo(States.DUCK, {}); return; }
    if (iv.x !== 0 && ctx.key_time <= 0) {
      ctx.dash_last_direction = iv.x;
      ctx.key_time = 100;
      ctx.dash_flag = true;
    } else {
      ctx.key_time--;
    }
  }
  exit() {}
}

class RunState {
  constructor(p) { this.p = p; }
  enter(msg) {
    this.p.play_anim('run');
    this.p.state_ctx.key_time = 100;
    this.dustTimer = 0;
  }
  physics_process(dt) {
    if (this.p.level_passed) { this.p._transitionTo(States.WIN, {}); return; }
    const iv = this.p.get_input_vector();
    this.dustTimer = (this.dustTimer || 0) + 1;
    if (this.dustTimer >= 30) {
      this.dustTimer = 0;
      this.p.world.effects.walkDust(this.p.x + (Math.random() * 6 - 3), this.p.y, this.p.facing < 0);
    }
    if (iv.x === 0) {
      this.p._transitionTo(States.IDLE, { time: this.p.state_ctx.key_time, direction: this.p.state_ctx.dash_last_direction });
      return;
    }
    this.p.apply_horizontal_force(iv, dt);
    this.p.apply_friction(iv);
    this.p.jump_check();
    this.p.apply_gravity(dt);
    this.p.move();
    this.p.check_box_collision(this.p.motion);
    if (iv.x !== 0) this.p.facing = iv.x;
    this.p.is_grounded = this.p.check_grounded();
    this.p.is_on_slippery = this.p.check_slippery();
    if (!this.p.is_grounded) {
      this.p.coyote_timer = PHYSICS.COYOTE_TIME;
      this.p._transitionTo(States.AIR, {});
    }
  }
  exit() {}
}

class AirState {
  constructor(p) { this.p = p; }
  enter(msg) {
    if (this.p.motion.y > 0 && this.p.coyote_timer <= 0) this.p.coyote_timer = PHYSICS.COYOTE_TIME;
    if (this.p.motion.y < -110) this.p.world.effects.jumpDust(this.p.x, this.p.y);
    this.wallDustTimer = 0;
  }
  physics_process(dt) {
    if (this.p.level_passed) { this.p._transitionTo(States.WIN, {}); return; }
    const iv = this.p.get_input_vector();
    this.p.apply_horizontal_force(iv, dt);
    this.p.apply_friction(iv);
    const wallDir = this.p.check_wall_direction();
    if (wallDir !== 0 && this.p.motion.y > 0) {
      this.p.apply_gravity_wall(dt);
      this.wallDustTimer++;
      if (this.wallDustTimer >= 5) {
        this.wallDustTimer = 0;
        this.p.world.effects.walkDust(this.p.x + wallDir * 5, this.p.y - 6, wallDir < 0);
      }
    } else {
      this.p.apply_gravity(dt);
    }
    this.p.coyote_jump_check();
    if (this.p.wall_jump_check()) return;
    this.p.cancel_jump_check();
    if (this.p.stomp_check()) return;
    if (this.p.motion.y < 0) this.p.play_anim('Jump');
    else if (wallDir !== 0) { this.p.play_anim('wall'); this.p.facing = -wallDir; }
    else this.p.play_anim('fall');
    this.p.move();
    this.p.is_grounded = this.p.check_grounded();
    this.p.is_on_slippery = this.p.check_slippery();
    if (this.p.is_grounded) {
      this.p.world.effects.landDust(this.p.x, this.p.y);
      this.p._transitionTo(States.IDLE, {});
    }
  }
  exit() {}
}

class DuckState {
  constructor(p) { this.p = p; }
  enter(msg) {
    this.p.play_anim('duck');
    this.p.motion.x = 0;
    this.p.motion.y = 0;
    this.count = 0;
  }
  physics_process(dt) {
    if (this.p.level_passed) { this.p._transitionTo(States.WIN, {}); return; }
    if (this.p.is_grounded && sharedInput.down) this.count++;
    else this.count = 0;
    if (sharedInput.downReleased) { this.p._transitionTo(States.IDLE, {}); return; }
    if (this.count >= PHYSICS.DUCK_CHARGE_FRAMES) {
      this.p.play_anim('duck_charged');
      if (sharedInput.jumpPressed) { this.p._transitionTo(States.BLAST, {}); return; }
    }
    this.p.apply_gravity(dt);
    this.p.move();
    this.p.is_grounded = this.p.check_grounded();
    if (!this.p.is_grounded) this.p._transitionTo(States.AIR, {});
  }
  exit() {}
}

class DashState {
  constructor(p) { this.p = p; }
  enter(msg) {
    this.p.play_anim('Roll');
    this.p.motion.y = 0;
    this.p.state_ctx.dash_direction = msg.direction;
    this.p.motion.x = PHYSICS.DASH_VEL * msg.direction;
    this.p.facing = msg.direction;
    audio.play_attack();
    this.attackDir = msg.direction > 0 ? 'right' : 'left';
  }
  physics_process(dt) {
    this.p.world.effects.trace(this.p.x, this.p.y, this.p.facing < 0);
    this.p.check_attack(this.attackDir);
    this.p.motion.x = lerp(this.p.motion.x, 0, PHYSICS.FRICTION);
    this.p.apply_gravity(dt);
    const result = this.p.move();
    if (Math.abs(this.p.motion.x) < 10) {
      this.p.dash_jump_timer = PHYSICS.DASH_JUMP_GRACE;
      this.p._transitionTo(States.IDLE, {});
      return;
    }
    if (result.onWall) {
      bus.emit(SIGNALS.ADD_SCREENSHAKE, 2, 0.5);
      this.p.world.effects.stompDust(this.p.x, this.p.y);
      this.p.dash_jump_timer = PHYSICS.DASH_JUMP_GRACE;
      this.p._transitionTo(States.IDLE, {});
    }
  }
  exit() { this.p.dash_jump_timer = PHYSICS.DASH_JUMP_GRACE; }
}

class StompState {
  constructor(p) { this.p = p; }
  enter(msg) {
    this.p.play_anim('Roll');
    this.p.motion.x = 0;
    this.p.motion.y = 0;
    audio.play_attack();
  }
  physics_process(dt) {
    this.p.world.effects.trace(this.p.x, this.p.y, this.p.facing < 0);
    this.p.check_attack('down');
    this.p.is_grounded = this.p.check_grounded();
    if (this.p.is_grounded) {
      bus.emit(SIGNALS.ADD_SCREENSHAKE, 2, 0.5);
      this.p.world.effects.stompDust(this.p.x, this.p.y);
      this.p._transitionTo(States.IDLE, {});
      return;
    }
    this.p.motion.y = PHYSICS.STOMP_VEL;
    this.p.move();
  }
  exit() {}
}

class WallJumpState {
  constructor(p) { this.p = p; }
  enter(msg) {
    this.p.play_anim('Roll');
    this.p.motion.x = msg.x;
    this.p.facing = msg.x > 0 ? 1 : -1;
    audio.play_attack();
    this.p.world.effects.walkDust(this.p.x, this.p.y, this.p.facing < 0);
    this.traceTimer = 0;
  }
  physics_process(dt) {
    this.traceTimer++;
    if (this.traceTimer >= 6) {
      this.traceTimer = 0;
      this.p.world.effects.trace(this.p.x, this.p.y, this.p.facing < 0);
    }
    this.p.apply_jump_friction();
    this.p.apply_gravity(dt);
    this.p.move();
    const wallDir = this.p.check_wall_direction();
    this.p.is_grounded = this.p.check_grounded();
    if (this.p.is_grounded) { this.p._transitionTo(States.IDLE, {}); return; }
    if (wallDir !== 0 && this.p.motion.y > 0) { this.p._transitionTo(States.AIR, {}); return; }
    if (sharedInput.downPressed) this.p._transitionTo(States.STOMP, {});
  }
  exit() {}
}

class BlastState {
  constructor(p) { this.p = p; }
  enter(msg) {
    this.p.play_anim('Roll');
    this.p.state_ctx.blast_init_y = this.p.y;
    this.p.motion.x = 0;
    this.p.motion.y = PHYSICS.BLAST_VEL;
    audio.play_attack();
  }
  physics_process(dt) {
    this.p.world.effects.trace(this.p.x, this.p.y, this.p.facing < 0);
    this.p.check_attack('up');
    if (this.p.y < this.p.state_ctx.blast_init_y - PHYSICS.BLAST_HEIGHT) {
      this.p.motion.y = 0;
      this.p._transitionTo(States.AIR, {});
      return;
    }
    this.p.move();
    if (this.p.y <= 6) {
      bus.emit(SIGNALS.ADD_SCREENSHAKE, 2, 0.5);
      this.p._transitionTo(States.AIR, {});
    }
  }
  exit() { this.p.motion.y = 0; }
}

class HurtState {
  constructor(p) { this.p = p; }
  enter(msg) {
    this.p.play_anim('fall');
    this.p.motion.y = PHYSICS.HURT_KNOCKBACK_Y;
    this.p.motion.x = -PHYSICS.HURT_KNOCKBACK_X * this.p.facing;
    audio.play_hurt();
    if (this.p.world.gems_collected > 0) {
      const n = this.p.world.gems_collected;
      bus.emit(SIGNALS.UPDATE_GEM, -n);
      this.p.world.spawnGemsPattern(this.p.x, this.p.y - 8, Math.min(n, 18), 1);
    }
  }
  physics_process(dt) {
    this.p.apply_gravity(dt);
    this.p.move();
    this.p.is_grounded = this.p.check_grounded();
    if (this.p.is_grounded && this.p.motion.y > -40) this.p._transitionTo(States.IDLE, {});
  }
  exit() { this.p.make_invincible(); }
}

class WinState {
  constructor(p) { this.p = p; }
  enter(msg) { this.p.play_anim('Jump'); }
  physics_process(dt) {}
  exit() {}
}

const STATE_CLASSES = {
  [States.IDLE]: IdleState,
  [States.RUN]: RunState,
  [States.AIR]: AirState,
  [States.DUCK]: DuckState,
  [States.DASH]: DashState,
  [States.STOMP]: StompState,
  [States.WALL_JUMP]: WallJumpState,
  [States.BLAST]: BlastState,
  [States.HURT]: HurtState,
  [States.WIN]: WinState,
};
