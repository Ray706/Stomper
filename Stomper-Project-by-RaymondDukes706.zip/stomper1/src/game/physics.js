// physics.js — AABB tile collision with slide resolution.

import { TILE, SOLID_TILES, ONE_WAY_TILE } from './constants.js';

export function moveAndSlide(box, dx, dy, tilemap, solids, opts = {}) {
  const result = {
    x: box.x, y: box.y, movedX: 0, movedY: 0,
    hitX: false, hitY: false,
    onFloor: false, onCeiling: false, onWall: false,
    wallDir: 0, onSlippery: false, onOneWay: false,
  };

  if (dx !== 0) {
    const newX = box.x + dx;
    const probe = { x: newX, y: box.y, w: box.w, h: box.h };
    const hit = collideTilemapAt(tilemap, probe, solids, opts);
    if (hit) {
      result.hitX = true;
      result.onWall = true;
      result.wallDir = dx > 0 ? 1 : -1;
      if (dx > 0) {
        const wallX = hit.tileRight !== undefined ? hit.tileRight : (hit.solid ? hit.solid.x : probe.x);
        result.movedX = wallX - (box.x + box.w);
      } else {
        const wallX = hit.tileLeft !== undefined ? hit.tileLeft : (hit.solid ? hit.solid.x + hit.solid.w : probe.x);
        result.movedX = wallX - box.x;
      }
    } else {
      result.movedX = dx;
    }
    box.x += result.movedX;
  }
  result.x = box.x;

  if (dy !== 0) {
    const newY = box.y + dy;
    const probe = { x: box.x, y: newY, w: box.w, h: box.h };
    const hit = collideTilemapAt(tilemap, probe, solids, opts);
    if (hit) {
      result.hitY = true;
      if (dy > 0) {
        result.onFloor = true;
        if (hit.tileTop !== undefined) result.movedY = hit.tileTop - (box.y + box.h);
        else if (hit.solid) result.movedY = hit.solid.y - (box.y + box.h);
        if (hit.slippery) result.onSlippery = true;
        if (hit.oneWay) result.onOneWay = true;
      } else {
        result.onCeiling = true;
        if (hit.tileBottom !== undefined) result.movedY = hit.tileBottom - box.y;
        else if (hit.solid) result.movedY = hit.solid.y + hit.solid.h - box.y;
      }
    } else {
      result.movedY = dy;
    }
    box.y += result.movedY;
  }
  result.y = box.y;
  return result;
}

export function collideTilemapAt(tilemap, box, solids, opts = {}) {
  const goingUp = opts.dy !== undefined && opts.dy < 0;
  const prevBottom = opts.prevBottom;

  if (tilemap) {
    const minTx = Math.floor(box.x / TILE);
    const maxTx = Math.floor((box.x + box.w - 1) / TILE);
    const minTy = Math.floor(box.y / TILE);
    const maxTy = Math.floor((box.y + box.h - 1) / TILE);

    for (let ty = minTy; ty <= maxTy; ty++) {
      for (let tx = minTx; tx <= maxTx; tx++) {
        const id = tilemap.get(tx, ty);
        if (id === 0 || id === undefined) continue;
        const isOneWay = (id === ONE_WAY_TILE);
        const isSolid = SOLID_TILES.has(id);
        if (!isSolid && !isOneWay) continue;
        if (isOneWay) {
          if (goingUp) continue;
          if (prevBottom !== undefined && prevBottom > ty * TILE) continue;
          if (opts.dy !== undefined && opts.dy <= 0) continue;
        }
        const tileLeft = tx * TILE;
        const tileTop = ty * TILE;
        const tileRight = tileLeft + TILE;
        const tileBottom = tileTop + TILE;
        if (box.x + box.w > tileLeft && box.x < tileRight &&
            box.y + box.h > tileTop && box.y < tileBottom) {
          if (isOneWay) return { tileTop, tileBottom, tileLeft, tileRight, oneWay: true, slippery: false };
          return { tileTop, tileBottom, tileLeft, tileRight, slippery: false, oneWay: false };
        }
      }
    }
  }

  if (solids && solids.length > 0) {
    for (const s of solids) {
      if (s.dead) continue;
      const sLeft = s.x, sTop = s.y, sRight = s.x + s.w, sBottom = s.y + s.h;
      if (s.oneWay) {
        if (goingUp) continue;
        if (prevBottom !== undefined && prevBottom > sTop) continue;
        if (opts.dy !== undefined && opts.dy <= 0) continue;
      }
      if (box.x + box.w > sLeft && box.x < sRight &&
          box.y + box.h > sTop && box.y < sBottom) {
        return {
          tileTop: sTop, tileBottom: sBottom, tileLeft: sLeft, tileRight: sRight,
          solid: s, slippery: !!s.slippery, oneWay: !!s.oneWay,
        };
      }
    }
  }
  return null;
}

export function aabbOverlap(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x &&
         a.y < b.y + b.h && a.y + a.h > b.y;
}
