// effects.js — Particle/dust effect spawner.

import { sprites, Animator } from './sprites.js';
import { EFFECT_ANIMS } from './constants.js';

export class Effect {
  constructor(type, x, y, opts = {}) {
    this.type = type;
    this.x = x;
    this.y = y;
    this.dead = false;
    this.flipX = opts.flipX || false;
    this.scale = opts.scale || 1;
    this.alpha = 1;
    this.offsetX = opts.ox || 0;
    this.offsetY = opts.oy || 0;
    const def = EFFECT_ANIMS[type];
    if (!def) { this.dead = true; this.anim = null; return; }
    this.anim = new Animator(sprites, def);
    if (opts.ox === undefined) {
      this.offsetX = def.hframes ? -(sprites.get(def.frames[0])?.naturalWidth || 16) / def.hframes / 2 : -8;
    }
    if (opts.oy === undefined) {
      this.offsetY = def.duration ? -16 : -8;
    }
  }

  update(dt) {
    if (this.dead) return;
    this.anim.update(dt);
    if (this.anim.done) this.dead = true;
  }

  draw(ctx) {
    if (this.dead || !this.anim) return;
    this.anim.draw(ctx, this.x, this.y, {
      flipX: this.flipX, scale: this.scale, alpha: this.alpha,
      ox: this.offsetX, oy: this.offsetY,
    });
  }
}

export class EffectManager {
  constructor() { this.effects = []; }
  clear() { this.effects.length = 0; }
  spawn(type, x, y, opts) {
    const e = new Effect(type, x, y, opts);
    if (!e.dead) this.effects.push(e);
    return e;
  }
  walkDust(x, y, flipX) { return this.spawn('walk_dust', x, y, { flipX }); }
  jumpDust(x, y)        { return this.spawn('jump_dust', x, y); }
  landDust(x, y)        { return this.spawn('land_dust', x, y); }
  stompDust(x, y)       { return this.spawn('stomp_dust', x, y); }
  trace(x, y, flipX)    { return this.spawn('trace', x, y, { flipX }); }
  gemFeedback(x, y)     { return this.spawn('gem_feedback', x, y); }
  hitFeedback(x, y)     { return this.spawn('hit_feedback', x, y); }

  update(dt) {
    for (let i = this.effects.length - 1; i >= 0; i--) {
      this.effects[i].update(dt);
      if (this.effects[i].dead) this.effects.splice(i, 1);
    }
  }
  draw(ctx) {
    for (const e of this.effects) e.draw(ctx);
  }
}
