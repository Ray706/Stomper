// camera.js — Camera2D with screen-shake.

import { VIEW_W, VIEW_H } from './constants.js';
import { bus, SIGNALS } from './events.js';
import { audio } from './audio.js';

export class Camera {
  constructor() {
    this.x = VIEW_W / 2;
    this.y = VIEW_H / 2;
    this.shake = 0;
    this.shakeTimer = 0;
    this.shakeDuration = 0;
    this.offsetX = 0;
    this.offsetY = 0;
    this._bound = false;
  }

  bind() {
    if (this._bound) return;
    this._bound = true;
    bus.on(SIGNALS.ADD_SCREENSHAKE, (amount, duration) => {
      this.screenshake(amount, duration);
      audio.play_Stomp();
    });
  }

  setCenter(x, y) { this.x = x; this.y = y; }

  screenshake(amount, duration) {
    this.shake = amount;
    this.shakeDuration = duration;
    this.shakeTimer = duration;
  }

  update(dt) {
    if (this.shakeTimer > 0) {
      this.shakeTimer -= dt;
      if (this.shakeTimer <= 0) {
        this.shake = 0;
        this.offsetX = 0;
        this.offsetY = 0;
      } else {
        const amt = this.shake;
        this.offsetX = (Math.random() * 2 - 1) * amt;
        this.offsetY = (Math.random() * 2 - 1) * amt;
      }
    } else {
      this.offsetX = 0;
      this.offsetY = 0;
    }
  }

  apply(ctx) {
    ctx.save();
    ctx.translate(-Math.round(this.x - VIEW_W / 2 + this.offsetX),
                  -Math.round(this.y - VIEW_H / 2 + this.offsetY));
  }

  restore(ctx) { ctx.restore(); }
}

export const camera = new Camera();
