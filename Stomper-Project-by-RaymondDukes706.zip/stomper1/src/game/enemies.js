// enemies.js — WalkingEnemy and FlyingEnemy.

import { ENEMY, ENEMY_ANIMS, VIEW_W } from './constants.js';
import { sprites, Animator } from './sprites.js';
import { moveAndSlide, aabbOverlap } from './physics.js';
import { bus, SIGNALS } from './events.js';
import { audio } from './audio.js';
import { States } from './player.js';

class Enemy {
  constructor(x, y, world, direction = 1, respawnable = false) {
    this.world = world;
    this.x = x;
    this.y = y;
    this.spawn_x = x;
    this.spawn_y = y;
    this.motion = { x: 0, y: 0 };
    this.direction = direction;
    this.facing = direction;
    this.is_alive = true;
    this.killFlag = false;
    this.stuntFlag = false;
    this.respawning_flag = false;
    this.respawnable = respawnable;
    this.stunt_timer = 0;
    this.respawn_timer = 0;
    this.respawn_duration = ENEMY.RESPAWN_DURATION;
    this.max_speed = ENEMY.MAX_SPEED;
    this.gems_drop = ENEMY.GEMS_DROP;
    this.half_w = 5;
    this.half_h = 6;
    this.dead = false;
    this.sprite_visible = true;
  }
  get collider() {
    return { x: this.x - this.half_w, y: this.y - this.half_h * 2, w: this.half_w * 2, h: this.half_h * 2 };
  }
  kill() {
    if (!this.is_alive) return;
    this.is_alive = false;
    this.killFlag = true;
    this.motion.y = ENEMY.KILL_POP_Y;
    this.motion.x = ENEMY.KILL_POP_X * this.facing;
    audio.play_enemydeath();
    if (this.gems_drop > 0) this.world.spawnGemsPattern(this.x, this.y - 8, this.gems_drop, 1);
  }
  stunt() {
    this.stuntFlag = true;
    this.stunt_timer = ENEMY.STUNT_DURATION;
  }
  check_kill(stateName) {
    return stateName === States.STOMP || stateName === States.WALL_JUMP ||
           stateName === States.DASH || stateName === States.BLAST;
  }
  check_hits(player) {
    if (this.respawning_flag) return;
    if (!this.is_alive) return;
    if (!aabbOverlap(player.collider, this.collider)) return;
    if (player.current_state === States.DUCK) return;
    if (this.check_kill(player.current_state)) { this.kill(); return; }
    if (player.motion.y > 0 && !this.stuntFlag) {
      bus.emit(SIGNALS.HIT);
      this.stunt();
      return;
    }
    if (!player.invincible_flag && !this.stuntFlag) {
      bus.emit(SIGNALS.HURT_PLAYER);
      return;
    }
  }
  wrap_around() {
    if (this.x < -4) this.x = VIEW_W;
    if (this.x > VIEW_W) this.x = -4;
  }
  throw_air(dt) {
    this.motion.y += 600 * dt;
    this.x += this.motion.x * dt;
    this.y += this.motion.y * dt;
    if (this.y > 2000) {
      if (this.respawnable) this.restore_enemy();
      else this.dead = true;
    }
  }
  restore_enemy() {
    this.respawning_flag = true;
    this.respawn_timer = this.respawn_duration;
    this.sprite_visible = false;
    this.is_alive = true;
    this.killFlag = false;
    this.stuntFlag = false;
    this.motion = { x: 0, y: 0 };
    this.x = this.spawn_x;
    this.y = this.spawn_y;
  }
  update_anim(dt) { if (this.animator) this.animator.update(dt); }
  draw(ctx) {
    if (!this.sprite_visible || !this.animator) return;
    this.animator.draw(ctx, this.x, this.y, { flipX: this.facing < 0, ox: -8, oy: -16 });
  }
}

export class WalkingEnemy extends Enemy {
  constructor(x, y, world, direction = 1, respawnable = false) {
    super(x, y, world, direction, respawnable);
    this.animator = new Animator(sprites, ENEMY_ANIMS.walking.Walk);
    this.gravity = ENEMY.WALKER_GRAVITY * 60;
  }
  update(dt) {
    if (!this.is_alive) { this.throw_air(dt); this.update_anim(dt); return; }
    if (this.respawning_flag) {
      this.respawn_timer -= dt;
      if (this.respawn_timer <= 0) { this.respawning_flag = false; this.sprite_visible = true; }
      return;
    }
    if (this.stuntFlag) {
      this.stunt_timer -= dt;
      if (this.stunt_timer <= 0) this.stuntFlag = false;
      this.animator = new Animator(sprites, ENEMY_ANIMS.walking.stunt);
      this.motion.x = 0;
    } else {
      this.animator = new Animator(sprites, ENEMY_ANIMS.walking.Walk);
      this.motion.x = this.direction * this.max_speed;
      this.facing = this.direction;
      if (this._should_turn_around()) this.direction = -this.direction;
    }
    this.motion.y += this.gravity * dt;
    if (this.motion.y > ENEMY.WALKER_TERMINAL_VEL) this.motion.y = ENEMY.WALKER_TERMINAL_VEL;
    const box = this.collider;
    const result = moveAndSlide(box, this.motion.x * dt, this.motion.y * dt,
      this.world.tilemap, this.world.solids, {});
    this.x = box.x + box.w / 2;
    this.y = box.y + box.h;
    if (result.hitX) this.motion.x = 0;
    if (result.hitY) this.motion.y = 0;
    this.wrap_around();
    if (this.world.player) this.check_hits(this.world.player);
    this.update_anim(dt);
  }
  _should_turn_around() {
    const aheadX = this.x + this.direction * (this.half_w + 2);
    const footY = this.y + 2;
    const tx = Math.floor(aheadX / 16);
    const ty = Math.floor(footY / 16);
    if (this.world.tilemap.get(tx, ty) === 0) return true;
    const wallTx = Math.floor((this.x + this.direction * (this.half_w + 1)) / 16);
    const wallTy = Math.floor((this.y - 6) / 16);
    const wallTile = this.world.tilemap.get(wallTx, wallTy);
    if (wallTile !== 0 && wallTile !== 26) return true;
    return false;
  }
}

export class FlyingEnemy extends Enemy {
  constructor(x, y, world, direction = 1, respawnable = false) {
    super(x, y, world, direction, respawnable);
    this.animator = new Animator(sprites, ENEMY_ANIMS.flying.fly);
    this.respawn_duration = ENEMY.RESPAWN_DURATION_FLYING;
  }
  update(dt) {
    if (!this.is_alive) { this.throw_air(dt); this.update_anim(dt); return; }
    if (this.respawning_flag) {
      this.respawn_timer -= dt;
      if (this.respawn_timer <= 0) { this.respawning_flag = false; this.sprite_visible = true; }
      return;
    }
    if (this.stuntFlag) {
      this.stunt_timer -= dt;
      if (this.stunt_timer <= 0) this.stuntFlag = false;
      this.animator = new Animator(sprites, ENEMY_ANIMS.flying.stunt);
      this.motion.x = 0;
    } else {
      this.animator = new Animator(sprites, ENEMY_ANIMS.flying.fly);
      this.motion.x = this.direction * this.max_speed;
      this.facing = this.direction;
      if (this._hit_wall()) this.direction = -this.direction;
    }
    const box = this.collider;
    const result = moveAndSlide(box, this.motion.x * dt, 0,
      this.world.tilemap, this.world.solids, {});
    this.x = box.x + box.w / 2;
    this.y = box.y + box.h;
    if (result.hitX) this.motion.x = 0;
    this.wrap_around();
    if (this.world.player) this.check_hits(this.world.player);
    this.update_anim(dt);
  }
  _hit_wall() {
    const aheadX = this.x + this.direction * (this.half_w + 2);
    const aheadTx = Math.floor(aheadX / 16);
    const ty = Math.floor((this.y - 6) / 16);
    const tile = this.world.tilemap.get(aheadTx, ty);
    return tile !== 0 && tile !== 26;
  }
}
