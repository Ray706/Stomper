// audio.js — WebAudio-based audio manager with HTMLAudioElement fallback.

import { AUDIO } from './constants.js';

const dBToLinear = (db) => Math.pow(10, db / 20);

const VOLUMES = {
  bgm:         dBToLinear(-5.0) * 0.5,
  jump:        dBToLinear(-8.0),
  hurt:        dBToLinear(-6.429),
  pick:        dBToLinear(-6.429),
  stomp:       dBToLinear(-6.429),
  enemydeath:  dBToLinear(-6.429),
  attack:      dBToLinear(-6.429),
  hit:         dBToLinear(-6.429),
  door:        dBToLinear(4.0) * 0.5,
};

class AudioManager {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.bgmGain = null;
    this.sfxGain = null;
    this.bgmSource = null;
    this.bgmBuffer = null;
    this.bgmPlaying = false;
    this.bgmStartedAt = 0;
    this.bgmOffset = 0;
    this.bgmMuted = false;
    this.buffers = {};
    this.fallbacks = {};
    this.ready = false;
    this.loading = false;
    this.useFallback = false;
    this._muted = false;
    this._sfxMuted = false;
  }

  async init() {
    if (this.loading) return;
    this.loading = true;
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 1.0;
      this.masterGain.connect(this.ctx.destination);
      this.bgmGain = this.ctx.createGain();
      this.bgmGain.gain.value = 1.0;
      this.bgmGain.connect(this.masterGain);
      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 1.0;
      this.sfxGain.connect(this.masterGain);
      await this._preloadAll();
      this.ready = true;
    } catch (e) {
      console.warn('[audio] WebAudio init failed, using HTMLAudioElement fallback', e);
      this._initFallback();
      this.useFallback = true;
      this.ready = true;
    } finally {
      this.loading = false;
    }
  }

  async _preloadAll() {
    const names = Object.keys(AUDIO);
    await Promise.all(names.map(async (name) => {
      const url = AUDIO[name];
      try {
        const res = await fetch(url);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const arr = await res.arrayBuffer();
        const buf = await this.ctx.decodeAudioData(arr.slice(0));
        this.buffers[name] = buf;
      } catch (e) {
        console.warn(`[audio] failed to decode ${name} (${url}) — falling back to HTMLAudio`, e);
        const a = new Audio(url);
        a.preload = 'auto';
        this.fallbacks[name] = a;
      }
    }));
  }

  _initFallback() {
    for (const name of Object.keys(AUDIO)) {
      const a = new Audio(AUDIO[name]);
      a.preload = 'auto';
      this.fallbacks[name] = a;
    }
  }

  async unlock() {
    if (!this.ctx) await this.init();
    if (this.ctx && this.ctx.state === 'suspended') {
      try { await this.ctx.resume(); } catch (e) {}
    }
    if (this.ctx) {
      try {
        const buf = this.ctx.createBuffer(1, 1, 22050);
        const src = this.ctx.createBufferSource();
        src.buffer = buf;
        src.connect(this.ctx.destination);
        src.start(0);
      } catch (e) {}
    }
  }

  play_bgm() {
    if (!this.ready) return;
    if (this.bgmPlaying) return;
    if (this.useFallback || !this.buffers.bgm) {
      const a = this.fallbacks.bgm;
      if (a) {
        a.loop = true;
        a.volume = VOLUMES.bgm;
        a.currentTime = 0;
        a.play().catch(() => {});
        this.bgmPlaying = true;
      }
      return;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    const src = this.ctx.createBufferSource();
    src.buffer = this.buffers.bgm;
    src.loop = true;
    src.connect(this.bgmGain);
    if (this.bgmMuted || this._muted) this.bgmGain.gain.value = 0;
    else this.bgmGain.gain.value = VOLUMES.bgm;
    src.start(0, this.bgmOffset);
    this.bgmSource = src;
    this.bgmStartedAt = this.ctx.currentTime;
    this.bgmPlaying = true;
  }

  stop_bgm() {
    if (!this.bgmPlaying) return;
    if (this.bgmSource) {
      try {
        const elapsed = this.ctx.currentTime - this.bgmStartedAt;
        this.bgmOffset = (this.bgmOffset + elapsed) % this.bgmSource.buffer.duration;
        this.bgmSource.stop();
      } catch (e) {}
      this.bgmSource = null;
    }
    if (this.fallbacks.bgm) this.fallbacks.bgm.pause();
    this.bgmPlaying = false;
  }

  play(name, opts = {}) {
    if (!this.ready || this._sfxMuted) return;
    const volume = VOLUMES[name] !== undefined ? VOLUMES[name] * (opts.volumeMul || 1) : 0.5;
    if (this.useFallback || !this.buffers[name]) {
      const base = this.fallbacks[name];
      if (base) {
        const a = base.cloneNode(true);
        a.volume = Math.min(1, volume);
        a.currentTime = 0;
        a.play().catch(() => {});
        a.addEventListener('ended', () => { a.src = ''; });
      }
      return;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    const src = this.ctx.createBufferSource();
    src.buffer = this.buffers[name];
    const g = this.ctx.createGain();
    g.gain.value = volume;
    src.connect(g);
    g.connect(this.sfxGain);
    src.start(0);
  }

  play_jump()        { this.play('jump'); }
  play_hurt()        { this.play('hurt'); }
  play_Pick()        { this.play('pick'); }
  play_Stomp()       { this.play('stomp'); }
  play_enemydeath()  { this.play('enemydeath'); }
  play_attack()      { this.play('attack'); }
  play_door()        { this.play('door'); }
  play_hit()         { this.play('hit'); }

  toggleMute() {
    this._muted = !this._muted;
    if (this.bgmGain) this.bgmGain.gain.value = (this._muted || this.bgmMuted) ? 0 : VOLUMES.bgm;
    if (this.sfxGain) this.sfxGain.gain.value = this._muted ? 0 : 1.0;
    return this._muted;
  }
  isMuted() { return this._muted; }
}

export const audio = new AudioManager();
