// constants.js — Central tuning values ported from the original Godot project.

export const VIEW_W = 320;
export const VIEW_H = 240;
export const TILE = 16;

export const PHYSICS = {
  MAX_SPEED_X: 64,
  MAX_SPEED_Y: 200,
  ACCELERATION_GROUND: 500,
  ACCELERATION_AIR: 200,
  FRICTION: 0.1,
  GRAVITY: 200,
  GRAVITY_FALL: 400,
  GRAVITY_WALL: 200,
  WALL_SLIDE_MAX: 20,
  JUMP_FORCE: 125,
  JUMP_CUTOFF_FACTOR: 0.5,
  COYOTE_TIME: 0.2,
  DASH_JUMP_GRACE: 0.5,
  DASH_VEL: 420,
  STOMP_VEL: 400,
  BLAST_VEL: -400,
  BLAST_HEIGHT: 50,
  WALL_JUMP_VEL_Y: -100,
  WALL_JUMP_VEL_X: 200,
  HURT_KNOCKBACK_Y: -100,
  HURT_KNOCKBACK_X: 20,
  INVINCIBLE_MAX_FRAMES: 100,
  INVINCIBLE_BLINK_FRAMES: 7,
  DUCK_CHARGE_FRAMES: 50,
};

export const PLAYER_COLLIDER = {
  HALF_W: 5, HALF_H: 6, BOTTOM: 0, TOP: -12,
  RAY_FLOOR_Y: 4, RAY_LEFT_X: -5, RAY_CENTER_X: 0, RAY_RIGHT_X: 5,
  WALL_RAY_Y: -6, WALL_RAY_OFFSET: 5, WALL_RAY_LEN: 2,
  ATTACK_RANGE: 7, ATTACK_DOWN_RANGE: 5, ATTACK_UP_RANGE: 5,
};

export const ENEMY = {
  MAX_SPEED: 15, GEMS_DROP: 3,
  WALKER_GRAVITY: 9, WALKER_TERMINAL_VEL: 200,
  KILL_POP_Y: -300, KILL_POP_X: 50,
  STUNT_DURATION: 3.0,
  RESPAWN_DURATION: 3.0,
  RESPAWN_DURATION_FLYING: 2.0,
};

export const BOX = { PUSH_SPEED: 20, GRAVITY: 1000 };
export const CRATE = { DEFAULT_GEMS: 3 };

export const SOLID_TILES = new Set([1, 2, 3, 4, 5, 7, 8, 9, 10, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 27]);
export const ONE_WAY_TILE = 26;
export const DECORATION_TILES = new Set([11, 12, 13, 14, 19]);

export const LAYER = {
  PLAYER: 1, WORLD: 2, ENEMY_HURTBOX: 4, CRATES: 8, SLIPPERY: 16, ENEMIES: 32,
};

export const TILE_ATLAS = {
  1: [48, 0], 2: [64, 0], 3: [80, 0], 4: [96, 0], 5: [112, 0],
  7: [80, 16], 8: [112, 16], 9: [80, 32], 10: [112, 32],
  11: [0, 16], 12: [16, 16], 13: [48, 16], 14: [64, 16],
  15: [0, 32], 16: [16, 32], 17: [32, 32], 18: [48, 32], 19: [64, 32],
  20: [0, 48], 21: [16, 48], 22: [32, 48], 23: [48, 48],
  24: [64, 48], 25: [80, 48], 26: [96, 48], 27: [112, 48],
};

export const PLAYER_ANIMS = {
  idle:         { frames: ['player/run/run9.png'], fps: 5, loop: true },
  run:          { frames: ['player/run/run1.png','player/run/run2.png','player/run/run3.png','player/run/run4.png','player/run/run5.png','player/run/run6.png','player/run/run7.png','player/run/run8.png','player/run/run9.png','player/run/run10.png'], fps: 20, loop: true },
  Jump:         { frames: ['player/air/Jump.png'], fps: 5, loop: true },
  fall:         { frames: ['player/air/fall.png'], fps: 5, loop: true },
  Roll:         { frames: ['player/roll/Roll1.png','player/roll/Roll2.png','player/roll/Roll3.png'], fps: 20, loop: true },
  duck:         { frames: ['player/duck/duck.png'], fps: 5, loop: true },
  duck_charged: { frames: ['player/duck/duck2.png','player/duck/duck.png'], fps: 10, loop: true },
  wall:         { frames: ['player/wall.png'], fps: 5, loop: true },
};

export const ENEMY_ANIMS = {
  walking: {
    Walk:  { frames: ['enemies/walking/walk1.png','enemies/walking/walk2.png','enemies/walking/walk3.png','enemies/walking/walk4.png'], fps: 7, loop: true },
    stunt: { frames: ['enemies/walking/stunt1.png','enemies/walking/stunt2.png'], fps: 5, loop: true },
  },
  flying: {
    fly:   { frames: ['enemies/flying/flying1.png','enemies/flying/flying2.png','enemies/flying/flying3.png','enemies/flying/flying4.png'], fps: 10, loop: true },
    stunt: { frames: ['enemies/flying/stunt1.png','enemies/flying/stunt2.png'], fps: 7, loop: true },
  },
};

export const DOOR_ANIMS = {
  closed: { frames: ['door/door.png'], fps: 5, loop: false },
  active: { frames: ['door/active1.png','door/active2.png','door/active3.png','door/active4.png'], fps: 13, loop: true },
};

export const STAR_ANIMS = {
  spin: { frames: ['star/zaphire1.png','star/zaphire2.png','star/zaphire3.png','star/zaphire4.png'], fps: 15, loop: true },
};

export const GEM_ANIMS = {
  spin: { frames: ['gems/gem1.png','gems/gem2.png','gems/gem3.png','gems/gem4.png','gems/gem5.png','gems/gem6.png'], fps: 10, loop: true },
};

export const SHOOTING_ANIMS = {
  idle: { frames: ['shooting/shooting-head.png'], fps: 5, loop: false },
};

export const SHOOT_ANIMS = {
  fly: { frames: ['shooting/shoot1.png','shooting/shoot2.png','shooting/shoot3.png'], fps: 10, loop: true },
};

export const EFFECT_ANIMS = {
  walk_dust:   { frames: ['effects/walk-dust.png'],   fps: 10, loop: false, hframes: 3, duration: 0.3 },
  jump_dust:   { frames: ['effects/jump-dust.png'],   fps: 10, loop: false, hframes: 4, duration: 0.4 },
  land_dust:   { frames: ['effects/land-dust.png'],   fps: 10, loop: false, hframes: 5, duration: 0.5 },
  stomp_dust:  { frames: ['effects/stomp-dust-sheet.png'], fps: 10, loop: false, hframes: 4, duration: 0.4 },
  trace:       { frames: ['player/roll/trace.png'],   fps: 5, loop: false, duration: 0.5, fade: true },
  gem_feedback:{ frames: ['gems/gem-feedback.png'],   fps: 10, loop: false, hframes: 3, duration: 0.3 },
  hit_feedback:{ frames: ['effects/hit.png'],         fps: 10, loop: false, hframes: 3, duration: 0.3 },
};

export const AUDIO = {
  bgm: 'assets/audio/musicbox.ogg',
  jump: 'assets/audio/fx/jump.wav',
  hurt: 'assets/audio/fx/hurt.wav',
  pick: 'assets/audio/fx/pick.wav',
  stomp: 'assets/audio/fx/stomp.wav',
  enemydeath: 'assets/audio/fx/enemy_death.wav',
  attack: 'assets/audio/fx/attack.wav',
  hit: 'assets/audio/fx/hit.wav',
  door: 'assets/audio/fx/door.wav',
};

export const ASSET_BASE = './assets/sprites/';
export const FIXED_DT = 1 / 60;
export const PLAYER_SPRITE_OFFSET_Y = -11;
export const WRAP = { LEFT: -4, RIGHT: VIEW_W, TOP_CEIL: 5, BOTTOM_WRAP: VIEW_H - 32 };
export const TOTAL_LEVELS = 16;
export const FIRST_GAMEPLAY_LEVEL = 1;
export const LAST_GAMEPLAY_LEVEL = 15;
export const WIN_SCREEN_LEVEL = 16;
