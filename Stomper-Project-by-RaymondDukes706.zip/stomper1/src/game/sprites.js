// sprites.js — Asset loader + sprite animator.

import { ASSET_BASE } from './constants.js';
import {
  PLAYER_ANIMS, ENEMY_ANIMS, DOOR_ANIMS, STAR_ANIMS, GEM_ANIMS,
  SHOOTING_ANIMS, SHOOT_ANIMS, EFFECT_ANIMS,
} from './constants.js';

class SpriteCache {
  constructor() {
    this._images = new Map();
    this._loading = new Map();
    this._allLoaded = false;
  }

  load(path) {
    if (this._images.has(path)) return Promise.resolve(this._images.get(path));
    if (this._loading.has(path)) return this._loading.get(path);
    const p = new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => { this._images.set(path, img); resolve(img); };
      img.onerror = () => {
        console.warn('[sprites] failed to load', ASSET_BASE + path);
        this._images.set(path, img);
        resolve(img);
      };
      img.src = ASSET_BASE + path;
    });
    this._loading.set(path, p);
    return p;
  }

  async preload(paths) {
    await Promise.all(paths.map((p) => this.load(p)));
    this._allLoaded = true;
  }

  get(path) { return this._images.get(path) || null; }

  draw(ctx, path, x, y, opts = {}) {
    const img = this.get(path);
    if (!img || !img.complete || img.naturalWidth === 0) return;
    const { flipX = false, scale = 1, alpha = 1, w, h, ox = 0, oy = 0 } = opts;
    ctx.save();
    ctx.globalAlpha = alpha;
    const dw = w || img.naturalWidth;
    const dh = h || img.naturalHeight;
    if (flipX) {
      ctx.translate(Math.round(x + ox + dw * scale), Math.round(y + oy));
      ctx.scale(-scale, scale);
      ctx.drawImage(img, 0, 0, dw, dh);
    } else {
      ctx.translate(Math.round(x + ox), Math.round(y + oy));
      ctx.scale(scale, scale);
      ctx.drawImage(img, 0, 0, dw, dh);
    }
    ctx.restore();
  }

  drawFrame(ctx, sheetPath, frameIndex, x, y, opts = {}) {
    const img = this.get(sheetPath);
    if (!img || !img.complete || img.naturalWidth === 0) return;
    const { flipX = false, scale = 1, alpha = 1, frameW, frameH, ox = 0, oy = 0 } = opts;
    const fw = frameW || img.naturalHeight;
    const fh = frameH || img.naturalHeight;
    const sx = frameIndex * fw;
    ctx.save();
    ctx.globalAlpha = alpha;
    if (flipX) {
      ctx.translate(Math.round(x + ox + fw * scale), Math.round(y + oy));
      ctx.scale(-scale, scale);
      ctx.drawImage(img, sx, 0, fw, fh, 0, 0, fw, fh);
    } else {
      ctx.translate(Math.round(x + ox), Math.round(y + oy));
      ctx.scale(scale, scale);
      ctx.drawImage(img, sx, 0, fw, fh, 0, 0, fw, fh);
    }
    ctx.restore();
  }
}

export const sprites = new SpriteCache();

export class Animator {
  constructor(spriteCache, def) {
    this.sprites = spriteCache;
    this.frames = def.frames;
    this.fps = def.fps || 10;
    this.loop = def.loop !== false;
    this.time = 0;
    this.done = false;
    this.frameW = def.frameW || null;
    this.frameH = def.frameH || null;
    this.hframes = def.hframes || 1;
    this.fade = def.fade || false;
    this.duration = def.duration || null;
  }
  reset() { this.time = 0; this.done = false; }
  update(dt) {
    if (this.done) return;
    this.time += dt;
    if (this.duration) {
      if (this.time >= this.duration) {
        this.time = this.duration;
        this.done = !this.loop;
      }
    } else {
      const totalDur = this.frames.length / this.fps;
      if (this.time >= totalDur) {
        if (this.loop) this.time = this.time % totalDur;
        else { this.time = totalDur; this.done = true; }
      }
    }
  }
  get currentFrameIndex() {
    if (this.duration) {
      const t = Math.min(this.time / this.duration, 1);
      return Math.min(this.hframes - 1, Math.floor(t * this.hframes));
    }
    return Math.min(this.frames.length - 1, Math.floor(this.time * this.fps));
  }
  get alpha() {
    if (!this.fade) return 1;
    if (!this.duration) return 1;
    return Math.max(0, 1 - this.time / this.duration);
  }
  draw(ctx, x, y, opts = {}) {
    if (this.hframes > 1) {
      const idx = this.currentFrameIndex;
      const img = this.sprites.get(this.frames[0]);
      if (!img || !img.complete || img.naturalWidth === 0) return;
      const fw = img.naturalWidth / this.hframes;
      const fh = img.naturalHeight;
      this.sprites.drawFrame(ctx, this.frames[0], idx, x, y, {
        ...opts, frameW: fw, frameH: fh,
        alpha: this.alpha * (opts.alpha || 1),
        ox: opts.ox !== undefined ? opts.ox : -fw / 2,
        oy: opts.oy !== undefined ? opts.oy : -fh,
      });
    } else {
      const idx = this.currentFrameIndex;
      const path = this.frames[idx];
      this.sprites.draw(ctx, path, x, y, {
        ...opts,
        alpha: this.alpha * (opts.alpha || 1),
      });
    }
  }
}

export function getAllSpritePaths() {
  const paths = new Set();
  paths.add('world/tileset.png');
  paths.add('world/plant.png');
  paths.add('world/back.png');
  paths.add('world/back-animated1.png');
  paths.add('world/back-animated2.png');
  paths.add('world/back-animated3.png');
  paths.add('levels/title.png');
  paths.add('gems/gem-empty.png');
  paths.add('gems/gem-taken.png');
  for (const def of Object.values(PLAYER_ANIMS))    for (const f of def.frames) paths.add(f);
  for (const type of Object.values(ENEMY_ANIMS))
    for (const def of Object.values(type))
      for (const f of def.frames) paths.add(f);
  for (const def of Object.values(DOOR_ANIMS))      for (const f of def.frames) paths.add(f);
  for (const def of Object.values(STAR_ANIMS))      for (const f of def.frames) paths.add(f);
  for (const def of Object.values(GEM_ANIMS))       for (const f of def.frames) paths.add(f);
  for (const def of Object.values(SHOOTING_ANIMS))  for (const f of def.frames) paths.add(f);
  for (const def of Object.values(SHOOT_ANIMS))     for (const f of def.frames) paths.add(f);
  for (const def of Object.values(EFFECT_ANIMS))    for (const f of def.frames) paths.add(f);
  paths.add('crates/crate.png');
  paths.add('crates/brick.png');
  paths.add('spikes/spike-block.png');
  paths.add('spikes/spikes.png');
  paths.add('slippery/slime-block.png');
  paths.add('shooting/shooting-head.png');
  return Array.from(paths);
}

export async function preloadAllSprites() {
  await sprites.preload(getAllSpritePaths());
}
