// events.js — Signal bus (ports Godot's Events autoload).

export class EventBus {
  constructor() { this._handlers = new Map(); }
  on(signal, handler) {
    if (!this._handlers.has(signal)) this._handlers.set(signal, new Set());
    this._handlers.get(signal).add(handler);
    return () => this.off(signal, handler);
  }
  off(signal, handler) {
    const s = this._handlers.get(signal);
    if (s) s.delete(handler);
  }
  emit(signal, ...args) {
    const s = this._handlers.get(signal);
    if (!s) return;
    for (const h of s) {
      try { h(...args); } catch (e) { console.error('[EventBus handler error]', signal, e); }
    }
  }
  clear() { this._handlers.clear(); }
}

export const SIGNALS = {
  ADD_SCREENSHAKE: 'add_screenshake',
  HIT: 'hit',
  HURT: 'hurt',
  HURT_PLAYER: 'hurt_player',
  UPDATE_GEM: 'update_gem',
  UPDATE_TIME: 'update_time',
  LEVEL_PASSED: 'level_passed',
  OPEN_DOOR: 'open_door',
  UPDATE_UI: 'update_ui',
};

export const bus = new EventBus();
