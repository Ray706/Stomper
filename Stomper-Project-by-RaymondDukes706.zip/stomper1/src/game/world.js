// world.js — Level loader, tilemap, and entity registry.

import { TILE, VIEW_W, VIEW_H, SOLID_TILES, ONE_WAY_TILE, TILE_ATLAS } from './constants.js';
import { sprites } from './sprites.js';
import { EffectManager } from './effects.js';
import { camera } from './camera.js';
import { bus, SIGNALS } from './events.js';
import levelsData from './levels-data.js';
import { Player } from './player.js';
import { WalkingEnemy, FlyingEnemy } from './enemies.js';
import { Gem, Crate, Door, Spikes, SpikesBlock, ShootingBlock, SlipperyBlock, Star, Box } from './objects.js';

export class TileMap {
  constructor() {
    this.cells = new Map();
    this.maxX = 0;
    this.maxY = 0;
  }
  set(x, y, id) {
    this.cells.set(x + ',' + y, id);
    if (x > this.maxX) this.maxX = x;
    if (y > this.maxY) this.maxY = y;
  }
  get(x, y) { return this.cells.get(x + ',' + y) || 0; }
  forEach(cb) {
    for (const [key, id] of this.cells) {
      const [x, y] = key.split(',').map(Number);
      cb(x, y, id);
    }
  }
}

export class World {
  constructor(levelNum) {
    this.levelNum = levelNum;
    this.data = levelsData[String(levelNum)];
    if (!this.data) throw new Error('Level ' + levelNum + ' not found');
    this.tilemap = new TileMap();
    this.solids = [];
    this.crates = [];
    this.spikes = [];
    this.spikesBlocks = [];
    this.shootingBlocks = [];
    this.slipperyBlocks = [];
    this.stars = [];
    this.boxes = [];
    this.gems = [];
    this.enemies = [];
    this.shoots = [];
    this.bricks = [];
    this.props = [];
    this.labels = [];
    this.door = null;
    this.player = null;
    this.effects = new EffectManager();
    this.gems_required = this.data.gems_required;
    this.gems_collected = 0;
    this.time = 0;
    this.completed = false;
    this.bgFrame = 0;
    this.bgTimer = 0;
    this._build();
  }

  _build() {
    const d = this.data;
    for (const [x, y, id] of d.tiles) this.tilemap.set(x, y, id);
    this.player = new Player(d.player_start.x, d.player_start.y, this);
    this.door = new Door(d.door.x, d.door.y, this);
    for (const g of d.gems) this.gems.push(new Gem(g.x, g.y, this, g.take_flag));
    for (const e of d.enemies) {
      if (e.type === 'flying') this.enemies.push(new FlyingEnemy(e.x, e.y, this, e.direction, e.respawnable));
      else this.enemies.push(new WalkingEnemy(e.x, e.y, this, e.direction, e.respawnable));
    }
    for (const c of d.crates) this.crates.push(new Crate(c.x, c.y, this, c.gems_spawn_number));
    for (const s of d.spikes) this.spikes.push(new Spikes(s.x, s.y, this));
    for (const s of d.spikes_blocks) this.spikesBlocks.push(new SpikesBlock(s.x, s.y, this));
    for (const s of d.shooting_blocks) this.shootingBlocks.push(new ShootingBlock(s.x, s.y, this, s.shoot_speed));
    for (const s of d.slippery_blocks) {
      const sb = new SlipperyBlock(s.x, s.y, this);
      this.slipperyBlocks.push(sb);
      this.solids.push(sb);
    }
    for (const s of d.stars) this.stars.push(new Star(s.x, s.y, this));
    for (const b of d.boxes) {
      const box = new Box(b.x, b.y, this);
      this.boxes.push(box);
      this.solids.push(box);
    }
    for (const p of d.props) this.props.push({ x: p.x, y: p.y, flip: p.flip });
    for (const l of d.labels) this.labels.push({ x: l.x, y: l.y, text: l.text });
    this._onGemUpdate = (v) => {
      this.gems_collected = Math.max(0, Math.min(this.gems_required, this.gems_collected + v));
      if (this.gems_collected >= this.gems_required) bus.emit(SIGNALS.OPEN_DOOR);
    };
    bus.on(SIGNALS.UPDATE_GEM, this._onGemUpdate);
  }

  destroy() {
    bus.off(SIGNALS.UPDATE_GEM, this._onGemUpdate);
    if (this.player) this.player.destroy();
    if (this.door) this.door.destroy();
  }

  addShoot(shoot) { this.shoots.push(shoot); }
  addBrick(brick) { this.bricks.push(brick); }

  spawnGem(x, y, vx, vy) {
    const g = new Gem(x, y, this, false);
    g.setInitialVelocity(vx, vy);
    this.gems.push(g);
  }
  spawnGemsPattern(x, y, count, dir = 1) {
    const pattern = [
      [-70, -40], [70, -40], [0, -100],
      [-50, -80], [50, -80], [0, -120],
      [-80, -30], [80, -30], [-30, -90], [30, -90],
      [-60, -60], [60, -60], [0, -150],
      [-90, -20], [90, -20], [-40, -110], [40, -110], [0, -180],
    ];
    for (let i = 0; i < count && i < pattern.length; i++) {
      const [vx, vy] = pattern[i];
      this.spawnGem(x, y, vx * dir, vy);
    }
  }

  update(dt, input) {
    if (this.completed) {
      this.effects.update(dt);
      if (this.player) this.player.update(dt, input);
      this.bgTimer += dt;
      if (this.bgTimer >= 1 / 12) { this.bgTimer = 0; this.bgFrame = (this.bgFrame + 1) % 3; }
      return;
    }
    this.time += dt;
    this.bgTimer += dt;
    if (this.bgTimer >= 1 / 12) { this.bgTimer = 0; this.bgFrame = (this.bgFrame + 1) % 3; }
    if (this.player) this.player.update(dt, input);
    for (const e of this.enemies) e.update(dt);
    for (const g of this.gems) g.update(dt);
    for (const c of this.crates) c.update(dt);
    for (const sb of this.spikesBlocks) sb.update(dt);
    for (const sb of this.shootingBlocks) sb.update(dt);
    for (let i = this.shoots.length - 1; i >= 0; i--) {
      const s = this.shoots[i];
      s.update(dt);
      if (s.dead) this.shoots.splice(i, 1);
    }
    for (let i = this.bricks.length - 1; i >= 0; i--) {
      const b = this.bricks[i];
      b.update(dt);
      if (b.dead) this.bricks.splice(i, 1);
    }
    for (const s of this.stars) s.update(dt);
    for (const b of this.boxes) b.update(dt);
    for (const s of this.spikes) s.update(dt);
    this.effects.update(dt);
    if (this.player) {
      camera.setCenter(VIEW_W / 2, VIEW_H / 2);
    }
    camera.update(dt);
  }

  draw(ctx) {
    this._drawBackground(ctx);
    camera.apply(ctx);
    this._drawTiles(ctx);
    this._drawProps(ctx);
    if (this.door) this.door.draw(ctx);
    for (const c of this.crates) c.draw(ctx);
    for (const b of this.boxes) b.draw(ctx);
    for (const sb of this.slipperyBlocks) sb.draw(ctx);
    for (const s of this.spikes) s.draw(ctx);
    for (const sb of this.spikesBlocks) sb.draw(ctx);
    for (const sb of this.shootingBlocks) sb.draw(ctx);
    for (const s of this.stars) s.draw(ctx);
    for (const g of this.gems) g.draw(ctx);
    for (const e of this.enemies) e.draw(ctx);
    if (this.player) this.player.draw(ctx);
    for (const s of this.shoots) s.draw(ctx);
    for (const b of this.bricks) b.draw(ctx);
    this.effects.draw(ctx);
    camera.restore(ctx);
    this._drawLabels(ctx);
  }

  _drawBackground(ctx) {
    const path = `world/back-animated${this.bgFrame + 1}.png`;
    const img = sprites.get(path);
    if (img && img.complete && img.naturalWidth > 0) ctx.drawImage(img, 0, 0, VIEW_W, VIEW_H);
    else { ctx.fillStyle = '#1a1c2c'; ctx.fillRect(0, 0, VIEW_W, VIEW_H); }
  }

  _drawTiles(ctx) {
    const tilesetImg = sprites.get('world/tileset.png');
    if (!tilesetImg || !tilesetImg.complete) return;
    this.tilemap.forEach((x, y, id) => {
      const atlas = TILE_ATLAS[id];
      if (!atlas) return;
      const [sx, sy] = atlas;
      ctx.drawImage(tilesetImg, sx, sy, TILE, TILE, x * TILE, y * TILE, TILE, TILE);
    });
  }

  _drawProps(ctx) {
    const plantImg = sprites.get('world/plant.png');
    if (!plantImg || !plantImg.complete) return;
    for (const p of this.props) {
      ctx.save();
      if (p.flip) {
        ctx.translate(Math.round(p.x + plantImg.naturalWidth / 2), Math.round(p.y - plantImg.naturalHeight / 2));
        ctx.scale(-1, 1);
        ctx.drawImage(plantImg, -plantImg.naturalWidth / 2, -plantImg.naturalHeight / 2);
      } else {
        ctx.translate(Math.round(p.x), Math.round(p.y - plantImg.naturalHeight / 2));
        ctx.drawImage(plantImg, 0, -plantImg.naturalHeight / 2);
      }
      ctx.restore();
    }
  }

  _drawLabels(ctx) {
    ctx.save();
    ctx.font = '8px Pixel, "Courier New", monospace';
    ctx.fillStyle = '#fff';
    ctx.textBaseline = 'top';
    for (const l of this.labels) ctx.fillText(l.text, Math.round(l.x), Math.round(l.y));
    ctx.restore();
  }
}
