// input.js — Unified input manager for keyboard, mouse, and touch.

class InputManager {
  constructor() {
    this._held = { left: false, right: false, up: false, down: false, jump: false };
    this._pressed = { left: false, right: false, up: false, down: false, jump: false, reload: false, cancel: false, mute: false };
    this._released = { left: false, right: false, up: false, down: false, jump: false };
    this._keyDown = new Set();
    this._lastLeftPressTime = 0;
    this._lastRightPressTime = 0;
    this._lastLeftReleaseTime = 0;
    this._lastRightReleaseTime = 0;
    this.usedKeyboard = false;
    this.usedTouch = false;
    this.usedMouse = false;
    this._bind();
  }

  _bind() {
    if (typeof window === 'undefined') return;
    window.addEventListener('keydown', (e) => this._onKeyDown(e), { passive: false });
    window.addEventListener('keyup', (e) => this._onKeyUp(e), { passive: false });
    window.addEventListener('mousedown', () => { this.usedMouse = true; }, { passive: true });
    window.addEventListener('touchstart', (e) => {
      if (e.cancelable) e.preventDefault();
      this.usedTouch = true;
    }, { passive: false });
    window.addEventListener('touchmove', (e) => { if (e.cancelable) e.preventDefault(); }, { passive: false });
    window.addEventListener('contextmenu', (e) => e.preventDefault());
    window.addEventListener('blur', () => this._releaseAll());
    document.addEventListener('visibilitychange', () => { if (document.hidden) this._releaseAll(); });
  }

  _onKeyDown(e) {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const code = e.code;
    let handled = true;
    switch (code) {
      case 'ArrowLeft': case 'KeyA':
        if (!this._held.left) { this._pressed.left = true; this._lastLeftPressTime = performance.now(); }
        this._held.left = true; break;
      case 'ArrowRight': case 'KeyD':
        if (!this._held.right) { this._pressed.right = true; this._lastRightPressTime = performance.now(); }
        this._held.right = true; break;
      case 'ArrowUp': case 'KeyW':
        if (!this._held.up) this._pressed.up = true;
        this._held.up = true; break;
      case 'ArrowDown': case 'KeyS':
        if (!this._held.down) this._pressed.down = true;
        this._held.down = true; break;
      case 'Space': case 'Enter': case 'NumpadEnter':
        if (!this._held.jump) this._pressed.jump = true;
        this._held.jump = true; break;
      case 'KeyR': this._pressed.reload = true; break;
      case 'Escape': this._pressed.cancel = true; break;
      case 'KeyM': this._pressed.mute = true; break;
      default: handled = false;
    }
    if (handled) {
      this.usedKeyboard = true;
      if (e.cancelable) e.preventDefault();
    }
  }

  _onKeyUp(e) {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const code = e.code;
    switch (code) {
      case 'ArrowLeft': case 'KeyA':
        this._held.left = false; this._released.left = true; this._lastLeftReleaseTime = performance.now(); break;
      case 'ArrowRight': case 'KeyD':
        this._held.right = false; this._released.right = true; this._lastRightReleaseTime = performance.now(); break;
      case 'ArrowUp': case 'KeyW':
        this._held.up = false; this._released.up = true; break;
      case 'ArrowDown': case 'KeyS':
        this._held.down = false; this._released.down = true; break;
      case 'Space': case 'Enter': case 'NumpadEnter':
        this._held.jump = false; this._released.jump = true; break;
    }
  }

  _releaseAll() { for (const k of Object.keys(this._held)) this._held[k] = false; }

  setVirtualButton(name, pressed) {
    if (!(name in this._held)) return;
    if (pressed && !this._held[name]) {
      this._pressed[name] = true;
      if (name === 'left')  this._lastLeftPressTime = performance.now();
      if (name === 'right') this._lastRightPressTime = performance.now();
      this.usedTouch = true;
    } else if (!pressed && this._held[name]) {
      this._released[name] = true;
      if (name === 'left')  this._lastLeftReleaseTime = performance.now();
      if (name === 'right') this._lastRightReleaseTime = performance.now();
    }
    this._held[name] = pressed;
  }

  pulseVirtual(name) {
    if (name in this._pressed) this._pressed[name] = true;
    if (name === 'reload') this._pressed.reload = true;
    if (name === 'cancel') this._pressed.cancel = true;
    if (name === 'mute') this._pressed.mute = true;
    this.usedTouch = true;
  }

  endFrame() {
    for (const k of Object.keys(this._pressed)) this._pressed[k] = false;
    for (const k of Object.keys(this._released)) this._released[k] = false;
  }

  get left()         { return this._held.left; }
  get right()        { return this._held.right; }
  get up()           { return this._held.up; }
  get down()         { return this._held.down; }
  get jump()         { return this._held.jump; }
  get leftPressed()  { return this._pressed.left; }
  get rightPressed() { return this._pressed.right; }
  get upPressed()    { return this._pressed.up; }
  get downPressed()  { return this._pressed.down; }
  get downReleased() { return this._released.down; }
  get jumpPressed()  { return this._pressed.jump; }
  get jumpReleased() { return this._released.jump; }
  get reload()       { return this._pressed.reload; }
  get cancel()       { return this._pressed.cancel; }
  get mute()         { return this._pressed.mute; }
  get accept()       { return this._pressed.jump; }
  get acceptHeld()   { return this._held.jump; }
  get menuCancel()   { return this._pressed.cancel; }

  getInputVectorX() { return (this._held.right ? 1 : 0) - (this._held.left ? 1 : 0); }
}

export const input = new InputManager();
