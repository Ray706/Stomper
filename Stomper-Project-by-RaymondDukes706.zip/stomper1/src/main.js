// main.js — App bootstrap.

import { h, render } from 'preact';
import { App } from './App.js';

render(h(App, null), document.getElementById('app'));
