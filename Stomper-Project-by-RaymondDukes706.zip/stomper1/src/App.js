// App.js — Root Preact component.

import { h } from 'preact';
import { useState, useEffect, useRef, useCallback } from 'preact/hooks';
import { engine } from './game/engine.js';
import { audio } from './game/audio.js';
import { FIRST_GAMEPLAY_LEVEL, LAST_GAMEPLAY_LEVEL, VIEW_W, VIEW_H } from './game/constants.js';
import { TouchControls } from './components/TouchControls.js';
import { HUD } from './components/HUD.js';
import { StartScreen } from './components/StartScreen.js';
import { AboutScreen } from './components/AboutScreen.js';
import { GameOverScreen } from './components/GameOverScreen.js';
import { FadeOverlay } from './components/FadeOverlay.js';

export function App() {
  const [screen, setScreen] = useState('loading');
  const [snap, setSnap] = useState({ gems_collected: 0, gems_required: 0, time: 0, level: 1, state: '', stars: 0, muted: false });
  const [fade, setFade] = useState({ active: false, alpha: 0 });
  const [audioUnlocked, setAudioUnlocked] = useState(false);
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let mounted = true;
    (async () => {
      await engine.init(canvas);
      if (!mounted) return;
      engine.start();
      setScreen('title');
    })();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    engine.on('frame', (s) => setSnap(s));
    engine.on('level_complete', (levelNum) => {
      engine.fadeOut(0.6, () => {
        const next = levelNum + 1;
        if (next > LAST_GAMEPLAY_LEVEL) setScreen('win');
        else engine.loadLevel(next);
      });
    });
  }, []);

  const unlockAudio = useCallback(async () => {
    if (audioUnlocked) return;
    await audio.unlock();
    setAudioUnlocked(true);
  }, [audioUnlocked]);

  const startGame = useCallback(async () => {
    await unlockAudio();
    audio.play_bgm();
    setScreen('playing');
    engine.loadLevel(FIRST_GAMEPLAY_LEVEL);
  }, [unlockAudio]);

  const gotoAbout = useCallback(() => { setScreen('about'); }, []);
  const backToTitle = useCallback(() => { setScreen('title'); }, []);

  const [inputMethod, setInputMethod] = useState('auto');
  useEffect(() => {
    const onFirstTouch = () => { setInputMethod('touch'); };
    const onFirstKey = (e) => {
      if (e.code && (e.code.startsWith('Key') || e.code.startsWith('Arrow'))) setInputMethod('keyboard');
    };
    window.addEventListener('touchstart', onFirstTouch, { once: true, passive: true });
    window.addEventListener('keydown', onFirstKey, { once: true });
    return () => {
      window.removeEventListener('touchstart', onFirstTouch);
      window.removeEventListener('keydown', onFirstKey);
    };
  }, []);

  return (
    h('div', { class: 'app-container' },
      h('div', {
        class: 'canvas-wrapper' + (screen === 'playing' ? ' playing' : ''),
        onTouchStart: unlockAudio,
        onMouseDown: unlockAudio,
      },
        h('canvas', {
          ref: canvasRef,
          class: 'game-canvas',
          width: VIEW_W,
          height: VIEW_H,
        }),
        screen === 'playing' && h(HUD, {
          gems_collected: snap.gems_collected,
          gems_required: snap.gems_required,
          time: snap.time,
          level: snap.level,
          state: snap.state,
          muted: snap.muted,
          onToggleMute: () => engine.toggleMute(),
        }),
        screen === 'playing' && h(TouchControls, { inputMethod }),
        screen === 'title' && h(StartScreen, { onStart: startGame, onAbout: gotoAbout }),
        screen === 'about' && h(AboutScreen, { onBack: backToTitle }),
        screen === 'win' && h(GameOverScreen, {
          time: snap.time, stars: snap.stars,
          onRestart: () => { engine.global.stars_taken = 0; backToTitle(); },
        }),
        h(FadeOverlay, { alpha: fade.alpha }),
      ),
      h('style', null, `
        .app-container {
          position: absolute; inset: 0;
          background: #000;
          display: flex; align-items: center; justify-content: center;
          overflow: hidden;
        }
        .canvas-wrapper {
          position: relative;
          width: 100%; height: 100%;
          display: flex; align-items: center; justify-content: center;
          background: #000;
        }
        .game-canvas {
          width: min(100vw, calc(100vh * ${VIEW_W / VIEW_H}));
          height: min(100vh, calc(100vw * ${VIEW_H / VIEW_W}));
          max-width: ${VIEW_W * 4}px;
          max-height: ${VIEW_H * 4}px;
          image-rendering: pixelated;
          image-rendering: -moz-crisp-edges;
          image-rendering: crisp-edges;
          background: #000;
          touch-action: none;
        }
        @media (pointer: coarse) {
          .game-canvas {
            width: 100vw;
            height: 100vh;
            object-fit: contain;
            max-width: 100vw;
            max-height: 100vh;
          }
        }
      `)
    )
  );
}
