# Stomper — Web Build

A no-build, no-compile conversion of the original Godot "Stomper" project to
Preact + `<canvas>`, running entirely as static files (Preact/htm are loaded
from a CDN at runtime — there's no npm install or bundler step).

## Running it

Browsers block `fetch()` and ES module loading from `file://` pages, so you
need to serve this folder over HTTP (any static server works):

```bash
# from inside this folder
python3 -m http.server 8000
# or
npx serve .
```

Then open `http://localhost:8000` (or whatever port/host your server prints).
Works on desktop Chrome/Firefox/Safari/Edge and on mobile Safari/Chrome (iOS
and Android) — including installing it as a home-screen app.

## Controls

- **Move:** Arrow keys / WASD, or the on-screen D-pad (touch or mouse)
- **Jump:** Space / Z / J, or the on-screen JUMP button
- **Duck / ground-pound:** Down (tap in mid-air to stomp, hold on the ground)
- **Dash-roll:** double-tap Left or Right (works the same way on the touch D-pad)
- **Duck-charge blast:** hold Down on the ground until it flashes, then press Jump
- **Wall jump:** Jump while sliding down a wall
- **Restart level:** R
- **Mute:** M
- **Pause:** Esc

## What this is

All 15 levels, tiles, and entity placements were parsed programmatically out
of the original `.tscn` scene files (not redrawn by hand), so the room
layouts, gem/enemy/hazard positions, and gem totals match the source project.
The physics constants (gravity, jump force, dash velocity, coyote time,
wall-jump impulse, etc.) and the state machine (Idle/Run/Air/Duck/Blast/Dash/
Stomp/WallJump/Hurt/Win) are ported 1:1 from the Godot `Player.gd` scripts.

## Folder layout

```
index.html          entry point
css/style.css        mobile-first layout, touch controls, HUD
js/                   engine (constants, world/collision, player state machine,
                       entities, level orchestration, renderer, input, audio, app)
assets/               sprites, spritesheets, audio (from the original project)
data/levels.json      parsed level geometry + entity placements (all 15 levels)
data/tileset.json     tileset regions + collision/one-way metadata
```

## Known simplifications vs. the original

- Crates (`Crate`) render as solid obstacles but aren't destructible — in the
  original Godot project the crate's `kill()` method exists but is never
  wired to any signal either, so this matches actual original behavior.
- Dropped-gem physics (arcs/bounces after an enemy dies) are a simplified
  approximation of Godot's RigidBody2D + bounce-material physics rather than
  a full physics-engine port.
- Enemy "kill" detection combines Godot's separate raycast-based and
  body-overlap-based checks into one unified per-frame hitbox test.
