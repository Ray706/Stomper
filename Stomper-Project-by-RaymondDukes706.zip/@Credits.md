# Credits and License

## Credits

- **WebSim project and level editor:** Raymond Dukes.
- **Stomper:** a short arcade-like game originally made by AnsiMuz.
- **Title-screen “STOMPER” text:** SomePx.
- Original Stomper code and sprite art are credited to AnsiMuz and are identified by the original project as public domain / CC0.

## CC0 1.0 Universal

Raymond Dukes dedicates the code and sprite assets made for this WebSim project, including its level editor, to the public domain under the [CC0 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/). The original Stomper code and sprite art are included under their original public-domain / CC0 dedication. This dedication does not change the authorship or attribution above.

To the extent the dedication is not legally effective, the applicable rights are waived to the fullest extent permitted by law. CC0 is provided without warranty; see the linked legal text for the complete terms.
