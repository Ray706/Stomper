import { TILE } from './constants.js';
import { TileGrid, Solid } from './world.js';
import { Player, bindPlayerAssets } from './player.js';
import {
  WalkingEnemy, FlyingEnemy, Gem, Door, Star, Spikes, SpikesBlock,
  ShootingBlock, Shot, SlipperyBlock, Crate, Brick, Box, KILL_STATE_SET,
} from './entities.js';
function aabbOverlap(ax, ay, ahw, ahh, bx, by, bhw, bhh) {
  return Math.abs(ax - bx) < (ahw + bhw) && Math.abs(ay - by) < (ahh + bhh);
}

export class Level {
  constructor(levelData, tilesetMeta, assets, audio, hooks) {
    this.data = levelData;
    this.tilesetMeta = tilesetMeta;
    this.assets = assets;
    this.audio = audio;
    this.hooks = hooks; // { onComplete, onRestartRequest }

    bindPlayerAssets(assets);

    this.grid = new TileGrid(levelData.tiles, tilesetMeta);
    this.gemsTaken = 0;
    this.maxGems = levelData.gems_total;
    this.starsTaken = 0;
    this.doorOpened = false;
    this.completed = false;
    this.completeTimer = 0;

    this.shakeAmount = 0;
    this.shakeTimer = 0;
    this.shakeOffset = { x: 0, y: 0 };

    this.enemies = [];
    this.gems = [];
    this.crates = [];
    this.bricks = [];
    this.boxes = [];
    this.shots = [];
    this.spikes = [];
    this.spikesBlocks = [];
    this.shootingBlocks = [];
    this.slipperyBlocks = [];
    this.effects = [];
    this.star = null;

    for (const e of levelData.entities) {
      switch (e.type) {
        case 'gem': this.gems.push(new Gem(e.x + 8, e.y + 8)); break;
        case 'star': this.star = new Star(e.x, e.y); break;
        case 'walkingEnemy': this.enemies.push(new WalkingEnemy(e.x, e.y, e)); break;
        case 'flyingEnemy': this.enemies.push(new FlyingEnemy(e.x, e.y, e)); break;
        case 'crate': this.crates.push(new Crate(e.x, e.y, e)); break;
        case 'box': this.boxes.push(new Box(e.x, e.y)); break;
        case 'spikes': this.spikes.push(new Spikes(e.x, e.y, e)); break;
        case 'spikesBlock': this.spikesBlocks.push(new SpikesBlock(e.x, e.y, e)); break;
        case 'shootingBlock': this.shootingBlocks.push(new ShootingBlock(e.x, e.y, e)); break;
        case 'slipperyBlock': this.slipperyBlocks.push(new SlipperyBlock(e.x, e.y)); break;
      }
    }

    this.door = levelData.door ? new Door(levelData.door.x, levelData.door.y) : null;
    this.player = new Player(levelData.player.x, levelData.player.y);

    this._extraSolidsCache = [];
    this.time = 0;
    this._rebuildSolids();
  }

  _rebuildSolids() {
    const arr = [];
    for (const c of this.crates) if (!c.dead) arr.push(new Solid(c.pos.x, c.pos.y, 16, 16, { owner: c }));
    for (const b of this.boxes) arr.push(new Solid(b.pos.x, b.pos.y, 16, 16, { owner: b }));
    for (const sb of this.spikesBlocks) arr.push(new Solid(sb.pos.x, sb.pos.y, 16, 16, { owner: sb }));
    for (const sh of this.shootingBlocks) arr.push(new Solid(sh.pos.x, sh.pos.y, 16, 16, { owner: sh }));
    for (const sl of this.slipperyBlocks) arr.push(new Solid(sl.pos.x, sl.pos.y, 16, 16, { owner: sl }));
    this._extraSolidsCache = arr;
    return arr;
  }

  get extraSolids() { return this._extraSolidsCache; }

  extraSolidsExcept(box) {
    return this._extraSolidsCache.filter(s => s.owner !== box);
  }

  groundBelow(x, y) {
    const cx = Math.floor(x / TILE), cy = Math.floor(y / TILE);
    if (this.grid.cellSolid(cx, cy)) return true;
    for (const s of this._extraSolidsCache) {
      if (x >= s.left && x <= s.right && y >= s.top && y <= s.bottom) return true;
    }
    return false;
  }

  wallAt(x, y) {
    const cx = Math.floor(x / TILE), cy = Math.floor(y / TILE);
    if (this.grid.cellSolid(cx, cy, { ignoreOneWay: true })) return true;
    for (const s of this._extraSolidsCache) {
      if (s.oneWay) continue;
      if (x >= s.left && x <= s.right && y >= s.top && y <= s.bottom) return true;
    }
    return false;
  }

  isSlipperyAt(x, y) {
    for (const sl of this.slipperyBlocks) {
      if (Math.abs(x - sl.pos.x) < 8 && Math.abs(y - sl.pos.y) < 9) return true;
    }
    return false;
  }

  spawnEffect(kind, x, y) {
    const map = {
      jumpDust: { sheet: 'jumpDust', dur: 0.1, oy: -8 },
      landDust: { sheet: 'landDust', dur: 0.1, oy: -7 },
      stompDust: { sheet: 'stompDust', dur: 0.1, oy: -17 },
      walkDust: { sheet: 'walkDust', dur: 0.1, oy: -8 },
      trace: { sheet: null, dur: 0.5, oy: -8 },
    };
    const cfg = map[kind];
    if (!cfg) return;
    if (kind === 'trace') {
      this.effects.push({ kind: 'trace', x, y, t: 0, dur: 0.5 });
      return;
    }
    const sheet = this.assets.sheet(cfg.sheet);
    this.effects.push(new TimedEffectWrap(x, y, sheet, cfg.dur, cfg.oy));
  }

  screenshake(amount, duration) {
    this.shakeAmount = amount;
    this.shakeTimer = duration;
    this.audio.play('stomp');
  }

  reloadLevel() {
    if (this.hooks.onRestartRequest) this.hooks.onRestartRequest();
  }

  addGem(value) {
    this.gemsTaken = Math.max(0, Math.min(this.maxGems, this.gemsTaken + value));
    if (this.hooks.onGemsChanged) this.hooks.onGemsChanged(this.gemsTaken, this.maxGems);
    if (this.gemsTaken >= this.maxGems && !this.doorOpened) {
      this.doorOpened = true;
      if (this.door) this.door.setOpen();
    }
  }

  spawnGemsAt(x, y, count) {
    const hor = 70;
    const positions = [[-hor, -40], [hor, -40], [0, -100]].slice(0, count);
    // Spawn above the entity's feet/center so the gem's 16px box doesn't start
    // overlapping a solid tile — an overlap plus the upward throw impulse makes
    // the first collision frame treat the floor as a ceiling and sink the gem.
    for (const [dx, dy] of positions) this._dropGem(x, y - 16, dx, dy);
  }

  spawnPlayerGems(x, y, count) {
    const hor = 70, dia = 35;
    const table = [
      [-hor, -40], [hor, -40], [-dia, -80], [dia, -80],
      [-hor, -60], [hor, -60], [-40, -95], [40, -95],
      [0, -100], [60, -100], [-60, -100], [50, -90], [-50, -90],
      [20, -95], [-20, -95], [10, -96], [-10, -96], [22, -60], [-22, -60], [0, -150],
    ];
    for (let i = 0; i < Math.min(count, table.length); i++) {
      const [dx, dy] = table[i];
      this._dropGem(x, y - 24, dx, dy);
    }
  }

  _dropGem(x, y, dx, dy) {
    const g = new Gem(x, y, { dropped: true, impulse: { x: dx, y: dy } });
    this.gems.push(g);
  }

  spawnBricks(x, y) {
    const offsets = [[-4, -8, -1], [4, -8, 1], [-4, 4, -1], [4, 4, 1]];
    for (const [dx, dy, rot] of offsets) this.bricks.push(new Brick(x + dx, y + dy, rot));
  }

  spawnShot(x, y, speed) {
    this.shots.push(new Shot(x, y, speed));
  }

  tryPushBox(player, moveResult) {
    if (!(moveResult.onWallLeft || moveResult.onWallRight)) return;
    for (const b of this.boxes) {
      if (b.pos.y >= player.pos.y) continue; // must be a box we're pushing into, roughly level
      const dx = Math.abs(player.pos.x - b.pos.x);
      if (dx < 8 + player.hw + 2) {
        b.push(player.facing);
      }
    }
  }

  // ---------------- main update ----------------
  update(dt, input) {
    this.time += dt;
    this._rebuildSolids();

    if (this.shakeTimer > 0) {
      this.shakeTimer -= dt;
      if (this.shakeTimer <= 0) { this.shakeTimer = 0; this.shakeAmount = 0; }
    }
    this.shakeOffset.x = this.shakeAmount ? (Math.random() * 2 - 1) * this.shakeAmount : 0;
    this.shakeOffset.y = this.shakeAmount ? (Math.random() * 2 - 1) * this.shakeAmount : 0;

    const ctx = this;
    this.player.update(dt, input, ctx);

    for (const en of this.enemies) en.update(dt, ctx);
    for (const g of this.gems) g.update(dt, ctx);
    for (const sb of this.spikesBlocks) sb.update(dt);
    for (const sh of this.shootingBlocks) sh.update(dt, ctx);
    for (const s of this.shots) s.update(dt, ctx);
    for (const b of this.boxes) b.update(dt, ctx);
    for (const br of this.bricks) br.update(dt);
    if (this.door) this.door.update(dt, ctx);
    if (this.star) this.star.update(dt, ctx);
    for (const ef of this.effects) {
      if (ef.kind === 'trace') ef.t += dt;
      else ef.update(dt);
    }

    this._resolveCollisions();
    this._cleanup();

    if (this.doorOpened && this.door && !this.completed) {
      if (aabbOverlap(this.player.pos.x, this.player.pos.y - 6, this.player.hw, this.player.hh,
        this.door.pos.x, this.door.pos.y, this.door.hw, this.door.hh)) {
        this.completed = true;
        this.player.levelPassed = true;
        this.audio.play('door');
        if (this.hooks.onComplete) this.hooks.onComplete();
      }
    }
  }

  _playerAttackBoxes() {
    const p = this.player;
    const boxes = [];
    // baseline body hitbox (always active)
    boxes.push({ x: p.pos.x, y: p.pos.y - 6, hw: 6, hh: 7, kill: KILL_STATE_SET.has(p.state) });
    if (p.attack.right) boxes.push({ x: p.pos.x + 9.5, y: p.pos.y - 6, hw: 3.5, hh: 2, kill: true });
    if (p.attack.left) boxes.push({ x: p.pos.x - 9.5, y: p.pos.y - 6, hw: 3.5, hh: 2, kill: true });
    if (p.attack.down) boxes.push({ x: p.pos.x, y: p.pos.y + 3.5, hw: 4, hh: 2.5, kill: true });
    if (p.attack.up) boxes.push({ x: p.pos.x, y: p.pos.y - 15, hw: 4, hh: 2.5, kill: true });
    return boxes;
  }

  _resolveCollisions() {
    const p = this.player;
    const attackBoxes = this._playerAttackBoxes();

    // Player vs enemies
    for (const en of this.enemies) {
      if (!en.alive || en.respawning) continue;
      let hitByAttack = false;
      for (const box of attackBoxes) {
        if (!box.kill) continue;
        if (aabbOverlap(box.x, box.y, box.hw, box.hh, en.pos.x, en.pos.y, en.hw, en.hh)) { hitByAttack = true; break; }
      }
      const bodyOverlap = aabbOverlap(p.pos.x, p.pos.y - 6, 6, 7, en.pos.x, en.pos.y, en.hw, en.hh);
      if (!bodyOverlap && !hitByAttack) continue;
      if (p.state === 'duck') continue;
      if (hitByAttack) {
        en.kill(this);
      } else if (p.vel.y > 0 && !en.stunt) {
        p.onHit(this);
        en.applyStunt();
      } else if (!p.invincible && !en.stunt) {
        p.hurt(this);
      }
    }

    // Player attack vs breakable crates
    for (const c of this.crates) {
      if (c.dead) continue;
      for (const box of attackBoxes) {
        if (!box.kill) continue;
        if (aabbOverlap(box.x, box.y, box.hw, box.hh, c.pos.x, c.pos.y, c.hw, c.hh)) {
          c.kill(this);
          break;
        }
      }
    }

    // Player vs gems
    for (const g of this.gems) {
      if (g.dead || !g.collectible) continue;
      if (aabbOverlap(p.pos.x, p.pos.y - 6, 6, 7, g.pos.x, g.pos.y, g.hw, g.hh)) {
        g.dead = true;
        this.addGem(1);
        this.audio.play('pick');
        this.effects.push(new TimedEffectWrap(g.pos.x, g.pos.y, this.assets.sheet('gemFeedback'), 0.07, -8));
      }
    }

    // Player vs star
    if (this.star) {
      if (aabbOverlap(p.pos.x, p.pos.y - 6, 6, 7, this.star.pos.x, this.star.pos.y, this.star.hw, this.star.hh)) {
        this.starsTaken++;
        this.audio.play('door');
        this.star = null;
      }
    }

    // Player vs spikes (always-on hazard)
    for (const s of this.spikes) {
      if (p.invincible) continue;
      if (aabbOverlap(p.pos.x, p.pos.y - 6, 6, 7, s.pos.x, s.pos.y, s.hw, s.hh)) p.hurt(this);
    }

    // Player vs spikes blocks (retracting hazard)
    for (const sb of this.spikesBlocks) {
      if (!sb.out || p.invincible) continue;
      const hb = sb.hazardBox();
      if (aabbOverlap(p.pos.x, p.pos.y - 6, 6, 7, hb.x, hb.y, hb.hw, hb.hh)) p.hurt(this);
    }

    // Shots vs player
    for (const s of this.shots) {
      if (s.dead) continue;
      if (aabbOverlap(p.pos.x, p.pos.y - 6, 6, 7, s.pos.x, s.pos.y, s.hw, s.hh)) {
        if (p.state === 'duck') continue; // ducking lets shots fly over
        if (!p.invincible) p.hurt(this);
        s.dead = true;
        this.effects.push(new TimedEffectWrap(s.pos.x, s.pos.y, this.assets.sheet('hitFeedback'), 0.07, 0));
      }
    }
  }

  _cleanup() {
    this.gems = this.gems.filter(g => !g.dead);
    this.enemies = this.enemies.filter(e => !e.dead);
    this.crates = this.crates.filter(c => !c.dead);
    this.bricks = this.bricks.filter(b => !b.dead);
    this.shots = this.shots.filter(s => !s.dead);
    this.effects = this.effects.filter(ef => ef.kind === 'trace' ? ef.t < ef.dur : !ef.dead);
  }
}

class TimedEffectWrap {
  constructor(x, y, sheet, frameDur, offsetY) {
    this.kind = 'sheet';
    this.x = x; this.y = y;
    this.sheet = sheet;
    this.frameDur = frameDur;
    this.offsetY = offsetY;
    this.t = 0;
    this.dead = false;
  }
  update(dt) {
    this.t += dt;
    if (this.t >= this.frameDur * this.sheet.hframes) this.dead = true;
  }
  frameIndex() {
    return Math.min(this.sheet.hframes - 1, Math.floor(this.t / this.frameDur));
  }
}
