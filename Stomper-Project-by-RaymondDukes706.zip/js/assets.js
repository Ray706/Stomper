// Central asset manifest + loader. Everything is plain PNG/WAV/OGG, no build step.

const A = 'assets/';

// Single-frame-per-file animations: list of individual image paths.
export const SEQ = {
  playerRun: [1,2,3,4,5,6,7,8,9,10].map(n => `${A}player/run/run${n}.png`),
  playerRoll: [1,2,3].map(n => `${A}player/roll/Roll${n}.png`),
  playerIdle: [`${A}player/run/run9.png`],
  playerJump: [`${A}player/air/Jump.png`],
  playerFall: [`${A}player/air/fall.png`],
  playerWall: [`${A}player/wall.png`],
  playerDuck: [`${A}player/duck/duck.png`],
  playerDuckCharged: [`${A}player/duck/duck2.png`, `${A}player/duck/duck.png`],

  walkerWalk: [1,2,3,4].map(n => `${A}enemies/walking/walk${n}.png`),
  walkerStunt: [1,2].map(n => `${A}enemies/walking/stunt${n}.png`),

  flyerFly: [1,2,3,4].map(n => `${A}enemies/flying/flying${n}.png`),
  flyerStunt: [1,2].map(n => `${A}enemies/flying/stunt${n}.png`),

  gemSpin: [1,2,3,4,5,6].map(n => `${A}gems/gem${n}.png`),

  doorActive: [1,2,3,4].map(n => `${A}door/active${n}.png`),
  doorOff: [`${A}door/door.png`],

  star: [1,2,3,4,1,1,1,1,1,1].map(n => `${A}star/zaphire${n}.png`),

  shoot: [1,2,3].map(n => `${A}misc/shoot/shoot${n}.png`),
};

// Spritesheets: single image sliced into N horizontal frames.
export const SHEET = {
  jumpDust: { src: `${A}fx/jump-dust.png`, hframes: 4 },
  landDust: { src: `${A}fx/land-dust.png`, hframes: 5 },
  stompDust: { src: `${A}fx/stomp-dust-sheet.png`, hframes: 4 },
  walkDust: { src: `${A}fx/walk-dust.png`, hframes: 3 },
  gemFeedback: { src: `${A}fx/gem-feedback.png`, hframes: 3 },
  hitFeedback: { src: `${A}fx/hit.png`, hframes: 3 },
  spikes: { src: `${A}misc/spikes.png`, hframes: 2 },
  spikesBlockHead: { src: `${A}misc/shooting-head.png`, hframes: 2 }, // placeholder unused
  shootingHead: { src: `${A}misc/shooting-head.png`, hframes: 2 },
};

export const IMG = {
  tileset: `${A}tiles/tileset.png`,
  trace: `${A}fx/trace.png`,
  spikeBlock: `${A}misc/spike-block.png`,
  slimeBlock: `${A}misc/slime-block.png`,
  brick: `${A}misc/brick.png`,
  box: `${A}misc/box.png`,
  plant: `${A}misc/plant.png`,
  bg1: `${A}bg/back-animated1.png`,
  bg2: `${A}bg/back-animated2.png`,
  bg3: `${A}bg/back-animated3.png`,
  title: `${A}ui/title.png`,
  button: `${A}ui/button.png`,
};

export const SND = {
  jump: `${A}audio/jump.wav`,
  hurt: `${A}audio/hurt.wav`,
  pick: `${A}audio/pick.wav`,
  stomp: `${A}audio/stomp.wav`,
  enemyDeath: `${A}audio/enemy_death.wav`,
  attack: `${A}audio/attack.wav`,
  door: `${A}audio/door.wav`,
  hit: `${A}audio/hit.wav`,
  bgm: `${A}audio/musicbox.ogg`,
};

// Music fallback for browsers that can't play Ogg Vorbis (Safari/iOS).
export const BGM_WAV = `${A}audio/musicbox.wav`;

function loadImage(src) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(img); // don't hard-fail the whole boot on one bad asset
    img.src = src;
  });
}

export class Assets {
  constructor() {
    this.images = new Map(); // path -> HTMLImageElement
    this.sheets = new Map(); // key -> {img, hframes, fw, fh}
    this.sequences = new Map(); // key -> HTMLImageElement[]
    this.sounds = new Map(); // key -> HTMLAudioElement[] (small pool)
  }

  async loadAll(onProgress) {
    const jobs = [];
    let done = 0;
    const bump = () => { done++; if (onProgress) onProgress(done, total); };

    const allImagePaths = new Set([IMG.tileset, IMG.trace, IMG.spikeBlock, IMG.slimeBlock,
      IMG.brick, IMG.box, IMG.plant, IMG.bg1, IMG.bg2, IMG.bg3, IMG.title, IMG.button]);
    for (const key in SHEET) allImagePaths.add(SHEET[key].src);
    for (const key in SEQ) for (const p of SEQ[key]) allImagePaths.add(p);

    const total = allImagePaths.size + Object.keys(SND).length + 1;

    for (const path of allImagePaths) {
      jobs.push(loadImage(path).then(img => { this.images.set(path, img); bump(); }));
    }
    const preloadSound = (key, src) => new Promise((resolve) => {
      const a = new Audio();
      a.src = src;
      a.preload = 'auto';
      const finish = () => { this.sounds.set(key, a); bump(); resolve(); };
      a.addEventListener('canplaythrough', finish, { once: true });
      a.addEventListener('error', finish, { once: true });
      // Safety net in case canplaythrough never fires (some mobile browsers)
      setTimeout(finish, 3000);
    });
    for (const key in SND) {
      jobs.push(preloadSound(key, SND[key]));
    }
    jobs.push(preloadSound('bgmWav', BGM_WAV));

    await Promise.all(jobs);

    for (const key in SHEET) {
      const { src, hframes } = SHEET[key];
      const img = this.images.get(src);
      this.sheets.set(key, { img, hframes, fw: img.naturalWidth / hframes, fh: img.naturalHeight });
    }
    for (const key in SEQ) {
      this.sequences.set(key, SEQ[key].map(p => this.images.get(p)));
    }
  }

  img(path) { return this.images.get(path); }
  seq(key) { return this.sequences.get(key); }
  sheet(key) { return this.sheets.get(key); }
}
