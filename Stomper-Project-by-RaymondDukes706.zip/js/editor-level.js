// Level-editor data model. A "draft" mirrors the data/levels.json entry format:
// { tiles: [x, y, tileId][], entities: [{type, x, y, ...}], props: [{x, y, flip_h}],
//   labels: [], player: {x, y} | null, door: {x, y} | null, gems_total: n }
// Internally every entity keeps its coordinates as stored in levels.json; the
// cell it occupies is derived with a per-type rule (top-left for grid objects,
// centre-spawn for characters). All functions mutate the draft in place — the
// editor canvas re-reads it every frame.

export const COLS = 20;
export const ROWS = 15;
export const CELL = 16;

// Character origins are a spawn point/feet baseline rather than a cell corner.
const CENTER_TYPES = new Set(['walkingEnemy', 'flyingEnemy', 'player', 'door']);

export function isCenterType(type) {
  return CENTER_TYPES.has(type);
}

export function cellOf(type, x, y) {
  if (CENTER_TYPES.has(type)) {
    return [Math.round((x - CELL / 2) / CELL), Math.round((y - CELL / 2) / CELL)];
  }
  return [Math.floor(x / CELL), Math.floor(y / CELL)];
}

export function entityCell(e) {
  return cellOf(e.type, e.x, e.y);
}

// World-space coordinates used when placing an entity into a cell.
export function coordsFor(type, cx, cy) {
  if (CENTER_TYPES.has(type)) return { x: cx * CELL + CELL / 2, y: cy * CELL + CELL / 2 };
  return { x: cx * CELL, y: cy * CELL };
}

export function blankLevel() {
  return {
    tiles: [],
    entities: [],
    props: [],
    labels: [],
    player: { x: 160, y: 176 },
    door: null,
    gems_total: 0,
  };
}

export function deepCopy(d) {
  return JSON.parse(JSON.stringify(d));
}

export function clampCell(cx, cy) {
  return [Math.max(0, Math.min(COLS - 1, cx)), Math.max(0, Math.min(ROWS - 1, cy))];
}

export function tileAt(draft, cx, cy) {
  for (const t of draft.tiles) if (t[0] === cx && t[1] === cy) return t[2];
  return null;
}

export function entitiesAt(draft, cx, cy, type) {
  return draft.entities.filter((e) => {
    if (type && e.type !== type) return false;
    const [x, y] = entityCell(e);
    return x === cx && y === cy;
  });
}

export function propsAt(draft, cx, cy) {
  return draft.props.filter((p) => Math.floor(p.x / CELL) === cx && Math.floor(p.y / CELL) === cy);
}

export function playerAt(draft, cx, cy) {
  if (!draft.player) return false;
  const [x, y] = cellOf('player', draft.player.x, draft.player.y);
  return x === cx && y === cy;
}

export function doorAt(draft, cx, cy) {
  if (!draft.door) return false;
  const [x, y] = cellOf('door', draft.door.x, draft.door.y);
  return x === cx && y === cy;
}

// ---- painting ----

export function setTileAt(draft, cx, cy, tileId) {
  for (let i = 0; i < draft.tiles.length; i++) {
    if (draft.tiles[i][0] === cx && draft.tiles[i][1] === cy) {
      if (tileId == null) draft.tiles.splice(i, 1);
      else draft.tiles[i][2] = tileId;
      return;
    }
  }
  if (tileId != null) draft.tiles.push([cx, cy, tileId]);
}

export function eraseAt(draft, cx, cy) {
  setTileAt(draft, cx, cy, null);
  draft.entities = draft.entities.filter((e) => {
    const [x, y] = entityCell(e);
    return !(x === cx && y === cy);
  });
  draft.props = draft.props.filter((p) => !(Math.floor(p.x / CELL) === cx && Math.floor(p.y / CELL) === cy));
  if (playerAt(draft, cx, cy)) draft.player = null;
  if (doorAt(draft, cx, cy)) draft.door = null;
}

export function paintEntity(draft, type, cx, cy, opts = {}) {
  cx = Math.max(0, Math.min(COLS - 1, cx));
  cy = Math.max(0, Math.min(ROWS - 1, cy));
  const at = coordsFor(type, cx, cy);
  if (type === 'player') {
    draft.player = { x: at.x, y: at.y };
    return;
  }
  if (type === 'door') {
    draft.door = { x: at.x, y: at.y };
    return;
  }
  draft.entities = draft.entities.filter((e) => {
    if (e.type !== type) return true;
    const [x, y] = entityCell(e);
    return !(x === cx && y === cy);
  });
  const e = { type, x: at.x, y: at.y };
  if (type === 'walkingEnemy' || type === 'flyingEnemy') {
    e.direction = opts.flip ? -1 : 1;
    e.respawnable = !!opts.respawnable;
  }
  if (type === 'spikes' || type === 'spikesBlock') e.flip = !!opts.flip;
  if (type === 'shootingBlock') e.shoot_speed = opts.flip ? 1.5 : -1.5;
  if (type === 'crate') e.gems_spawn_number = opts.gems ?? 3;
  draft.entities.push(e);
}

export function paintProp(draft, cx, cy, opts = {}) {
  cx = Math.max(0, Math.min(COLS - 1, cx));
  cy = Math.max(0, Math.min(ROWS - 1, cy));
  draft.props = draft.props.filter((p) => !(Math.floor(p.x / CELL) === cx && Math.floor(p.y / CELL) === cy));
  draft.props.push({ x: cx * CELL, y: cy * CELL, flip_h: !!opts.flip });
}

export function moveEntityTo(draft, e, cx, cy) {
  cx = Math.max(0, Math.min(COLS - 1, cx));
  cy = Math.max(0, Math.min(ROWS - 1, cy));
  const at = coordsFor(e.type, cx, cy);
  e.x = at.x;
  e.y = at.y;
  return e;
}

export function countGems(draft) {
  return draft.entities.filter((e) => e.type === 'gem').length;
}

// ---- serialize / parse ----

const round1 = (n) => Math.round(n * 10) / 10;

export function serialize(draft) {
  const tiles = draft.tiles
    .filter((t) => t && t.length >= 3)
    .map((t) => [Math.floor(t[0]), Math.floor(t[1]), Math.floor(t[2])])
    .sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const entities = draft.entities.filter((e) => e && e.type).map((e) => {
    const c = { type: e.type, x: round1(e.x), y: round1(e.y) };
    if (e.direction != null) c.direction = e.direction;
    if (e.respawnable != null) c.respawnable = !!e.respawnable;
    if (e.flip != null) c.flip = !!e.flip;
    if (e.shoot_speed != null) c.shoot_speed = e.shoot_speed;
    if (e.gems_spawn_number != null) c.gems_spawn_number = e.gems_spawn_number;
    return c;
  });
  const props = draft.props.filter((p) => p).map((p) => ({ x: round1(p.x), y: round1(p.y), flip_h: !!p.flip_h }));
  const out = {
    gems_total: entities.filter((e) => e.type === 'gem').length,
    tiles,
    entities,
    props,
    labels: [],
    player: draft.player ? { x: round1(draft.player.x), y: round1(draft.player.y) } : { x: 160, y: 176 },
  };
  if (draft.door) out.door = { x: round1(draft.door.x), y: round1(draft.door.y) };
  return out;
}

export function parseLevel(input) {
  let obj = typeof input === 'string' ? JSON.parse(input) : input;
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) throw new Error('Not a valid level object.');
  if (!Array.isArray(obj.tiles)) {
    const key = Object.keys(obj).find((k) => obj[k] && Array.isArray(obj[k].tiles));
    if (!key) throw new Error('Level data has no "tiles" array.');
    obj = obj[key];
  }
  if (!Array.isArray(obj.tiles)) throw new Error('Level data has no "tiles" array.');
  if (obj.entities != null && !Array.isArray(obj.entities)) throw new Error('Invalid "entities" field.');

  const draft = blankLevel();
  draft.tiles = obj.tiles
    .filter((t) => Array.isArray(t) && t.length >= 3 && Number.isFinite(t[0]) && Number.isFinite(t[1]) && Number.isFinite(t[2]))
    .map((t) => [Math.floor(t[0]), Math.floor(t[1]), Math.floor(t[2])])
    .filter((t) => t[0] >= 0 && t[0] < COLS && t[1] >= 0 && t[1] < ROWS);

  for (const e of obj.entities || []) {
    if (!e || !e.type || !Number.isFinite(e.x) || !Number.isFinite(e.y)) continue;
    const c = { type: e.type, x: e.x, y: e.y };
    if (e.direction != null) c.direction = e.direction;
    if (e.respawnable != null) c.respawnable = !!e.respawnable;
    if (e.flip != null) c.flip = !!e.flip;
    if (e.shoot_speed != null) c.shoot_speed = e.shoot_speed;
    if (e.gems_spawn_number != null) c.gems_spawn_number = e.gems_spawn_number;
    if (e.type === 'player') draft.player = { x: e.x, y: e.y };
    else if (e.type === 'door') draft.door = { x: e.x, y: e.y };
    else draft.entities.push(c);
  }

  draft.props = Array.isArray(obj.props)
    ? obj.props.filter((p) => p && Number.isFinite(p.x) && Number.isFinite(p.y)).map((p) => ({ x: p.x, y: p.y, flip_h: !!p.flip_h }))
    : [];

  if (obj.player && Number.isFinite(obj.player.x) && Number.isFinite(obj.player.y)) {
    draft.player = { x: obj.player.x, y: obj.player.y };
  }
  if (obj.door && Number.isFinite(obj.door.x) && Number.isFinite(obj.door.y)) {
    draft.door = { x: obj.door.x, y: obj.door.y };
  }
  draft.gems_total = countGems(draft);
  return draft;
}
