import { PLAYER, PLAYER_GEOM } from './constants.js';
import { Anim } from './anim.js';
import { moveAABB, screenWrap } from './world.js';

const P = PLAYER;

export class Player {
  constructor(x, y) {
    this.pos = { x, y };
    this.vel = { x: 0, y: 0 };
    this.facing = 1;
    this.state = 'idle';
    this.grounded = false;
    this.invincible = false;
    this.invincibleCounter = 0;
    this.hidden = false;
    this.levelPassed = false;
    this.coyoteTimer = 0;
    this.dashJumpTimer = 0;
    this.attack = { left: false, right: false, up: false, down: false };
    this.anim = new Anim();
    this.hw = 5; this.hh = 6;
    this.wallDirection = 0;

    // per-state scratch variables
    this.s = {
      dashFlag: false, keyTime: 0, dashLastDirection: 1, lastDirection: 1,
      duckCount: 0, dustCounter: 0, wallDustCounter: 0, traceCounter: 0,
      blastInitY: 0, dashCount: 0,
    };
    this._lastMove = { onFloor: false };
    this._enterState('idle', {});
  }

  // ----- shared helpers (ported from Player.gd) -----
  getInputVector(input) { return input.axisX; }

  applyHorizontalForce(ax, dt) {
    const accel = this.grounded ? P.ACCELERATION : P.AIR_ACCELERATION;
    this.vel.x += ax * accel * dt;
    this.vel.x = Math.max(-P.MAX_SPEED_X, Math.min(P.MAX_SPEED_X, this.vel.x));
  }

  applyFriction(ax, world) {
    if (world.isSlipperyAt(this.pos.x, this.pos.y + 3)) return;
    if (ax === 0) this.vel.x = lerp(this.vel.x, 0, P.FRICTION);
  }

  applyGravity(dt) {
    if (this.vel.y > 0) this.vel.y += (P.GRAVITY + 200) * dt;
    else this.vel.y += P.GRAVITY * dt;
    this.vel.y = Math.max(-P.MAX_SPEED_Y, Math.min(P.MAX_SPEED_Y, this.vel.y));
  }

  applyGravityWall(dt) {
    this.vel.y += P.GRAVITY_WALL * dt;
    this.vel.y = Math.max(-20, Math.min(20, this.vel.y));
  }

  jumpCheck(input, world) {
    if (this.grounded) {
      if (input.jumpJustPressed) { this.vel.y = -P.JUMP_FORCE; world.audio.play('jump'); }
    } else if (input.jumpJustReleased && this.vel.y < -P.JUMP_FORCE / 2) {
      this.vel.y = -P.JUMP_FORCE / 2;
    }
  }

  bounce() { this.vel.y = -P.JUMP_FORCE; }

  checkGrounded(world) {
    if (this.vel.y < 0) return false;
    // Prefer the real collision result from the last move — it only reports a
    // floor when the collider actually rests on a solid from above, so a wall
    // beside the player (pointing down the side of a blast/dash) can't read as
    // ground and snap an airborne player into the idle state.
    if (this._lastMove && this._lastMove.onFloor) return true;
    // Fallback: ground rays for the exact-touch case where the collider isn't
    // penetrating a floor (e.g. a state that skips gravity). Sample strictly
    // inside the collider so a beside-wall can't be mistaken for floor.
    const feetY = this.pos.y - 1 + 4; // ray origin y=-1 rel to origin, cast 4 down
    const maxDx = Math.max(0, this.hw - 1);
    for (const dx of PLAYER_GEOM.groundRays) {
      const x = this.pos.x + Math.max(-maxDx, Math.min(maxDx, dx));
      if (world.groundBelow(x, feetY)) return true;
    }
    return false;
  }

  move(world, dt) {
    // this.pos is the feet baseline (matches the original Godot node origin);
    // the collision box is centered 6px above that, per the RectangleShape2D offset.
    const center = { x: this.pos.x, y: this.pos.y - 6 };
    const r = moveAABB(world.grid, world.extraSolids, center, this.vel, this.hw, this.hh, dt);
    this.pos.x = center.x;
    this.pos.y = center.y + 6;
    this._lastMove = r;
    return r;
  }

  wrapAround() { screenWrap(this.pos); }

  invincibleController(dt) {
    if (!this.invincible) { this.hidden = false; return; }
    this.invincibleCounter++;
    if (this.invincibleCounter % 7 === 0) this.hidden = !this.hidden;
    if (this.invincibleCounter > P.INVINCIBLE_MAX) {
      this.invincibleCounter = 0;
      this.invincible = false;
      this.hidden = false;
    }
  }

  makeInvincible() { this.invincible = true; this.invincibleCounter = 0; }

  onHit(world) { // Enemy touched from above (soft, non-attack contact)
    if (this.vel.y > 10) { this.bounce(); world.audio.play('hit'); }
  }

  hurt(world) {
    this._transition('hurt', {}, world);
  }

  // ----- top-level update -----
  update(dt, input, world) {
    this.wrapAround();
    this.invincibleController(dt);

    if (this.coyoteTimer > 0) this.coyoteTimer -= dt;
    if (this.dashJumpTimer > 0) this.dashJumpTimer -= dt;

    if (input.reloadJustPressed) { world.reloadLevel(); return; }

    STATES[this.state].update(this, dt, input, world);
    this.anim.update(dt);
  }

  _enterState(name, msg, world) {
    this.state = name;
    const st = STATES[name];
    if (st.enter) st.enter(this, msg || {}, world);
  }

  _transition(name, msg, world) {
    const cur = STATES[this.state];
    if (cur.exit) cur.exit(this, world);
    this._enterState(name, msg || {}, world);
  }
}

function lerp(a, b, t) { return a + (b - a) * t; }

const EFFECT_NAMES = { jump: 'jumpDust', land: 'landDust', stomp: 'stompDust', walk: 'walkDust' };

function makeDust(world, kind, x, y) { world.spawnEffect(EFFECT_NAMES[kind], x, y); }
function makeTrace(world, p) { world.spawnEffect('trace', p.pos.x, p.pos.y); }

// ---------------- STATES ----------------
const STATES = {};

STATES.idle = {
  enter(p, msg) {
    p.anim.play('idle', worldSeq(p, 'playerIdle'), 5);
    p.s.dashFlag = false;
    if (msg && msg.time !== undefined) {
      if (msg.time > 90) {
        p.s.dashFlag = true;
        p.s.dashLastDirection = msg.direction;
        p.s.keyTime = 100;
      }
    }
  },
  update(p, dt, input, world) {
    if (p.levelPassed) { p._transition('win', {}, world); return; }
    const ax = p.getInputVector(input);
    if (p.s.dashFlag && ax !== 0 && p.s.keyTime > 80 && ax === p.s.dashLastDirection) {
      p._transition('dash', { direction: ax }, world);
      return;
    }
    if (ax !== 0) { p._transition('run', {}, world); return; }
    p.applyFriction(ax, world);
    p.applyGravity(dt);
    p.jumpCheck(input, world);
    p.move(world, dt);
    p.grounded = p.checkGrounded(world);
    if (!p.grounded) { p._transition('air', {}, world); return; }
    if (input.down) { p._transition('duck', {}, world); return; }
    p.s.keyTime -= 1;
    p.anim.play('idle', worldSeq(p, 'playerIdle'), 5);
  },
};

STATES.run = {
  enter(p) {
    p.anim.play('run', worldSeq(p, 'playerRun'), 20);
    p.s.keyTime = 100;
  },
  update(p, dt, input, world) {
    if (p.levelPassed) { p._transition('win', {}, world); return; }
    p.s.dustCounter++;
    if (p.s.dustCounter >= 30) { p.s.dustCounter = 0; makeDust(world, 'walk', p.pos.x + (Math.random() * 6 - 3), p.pos.y); }

    const ax = p.getInputVector(input);
    if (ax === 0) { p._transition('idle', { time: p.s.keyTime, direction: p.s.lastDirection }, world); return; }
    p.applyHorizontalForce(ax, dt);
    p.applyFriction(ax, world);
    p.jumpCheck(input, world);
    p.applyGravity(dt);
    const r = p.move(world, dt);
    world.tryPushBox(p, r);
    if (ax !== 0) { p.facing = ax; p.s.lastDirection = ax; }
    p.grounded = p.checkGrounded(world);
    if (!p.grounded) { p._transition('air', {}, world); return; }
    p.s.keyTime -= 1;
    p.anim.play('run', worldSeq(p, 'playerRun'), 20);
  },
};

STATES.air = {
  enter(p, msg, world) {
    p.s.wallDirection = 0;
    p.s.airDustCounter = 0;
    if (p.vel.y > 0) p.coyoteTimer = P.COYOTE_TIME;
    if (p.vel.y < -110 && world) makeDust(world, 'jump', p.pos.x, p.pos.y);
  },
  update(p, dt, input, world) {
    const ax = p.getInputVector(input);
    p.applyHorizontalForce(ax, dt);
    p.applyFriction(ax, world);

    if (p.s.wallDirection !== 0 && p.vel.y > 0) {
      p.applyGravityWall(dt);
      p.s.airDustCounter = (p.s.airDustCounter || 0) + 1;
      if (p.s.airDustCounter >= 5) { p.s.airDustCounter = 0; makeDust(world, 'walk', p.pos.x + (Math.random() * 6 - 3), p.pos.y + (Math.random() * 11 - 15)); }
    } else {
      p.applyGravity(dt);
    }

    if (p.coyoteTimer > 0 && input.jumpJustPressed) p.vel.y = -P.JUMP_FORCE;

    p.s.wallDirection = -(world.wallAt(p.pos.x - 6, p.pos.y - 6) ? 1 : 0) + (world.wallAt(p.pos.x + 6, p.pos.y - 6) ? 1 : 0);

    if (p.s.wallDirection !== 0 && input.jumpJustPressed) {
      p.vel.y = P.WALL_JUMP_V;
      const hx = p.s.wallDirection === 1 ? -P.WALL_JUMP_H : P.WALL_JUMP_H;
      p._transition('walljump', { x: hx }, world);
      return;
    }
    if (input.jumpJustReleased && p.vel.y < -P.JUMP_FORCE / 2) p.vel.y = -P.JUMP_FORCE / 2;
    if (input.downJustPressed) { p._transition('stomp', {}, world); return; }

    if (p.vel.y < 0) p.anim.play('jump', worldSeq(p, 'playerJump'), 5);
    else if (p.s.wallDirection === 0) p.anim.play('fall', worldSeq(p, 'playerFall'), 5);
    else { p.anim.play('wall', worldSeq(p, 'playerWall'), 5); p.facing = p.s.wallDirection * -1; }

    p.move(world, dt);
    p.grounded = p.checkGrounded(world);
    if (p.grounded) {
      makeDust(world, 'land', p.pos.x, p.pos.y);
      p._transition('idle', {}, world);
    }
  },
  exit() {},
};

STATES.duck = {
  enter(p) {
    p.vel.x = 0; p.vel.y = 0;
    p.anim.play('duck', worldSeq(p, 'playerDuck'), 5);
    p.s.duckCount = 0;
  },
  update(p, dt, input, world) {
    p.grounded = p.checkGrounded(world);
    if (p.grounded && input.down) p.s.duckCount += 1;
    else if (!p.grounded) p.s.duckCount = 0;
    if (input.downJustReleased) { p._transition('idle', {}, world); return; }
    if (p.s.duckCount > P.DUCK_CHARGE_FRAMES && input.jumpJustPressed) { p._transition('blast', {}, world); return; }
    if (p.s.duckCount >= P.DUCK_CHARGE_FRAMES) p.anim.play('duckCharged', worldSeq(p, 'playerDuckCharged'), 10);
  },
  exit(p) { p.s.duckCount = 0; },
};

STATES.blast = {
  enter(p, msg, world) {
    p.attack.up = true;
    p.s.blastInitY = p.pos.y;
    p.vel.x = 0; p.vel.y = P.BLAST_VEL;
    if (world) world.audio.play('attack');
  },
  update(p, dt, input, world) {
    makeTrace(world, p);
    p.anim.play('roll', worldSeq(p, 'playerRoll'), 20);
    if (p.pos.y < p.s.blastInitY - P.BLAST_HEIGHT) { p._transition('air', {}, world); return; }
    const r = p.move(world, dt);
    if (r.onCeiling || p.pos.y < 6) {
      world.screenshake(2, 0.5);
      p._transition('air', {}, world);
      return;
    }
  },
  exit(p, world) { p.vel.y = 0; p.attack.up = false; },
};

STATES.dash = {
  enter(p, msg, world) {
    p.vel.x = 0; p.vel.y = 0;
    p.vel.x = P.DASH_VEL * msg.direction;
    world.audio.play('attack');
    if (p.vel.x > 0) p.attack.right = true; else p.attack.left = true;
  },
  update(p, dt, input, world) {
    makeTrace(world, p);
    p.anim.play('roll', worldSeq(p, 'playerRoll'), 20);
    p.grounded = p.checkGrounded(world);
    p.vel.x = lerp(p.vel.x, 0, P.FRICTION);
    const r = p.move(world, dt);
    if (Math.abs(p.vel.x) < 10) { p._transition('idle', {}, world); return; }
    if (r.onWallLeft || r.onWallRight) {
      world.screenshake(2, 0.5);
      world.spawnEffect('stompDust', p.pos.x, p.pos.y);
    }
  },
  exit(p, world) {
    p.attack.right = false; p.attack.left = false;
    p.dashJumpTimer = P.DASH_JUMP_TIME;
  },
};

STATES.stomp = {
  enter(p, msg, world) {
    p.attack.down = true;
    p.vel.x = 0; p.vel.y = 0;
    p.s.stompInitY = p.pos.y;
    world.audio.play('attack');
  },
  update(p, dt, input, world) {
    makeTrace(world, p);
    p.anim.play('roll', worldSeq(p, 'playerRoll'), 20);
    p.grounded = p.checkGrounded(world);
    if (p.grounded) {
      world.screenshake(2, 0.5);
      world.spawnEffect('stompDust', p.pos.x, p.pos.y);
      p._transition('idle', {}, world);
      return;
    }
    // A stomp only falls, so ending up above where it started means the world
    // wrapped us back to the top of a bottomless pit — end the stomp so the
    // normal fall handling takes over instead of looping forever.
    if (p.pos.y < p.s.stompInitY - 10) { p._transition('air', {}, world); return; }
    p.vel.y = P.STOMP_VEL;
    p.move(world, dt);
  },
  exit(p) { p.attack.down = false; },
};

STATES.walljump = {
  enter(p, msg, world) {
    p.vel.x = msg.x;
    p.facing = Math.sign(msg.x) || p.facing;
    world.audio.play('attack');
    world.spawnEffect('walkDust', p.pos.x, p.pos.y);
    p.s.traceCounter = 0;
  },
  update(p, dt, input, world) {
    p.s.traceCounter += 0.1;
    if (p.s.traceCounter > 0.1) { makeTrace(world, p); p.s.traceCounter = 0; }
    p.anim.play('roll', worldSeq(p, 'playerRoll'), 20);
    p.vel.x = lerp(p.vel.x, 0, 0.05);
    p.applyGravity(dt);
    p.move(world, dt);

    p.s.wallDirection = -(world.wallAt(p.pos.x - 6, p.pos.y - 6) ? 1 : 0) + (world.wallAt(p.pos.x + 6, p.pos.y - 6) ? 1 : 0);
    if (p.s.wallDirection !== 0 && input.jumpJustPressed) {
      p.vel.y = P.WALL_JUMP_V;
      const hx = p.s.wallDirection === 1 ? -P.WALL_JUMP_H : P.WALL_JUMP_H;
      p._transition('walljump', { x: hx }, world);
      return;
    }
    p.grounded = p.checkGrounded(world);
    if (p.grounded) { p._transition('idle', {}, world); return; }
    if (p.s.wallDirection !== 0 && p.vel.y > 0) { p._transition('air', {}, world); return; }
  },
};

STATES.hurt = {
  enter(p, msg, world) {
    p.vel.y = -100;
    p.vel.x = -20 * p.facing;
    p.anim.play('fall', worldSeq(p, 'playerFall'), 5);
    world.audio.play('hurt');
    if (world.gemsTaken < world.maxGems) {
      const gems = world.gemsTaken;
      world.addGem(-gems);
      world.spawnPlayerGems(p.pos.x, p.pos.y, gems);
    }
  },
  update(p, dt, input, world) {
    p.applyGravity(dt);
    p.move(world, dt);
    p.grounded = p.checkGrounded(world);
    if (p.grounded && p.vel.y > -40) { p._transition('idle', {}, world); return; }
  },
  exit(p) { p.makeInvincible(); },
};

STATES.win = {
  enter(p) {
    p.anim.play('jump', worldSeq(p, 'playerJump'), 5);
  },
  update() {},
};

function worldSeq(p, key) {
  return _assetsRef && _assetsRef.seq(key);
}
let _assetsRef = null;
export function bindPlayerAssets(assets) { _assetsRef = assets; }
