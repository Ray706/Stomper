import { TILE, SCREEN_W, SCREEN_H } from './constants.js';

function drawImgCentered(ctx, img, cx, cy, flipX = false) {
  if (!img) return;
  const w = img.naturalWidth, h = img.naturalHeight;
  ctx.save();
  ctx.translate(Math.round(cx), Math.round(cy));
  ctx.scale(flipX ? -1 : 1, 1);
  ctx.drawImage(img, -w / 2, -h / 2, w, h);
  ctx.restore();
}

function drawTopLeft(ctx, img, x, y, flipH = false) {
  if (!img) return;
  const w = img.naturalWidth, h = img.naturalHeight;
  if (!flipH) { ctx.drawImage(img, Math.round(x), Math.round(y)); return; }
  ctx.save();
  ctx.translate(Math.round(x) + w, Math.round(y));
  ctx.scale(-1, 1);
  ctx.drawImage(img, 0, 0);
  ctx.restore();
}

// Draws a draft level (editor-level format) in world pixel space (320x240).
// `opts.highlight` = {x, y, type, tileId} draws a translucent preview cell.
export function drawEditorLevel(ctx, draft, meta, assets, opts = {}) {
  ctx.imageSmoothingEnabled = false;

  // background
  const bg = assets.img('assets/bg/back-animated1.png');
  if (bg) ctx.drawImage(bg, 0, 0, SCREEN_W, SCREEN_H);
  else { ctx.fillStyle = '#11131f'; ctx.fillRect(0, 0, SCREEN_W, SCREEN_H); }

  // tiles
  const tileset = assets.img('assets/tiles/tileset.png');
  for (const [x, y, id] of draft.tiles) {
    if (x < 0 || y < 0 || x >= 20 || y >= 15) continue;
    const region = meta.tiles[id];
    if (!region || !tileset) continue;
    ctx.drawImage(tileset, region.x, region.y, region.w, region.h, x * TILE, y * TILE, TILE, TILE);
  }

  // props (background plants)
  const plant = assets.img('assets/misc/plant.png');
  for (const p of draft.props) drawTopLeft(ctx, plant, p.x, p.y, p.flip_h);

  // slippery blocks
  const slime = assets.img('assets/misc/slime-block.png');
  for (const e of byType(draft, 'slipperyBlock')) drawTopLeft(ctx, slime, e.x, e.y);

  // spikes
  const spSheet = assets.sheet('spikes');
  for (const e of byType(draft, 'spikes')) {
    if (e.flip) {
      if (spSheet && spSheet.img) {
        ctx.save();
        ctx.translate(Math.round(e.x), Math.round(e.y + spSheet.fh));
        ctx.scale(1, -1);
        ctx.drawImage(spSheet.img, spSheet.fw, 0, spSheet.fw, spSheet.fh, 0, 0, spSheet.fw, spSheet.fh);
        ctx.restore();
      }
    } else {
      ctx.drawImage(spSheet.img, spSheet.fw, 0, spSheet.fw, spSheet.fh, Math.round(e.x), Math.round(e.y), spSheet.fw, spSheet.fh);
    }
  }

  // spikes blocks (head + spikes)
  const headImg = assets.img('assets/misc/spike-block.png');
  for (const e of byType(draft, 'spikesBlock')) {
    ctx.save();
    if (e.flip) { ctx.translate(e.x, e.y + 16); ctx.scale(1, -1); ctx.drawImage(headImg, 0, 0); }
    else ctx.drawImage(headImg, e.x, e.y);
    ctx.restore();
    if (spSheet && spSheet.img) {
      const dy = e.flip ? 8 : -8;
      ctx.drawImage(spSheet.img, spSheet.fw, 0, spSheet.fw, spSheet.fh, Math.round(e.x), Math.round(e.y + dy), spSheet.fw, spSheet.fh);
    }
  }

  // shooting blocks
  const shootHead = assets.sheet('shootingHead');
  for (const e of byType(draft, 'shootingBlock')) {
    if (shootHead && shootHead.img) {
      const flip = (e.shoot_speed ?? -1.5) < 0;
      ctx.save();
      ctx.translate(Math.round(e.x + 8), Math.round(e.y));
      if (flip) ctx.scale(-1, 1);
      ctx.drawImage(shootHead.img, 0, 0, shootHead.fw, shootHead.fh, -shootHead.fw / 2, 0, shootHead.fw, shootHead.fh);
      ctx.restore();
    }
  }

  // door
  if (draft.door) {
    const seq = assets.seq('doorOff');
    if (seq && seq[0]) drawImgCentered(ctx, seq[0], draft.door.x, draft.door.y - 12);
  }

  // crates
  const brick = assets.img('assets/misc/brick.png');
  for (const e of byType(draft, 'crate')) drawTopLeft(ctx, brick, e.x, e.y);

  // boxes
  const box = assets.img('assets/misc/box.png');
  for (const e of byType(draft, 'box')) drawImgCentered(ctx, box, e.x + 8, e.y + 8);

  // gems
  const gemSeq = assets.seq('gemSpin');
  for (const e of byType(draft, 'gem')) if (gemSeq && gemSeq[0]) drawImgCentered(ctx, gemSeq[0], e.x + 8, e.y + 8);

  // star
  const starSeq = assets.seq('star');
  for (const e of byType(draft, 'star')) if (starSeq && starSeq[0]) drawImgCentered(ctx, starSeq[0], e.x + 8, e.y + 8);

  // enemies
  for (const e of byType(draft, 'walkingEnemy')) {
    const seq = assets.seq('walkerWalk');
    if (seq && seq[0]) drawImgCentered(ctx, seq[0], e.x, e.y - 12, (e.direction ?? 1) < 0);
  }
  for (const e of byType(draft, 'flyingEnemy')) {
    const seq = assets.seq('flyerFly');
    if (seq && seq[0]) drawImgCentered(ctx, seq[0], e.x, e.y, (e.direction ?? 1) < 0);
  }

  // player
  if (draft.player) {
    const seq = assets.seq('playerIdle');
    if (seq && seq[0]) drawImgCentered(ctx, seq[0], draft.player.x, draft.player.y - 11);
  }

  // grid + bounds
  ctx.strokeStyle = 'rgba(255,255,255,0.10)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = 0; x <= SCREEN_W; x += TILE) { ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, SCREEN_H); }
  for (let y = 0; y <= SCREEN_H; y += TILE) { ctx.moveTo(0, y + 0.5); ctx.lineTo(SCREEN_W, y + 0.5); }
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,157,60,0.6)';
  ctx.lineWidth = 2;
  ctx.strokeRect(0.5, 0.5, SCREEN_W - 1, SCREEN_H - 1);

  // highlight preview cell
  const hl = opts.highlight;
  if (hl) {
    ctx.fillStyle = 'rgba(255,157,60,0.35)';
    ctx.fillRect(hl.x * TILE, hl.y * TILE, TILE, TILE);
    ctx.strokeStyle = '#ff9d3c';
    ctx.lineWidth = 1;
    ctx.strokeRect(hl.x * TILE + 0.5, hl.y * TILE + 0.5, TILE - 1, TILE - 1);
  }
}

function byType(draft, type) {
  return draft.entities.filter((e) => e.type === type);
}

// Build a small data-URL icon (for the editor palette) drawing `fn` into a square canvas.
export function makeIcon(size, drawFn) {
  const c = document.createElement('canvas');
  c.width = size; c.height = size;
  const g = c.getContext('2d');
  g.imageSmoothingEnabled = false;
  drawFn(g, size);
  return c.toDataURL();
}

// Helper to render an asset into a palette icon via an offscreen canvas draw.
export function drawAssetIcon(g, size, draw) {
  g.clearRect(0, 0, size, size);
  draw(g);
}
