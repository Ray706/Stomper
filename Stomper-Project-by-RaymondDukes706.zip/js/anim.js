// Lightweight animation player mirroring Godot's AnimatedSprite "speed" (frames/sec).
export class Anim {
  constructor() {
    this.name = null;
    this.frame = 0;
    this.t = 0;
    this.speed = 10;
    this.frames = [];
    this.oneShotDone = false;
  }
  play(name, frames, speed, { restartIfSame = false } = {}) {
    if (this.name === name && !restartIfSame) return;
    this.name = name;
    this.frames = frames;
    this.speed = speed;
    this.frame = 0;
    this.t = 0;
    this.oneShotDone = false;
  }
  update(dt) {
    if (!this.frames || this.frames.length === 0) return;
    this.t += dt * this.speed;
    if (this.t >= 1) {
      const advance = Math.floor(this.t);
      this.t -= advance;
      this.frame += advance;
      if (this.frame >= this.frames.length) {
        this.frame = this.frame % this.frames.length;
      }
    }
  }
  current() {
    return this.frames[this.frame];
  }
}

// One-shot effect animation driven by elapsed time against a fixed frame duration list.
export class TimedEffect {
  constructor(x, y, sheet, hframes, frameDur, offsetY = 0) {
    this.x = x; this.y = y;
    this.sheet = sheet;
    this.hframes = hframes;
    this.frameDur = frameDur;
    this.offsetY = offsetY;
    this.t = 0;
    this.dead = false;
  }
  update(dt) {
    this.t += dt;
    if (this.t >= this.frameDur * this.hframes) this.dead = true;
  }
  frameIndex() {
    return Math.min(this.hframes - 1, Math.floor(this.t / this.frameDur));
  }
}
