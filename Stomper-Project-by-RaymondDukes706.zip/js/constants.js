// Constants ported 1:1 from the original Godot project (Player.gd, Enemy.gd, etc).
// Values are in the original "Godot pixels" space (320x240 virtual screen, 16px tiles)
// and the renderer scales that virtual space up to fill the device screen.

export const TILE = 16;
export const SCREEN_W = 320;
export const SCREEN_H = 240;
export const COLS = SCREEN_W / TILE; // 20
export const ROWS = SCREEN_H / TILE; // 15

// Fixed physics timestep (Godot default physics tick)
export const STEP = 1 / 60;

export const PLAYER = {
  MAX_SPEED_X: 64,
  MAX_SPEED_Y: 200,
  ACCELERATION: 500,
  AIR_ACCELERATION: 200,
  FRICTION: 0.1,
  GRAVITY: 200,
  GRAVITY_WALL: 200,
  JUMP_FORCE: 125,
  COYOTE_TIME: 0.2,
  DASH_JUMP_TIME: 0.5,
  DASH_VEL: 420,
  BLAST_VEL: -400,
  BLAST_HEIGHT: 50,
  STOMP_VEL: 400,
  DUCK_CHARGE_FRAMES: 50, // "blast_value" in Duck.gd
  INVINCIBLE_MAX: 100, // frames
  WALL_JUMP_V: -100,
  WALL_JUMP_H: 200,
  DASH_KEY_WINDOW: 80, // key_time threshold in Idle.gd for double-tap dash
  HALF_LIFE: 0.5,
};

export const ENEMY = {
  WALK_SPEED: 15,
  FLY_SPEED: 15,
  STUNT_TIME: 3.0,
  RESPAWN_TIME: 3.0,
};

// Player-relative hitbox / raycast geometry (from Player.tscn), in local space
export const PLAYER_GEOM = {
  collider: { w: 10, h: 12, oy: -6 }, // RectangleShape2D extents(5,6) => size 10x12
  groundRays: [-5, 0, 5], // x offsets, cast from y=-1 down 4px
  wallLeft: { x: -5, y: -6, len: 2 },
  wallRight: { x: 5, y: -6, len: 2 },
  attack: {
    right: { x: 6, y: -6, len: 7 },
    left: { x: -6, y: -6, len: 7 },
    down: { x: 0, y: 1, len: 5 },
    up: { x: 0, y: -13, len: 5 },
  },
  spriteOffsetY: -11,
};

export const COLORS = {
  bg: '#0b0f1a',
};
