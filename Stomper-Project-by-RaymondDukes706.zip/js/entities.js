import { TILE, ENEMY, COLS, ROWS } from './constants.js';
import { Anim } from './anim.js';
import { moveAABB, screenWrap } from './world.js';

const KILL_STATES = new Set(['stomp', 'walljump', 'dash', 'blast']);

// ---------- Enemies ----------
class BaseEnemy {
  constructor(x, y, opts) {
    this.pos = { x, y };
    this.vel = { x: 0, y: 0 };
    this.spawn = { x, y };
    this.alive = true;
    this.killed = false;
    this.stunt = false;
    this.stuntTimer = 0;
    this.respawning = false;
    this.respawnTimer = 0;
    this.respawnable = !!opts.respawnable;
    this.gemsSpawnNumber = opts.gems_spawn_number ?? 3;
    this.facing = opts.direction ?? 1;
    this.anim = new Anim();
    this.dead = false; // fully removed
    this.rotation = 0;
    this.colliderOffsetY = 0; // overridden by subclasses whose origin sits at the feet
  }

  // Moves this.pos (origin/feet-baseline) through the world by translating to the
  // collider's actual center (origin + colliderOffsetY) for collision, per-entity.
  _moveAABB(world, dt) {
    const center = { x: this.pos.x, y: this.pos.y - this.colliderOffsetY };
    const r = moveAABB(world.grid, world.extraSolids, center, this.vel, this.hw, this.hh, dt);
    this.pos.x = center.x;
    this.pos.y = center.y + this.colliderOffsetY;
    return r;
  }

  kill(world) {
    if (!this.alive || this.killed) return;
    this.alive = false;
    this.killed = true;
    this.vel.y = -300;
    this.vel.x = 50 * this.facing;
    world.spawnGemsAt(this.pos.x, this.pos.y, this.gemsSpawnNumber);
    world.audio.play('enemyDeath');
  }

  applyStunt() {
    this.stunt = true;
    this.stuntTimer = ENEMY.STUNT_TIME;
  }

  updateThrow(dt, world) {
    this.vel.y += 10;
    this.pos.x += this.vel.x * dt;
    this.pos.y += this.vel.y * dt;
    this.rotation += 0.05;
    if (this.pos.y > 2000) {
      if (this.respawnable) this.restore();
      else this.dead = true;
    }
  }

  restore() {
    this.alive = true;
    this.killed = false;
    this.vel.x = 0; this.vel.y = 0;
    this.rotation = 0;
    this.respawning = true;
    this.respawnTimer = ENEMY.RESPAWN_TIME;
    this.pos.x = this.spawn.x; this.pos.y = this.spawn.y;
  }

  baseUpdate(dt, world) {
    if (this.respawning) {
      this.respawnTimer -= dt;
      if (this.respawnTimer <= 0) this.respawning = false;
    }
    if (this.stunt) {
      this.stuntTimer -= dt;
      if (this.stuntTimer <= 0) this.stunt = false;
    }
    if (!this.killed) screenWrap(this.pos);
  }
}

export class WalkingEnemy extends BaseEnemy {
  constructor(x, y, opts) {
    super(x, y, opts);
    this.hw = 6; this.hh = 6;
    this.colliderOffsetY = 6; // origin is at the feet, like the player
    this.type = 'walkingEnemy';
    this.vel.y = 9;
  }
  update(dt, world) {
    this.baseUpdate(dt, world);
    if (this.killed) { this.updateThrow(dt, world); this.anim.play('walk', world.assets.seq('walkerWalk'), 7); return; }
    if (this.respawning) return;

    const groundAhead = (dx) => world.groundBelow(this.pos.x + dx, this.pos.y + 3);
    const wallAhead = (dx) => world.wallAt(this.pos.x + dx, this.pos.y - 6);
    // Probe one pixel beyond the collider edge so a wall flush against the body
    // (whose leading edge sits exactly on a tile boundary) is still detected,
    // otherwise the enemy walks into it and never turns around.
    const probe = this.hw + 1;
    if (this.facing === 1) {
      this.vel.x = ENEMY.WALK_SPEED;
      if (wallAhead(probe) || !groundAhead(5)) this.facing = -1;
    } else {
      this.vel.x = -ENEMY.WALK_SPEED;
      if (wallAhead(-probe) || !groundAhead(-5)) this.facing = 1;
    }
    if (this.stunt) this.vel.x = 0;
    this.vel.y += 9;
    if (this.vel.y > 200) this.vel.y = 200;
    this._moveAABB(world, dt);
    this.anim.play(this.stunt ? 'stunt' : 'walk', world.assets.seq(this.stunt ? 'walkerStunt' : 'walkerWalk'), this.stunt ? 5 : 7);
    this.anim.update(dt);
  }
}

export class FlyingEnemy extends BaseEnemy {
  constructor(x, y, opts) {
    super(x, y, opts);
    this.hw = 6.5; this.hh = 6.5;
    this.type = 'flyingEnemy';
  }
  update(dt, world) {
    this.baseUpdate(dt, world);
    if (this.killed) { this.updateThrow(dt, world); this.anim.play('fly', world.assets.seq('flyerFly'), 10); return; }
    if (this.respawning) return;

    const wallAhead = (dx) => world.wallAt(this.pos.x + dx, this.pos.y);
    if (this.facing === 1) {
      this.vel.x = ENEMY.FLY_SPEED;
      if (wallAhead(this.hw + 0.5)) this.facing = -1;
    } else {
      this.vel.x = -ENEMY.FLY_SPEED;
      if (wallAhead(-(this.hw + 0.5))) this.facing = 1;
    }
    if (this.stunt) this.vel.x = 0;
    this.vel.y = 0;
    this._moveAABB(world, dt);
    this.anim.play(this.stunt ? 'stunt' : 'fly', world.assets.seq(this.stunt ? 'flyerStunt' : 'flyerFly'), this.stunt ? 7 : 10);
    this.anim.update(dt);
  }
}

// ---------- Gems ----------
export class Gem {
  constructor(x, y, { dropped = false, impulse = null } = {}) {
    this.pos = { x, y };
    this.vel = impulse ? { x: impulse.x * 2.2, y: impulse.y * 2.2 } : { x: 0, y: 0 };
    this.dropped = dropped;
    this.collectible = !dropped;
    this.pickupDelay = dropped ? 1.0 : 0;
    this.hw = 8; this.hh = 8;
    this.dead = false;
    this.anim = new Anim();
    this.settled = !dropped;
  }
  update(dt, world) {
    if (this.dead) return;
    if (!this.settled) {
      this.vel.y += 200 * dt * 6; // gravity_scale-ish, heavier than player for snappy drops
      const r = moveAABB(world.grid, world.extraSolids, this.pos, this.vel, this.hw, this.hh, dt);
      if (r.onFloor) { this.vel.y *= -0.55; this.vel.x *= 0.6; if (Math.abs(this.vel.y) < 20) { this.vel.y = 0; this.settled = true; } }
      if (r.onWallLeft || r.onWallRight) this.vel.x *= -0.5;
      screenWrap(this.pos);
    }
    if (this.pickupDelay > 0) {
      this.pickupDelay -= dt;
      if (this.pickupDelay <= 0) this.collectible = true;
    }
    this.anim.play('spin', world.assets.seq('gemSpin'), 20);
    this.anim.update(dt);
  }
}

// ---------- Door ----------
export class Door {
  constructor(x, y) {
    this.pos = { x, y };
    this.hw = 4; this.hh = 4;
    this.open = false;
    this.anim = new Anim();
    this.triggered = false;
  }
  setOpen() { this.open = true; }
  update(dt, world) {
    this.anim.play(this.open ? 'active' : 'off',
      world.assets.seq(this.open ? 'doorActive' : 'doorOff'), this.open ? 13 : 5);
    this.anim.update(dt);
  }
}

// ---------- Star (Zaphire collectible) ----------
export class Star {
  constructor(x, y) {
    this.pos = { x: x + 8, y: y + 8 };
    this.hw = 8; this.hh = 8;
    this.dead = false;
    this.anim = new Anim();
  }
  update(dt, world) {
    this.anim.play('spin', world.assets.seq('star'), 15);
    this.anim.update(dt);
  }
}

// ---------- Spikes (thin hazard strip) ----------
export class Spikes {
  constructor(x, y, opts = {}) {
    this.pos = { x: x + 8, y: y + 12 };
    this.hw = 8; this.hh = 4;
    this.spriteX = x; this.spriteY = y;
    this.flip = !!opts.flip;
  }
  update() {}
}

// ---------- SpikesBlock (retracting spikes on a solid block) ----------
export class SpikesBlock {
  constructor(x, y, opts) {
    this.pos = { x: x + 8, y: y + 8 };
    this.hw = 8; this.hh = 8;
    this.flip = !!opts.flip;
    this.spriteX = x; this.spriteY = y;
    this.t = Math.random() * 2.2;
    this.out = false;
    this.hazardHw = 8; this.hazardHh = 4;
  }
  update(dt) {
    this.t += dt;
    if (this.t >= 2.2) this.t -= 2.2;
    this.out = this.t >= 1.1;
  }
  hazardBox() {
    const dy = this.flip ? 8 : -8;
    return { x: this.pos.x, y: this.pos.y + dy, hw: this.hazardHw, hh: this.hazardHh };
  }
}

// ---------- Shooting block + projectile ----------
export class ShootingBlock {
  constructor(x, y, opts) {
    this.pos = { x: x + 8, y: y + 8 };
    this.spriteX = x; this.spriteY = y;
    this.hw = 8; this.hh = 8;
    this.shootSpeed = opts.shoot_speed ?? -1.5;
    this.t = Math.random() * 3;
    this.frame = 0;
  }
  update(dt, world) {
    this.t += dt;
    if (this.t >= 3) this.t -= 3;
    this.frame = this.t >= 1.3 ? 1 : 0;
    if (!this._firedThisCycle && this.t >= 1.5) {
      this._firedThisCycle = true;
      const px = this.shootSpeed > 0 ? this.pos.x + 16 : this.pos.x - 8;
      world.spawnShot(px, this.pos.y, this.shootSpeed);
    }
    if (this.t < 1.5) this._firedThisCycle = false;
  }
}

export class Shot {
  constructor(x, y, speed) {
    this.pos = { x, y };
    this.speed = speed * 60; // was per-frame pixel delta at 60fps in Godot
    this.hw = 4; this.hh = 4;
    this.dead = false;
    this.anim = new Anim();
  }
  update(dt, world) {
    this.pos.x += this.speed * dt;
    this.anim.play('shoot', world.assets.seq('shoot'), 15);
    this.anim.update(dt);
    if (this.pos.x < -20 || this.pos.x > COLS * TILE + 20) this.dead = true;
  }
}

// ---------- Slippery block (visual + solid ground, low friction) ----------
export class SlipperyBlock {
  constructor(x, y) {
    this.pos = { x: x + 8, y: y + 8 };
    this.spriteX = x; this.spriteY = y;
    this.hw = 8; this.hh = 8;
  }
}

// ---------- Crate (destructible) ----------
export class Crate {
  constructor(x, y, opts) {
    this.pos = { x: x + 8, y: y + 8 };
    this.spriteX = x; this.spriteY = y;
    this.hw = 8; this.hh = 8;
    this.gemsSpawnNumber = opts.gems_spawn_number ?? 3;
    this.dead = false;
  }
  kill(world) {
    if (this.dead) return;
    this.dead = true;
    world.spawnBricks(this.pos.x, this.pos.y);
    world.spawnGemsAt(this.pos.x, this.pos.y, this.gemsSpawnNumber);
  }
}

export class Brick {
  constructor(x, y, rotDir) {
    this.pos = { x, y };
    this.vel = { x: (Math.random() * 30 * rotDir), y: -200 };
    this.rot = rotDir;
    this.rotation = 0;
    this.t = 0;
    this.dead = false;
  }
  update(dt) {
    this.t += dt;
    this.vel.y += 200 * 6 * dt;
    this.pos.x += this.vel.x * dt;
    this.pos.y += this.vel.y * dt;
    this.rotation += 0.2 * this.rot;
    if (this.pos.y > ROWS * TILE + 60 || this.t > 4) this.dead = true;
  }
}

// ---------- Box (pushable) ----------
export class Box {
  constructor(x, y) {
    this.pos = { x: x + 8, y: y + 8 };
    this.hw = 8; this.hh = 8;
    this.vel = { x: 0, y: 0 };
  }
  push(dir) { this.vel.x = dir * 20; }
  update(dt, world) {
    this.vel.y += 1000 * dt;
    moveAABB(world.grid, world.extraSolidsExcept ? world.extraSolidsExcept(this) : world.extraSolids, this.pos, this.vel, this.hw, this.hh, dt);
    this.vel.x = 0;
  }
}

export const KILL_STATE_SET = KILL_STATES;
