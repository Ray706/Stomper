import { SND, BGM_WAV } from './assets.js';

const VOLUMES = {
  jump: 0.4, hurt: 0.48, pick: 0.48, stomp: 0.48, enemyDeath: 0.48,
  attack: 0.48, door: 0.5, hit: 0.48, bgm: 0.32,
};

export class AudioManager {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    this.unlocked = false;
    this.masterGain = null;
    this.bgmGain = null;
    this.sfxGain = null;
    this.bgmSource = null;
    this.bgmOn = false;
    this.buffers = {};
  }

  async init() {
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 1;
      this.masterGain.connect(this.ctx.destination);
      this.bgmGain = this.ctx.createGain();
      this.bgmGain.gain.value = 1;
      this.bgmGain.connect(this.masterGain);
      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 1;
      this.sfxGain.connect(this.masterGain);
      await this._preloadAll();
    } catch (e) {
      this.ctx = null;
    }
  }

  async _decode(url) {
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      const arr = await res.arrayBuffer();
      if (this.ctx.state === 'closed') return null;
      return await this.ctx.decodeAudioData(arr.slice(0));
    } catch (e) {
      return null;
    }
  }

  async _preloadAll() {
    await Promise.all(Object.entries(SND).map(async ([name, url]) => {
      const buf = await this._decode(url);
      if (buf) this.buffers[name] = buf;
    }));
    // Ogg Vorbis won't decode on Safari/iOS; fall back to the WAV music track.
    if (!this.buffers.bgm) {
      const buf = await this._decode(BGM_WAV);
      if (buf) this.buffers.bgm = buf;
    }
  }

  unlock() {
    if (this.unlocked) return;
    this.unlocked = true;
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    // Kick the context with a silent buffer inside the user gesture so later
    // play() calls aren't rejected by the autoplay policy (iOS/Safari).
    try {
      if (this.ctx.state !== 'running') {
        const buf = this.ctx.createBuffer(1, 1, 22050);
        const src = this.ctx.createBufferSource();
        src.buffer = buf;
        src.connect(this.ctx.destination);
        src.start(0);
      }
    } catch (e) { /* ignore */ }
  }

  play(key) {
    if (!this.enabled || !this.ctx || this.ctx.state === 'closed') return;
    const buf = this.buffers[key];
    if (!buf) return;
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    try {
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const g = this.ctx.createGain();
      g.gain.value = VOLUMES[key] ?? 0.5;
      src.connect(g);
      g.connect(this.sfxGain);
      src.start(0);
    } catch (e) { /* ignore */ }
  }

  playBgm() {
    if (!this.enabled || !this.ctx || this.ctx.state === 'closed') return;
    if (this.bgmOn || !this.buffers.bgm) return;
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    try {
      const src = this.ctx.createBufferSource();
      src.buffer = this.buffers.bgm;
      src.loop = true;
      const g = this.ctx.createGain();
      g.gain.value = VOLUMES.bgm ?? 0.3;
      src.connect(g);
      g.connect(this.bgmGain);
      src.start(0);
      this.bgmSource = src;
      this.bgmOn = true;
    } catch (e) { /* ignore */ }
  }

  stopBgm() {
    if (this.bgmSource) {
      try { this.bgmSource.stop(); } catch (e) { /* ignore */ }
      this.bgmSource = null;
    }
    this.bgmOn = false;
  }

  setEnabled(v) {
    this.enabled = v;
    if (!v) this.stopBgm();
    else if (this.unlocked) this.playBgm();
  }
}
