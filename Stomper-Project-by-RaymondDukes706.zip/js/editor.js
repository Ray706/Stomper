import { h } from 'https://esm.sh/preact@10.19.6';
import { useEffect, useRef, useState, useCallback, useMemo } from 'https://esm.sh/preact@10.19.6/hooks';
import htm from 'https://esm.sh/htm@3.1.1';
import { SCREEN_W, SCREEN_H } from './constants.js';
import * as model from './editor-level.js';
import { drawEditorLevel } from './editor-render.js';

const html = htm.bind(h);

const MIN_SCALE = 0.4;
const MAX_SCALE = 6;

const TILE_IDS = [1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27];

const TABS = [
  { id: 'tiles', label: 'TILES' },
  { id: 'enemies', label: 'ENEMIES' },
  { id: 'items', label: 'ITEMS' },
  { id: 'hazards', label: 'HAZARDS' },
  { id: 'decor', label: 'DECOR' },
];

function tabTools(tab) {
  switch (tab) {
    case 'enemies':
      return [
        { id: 'walkingEnemy', kind: 'entity', type: 'walkingEnemy', label: 'Walker' },
        { id: 'flyingEnemy', kind: 'entity', type: 'flyingEnemy', label: 'Flyer' },
      ];
    case 'items':
      return [
        { id: 'player', kind: 'entity', type: 'player', label: 'Player' },
        { id: 'door', kind: 'entity', type: 'door', label: 'Door' },
        { id: 'gem', kind: 'entity', type: 'gem', label: 'Gem' },
        { id: 'star', kind: 'entity', type: 'star', label: 'Star' },
        { id: 'crate', kind: 'entity', type: 'crate', label: 'Crate' },
        { id: 'box', kind: 'entity', type: 'box', label: 'Box' },
      ];
    case 'hazards':
      return [
        { id: 'spikes', kind: 'entity', type: 'spikes', label: 'Spikes' },
        { id: 'spikesBlock', kind: 'entity', type: 'spikesBlock', label: 'Spike block' },
        { id: 'shootingBlock', kind: 'entity', type: 'shootingBlock', label: 'Shooter' },
        { id: 'slipperyBlock', kind: 'entity', type: 'slipperyBlock', label: 'Ice' },
      ];
    case 'decor':
      return [
        { id: 'plant', kind: 'prop', type: 'plant', label: 'Plant' },
      ];
    case 'tiles':
    default:
      return [{ id: 'eraser', kind: 'eraser', label: 'Erase' }, ...TILE_IDS.map((id) => ({ id: 'tile:' + id, kind: 'tile', tileId: id }))];
  }
}

function buildIcons(assets) {
  const out = {};
  const draw = (g, img, cx, cy, maxW, maxH) => {
    if (!img) return;
    const s = Math.min(maxW / img.naturalWidth, maxH / img.naturalHeight, 1);
    const w = img.naturalWidth * s, h = img.naturalHeight * s;
    g.drawImage(img, cx - w / 2, cy - h / 2, w, h);
  };
  const sheetFrame = (g, sheet, frame, cx, cy, w, h) => {
    if (!sheet || !sheet.img) return;
    const fw = sheet.fw, fh = sheet.fh;
    const s = Math.min(w / fw, h / fh, 1);
    g.drawImage(sheet.img, frame * fw, 0, fw, fh, cx - (fw * s) / 2, cy - (fh * s) / 2, fw * s, fh * s);
  };
  const defs = {
    player: (g) => draw(g, assets.seq('playerIdle')?.[0], 16, 22, 28, 26),
    door: (g) => draw(g, assets.seq('doorOff')?.[0], 16, 20, 24, 22),
    gem: (g) => draw(g, assets.seq('gemSpin')?.[0], 16, 18, 22, 22),
    star: (g) => draw(g, assets.seq('star')?.[0], 16, 18, 24, 24),
    crate: (g) => draw(g, assets.img('assets/misc/brick.png'), 16, 16, 26, 26),
    box: (g) => draw(g, assets.img('assets/misc/box.png'), 16, 16, 26, 26),
    walkingEnemy: (g) => draw(g, assets.seq('walkerWalk')?.[0], 16, 18, 24, 24),
    flyingEnemy: (g) => draw(g, assets.seq('flyerFly')?.[0], 16, 18, 26, 26),
    spikes: (g) => sheetFrame(g, assets.sheet('spikes'), 1, 16, 24, 26, 16),
    spikesBlock: (g) => draw(g, assets.img('assets/misc/spike-block.png'), 16, 12, 24, 20),
    shootingBlock: (g) => sheetFrame(g, assets.sheet('shootingHead'), 0, 16, 16, 26, 26),
    slipperyBlock: (g) => draw(g, assets.img('assets/misc/slime-block.png'), 16, 16, 26, 26),
    plant: (g) => draw(g, assets.img('assets/misc/plant.png'), 16, 16, 26, 26),
  };
  for (const type in defs) {
    const c = document.createElement('canvas');
    c.width = 32; c.height = 32;
    const g = c.getContext('2d');
    g.imageSmoothingEnabled = false;
    defs[type](g);
    out[type] = c.toDataURL();
  }
  return out;
}

const clampScale = (s) => Math.max(MIN_SCALE, Math.min(MAX_SCALE, s));

// Lets other UI (e.g. the title screen) know the editor is consuming the keyboard.
let keyboardLocked = false;
export function setEditorKeyboardLock(v) { keyboardLocked = v; }
export function isEditorKeyboardLocked() { return keyboardLocked; }

export function LevelEditor({ initialDraft, assets, tilesetMeta, onClose, onTest }) {
  const canvasRef = useRef(null);
  const stageRef = useRef(null);
  const draftRef = useRef(model.deepCopy(initialDraft));
  const viewRef = useRef({ x: 0, y: 0, scale: 1 });
  const pointersRef = useRef(new Map());
  const gestureRef = useRef(null);
  const highlightRef = useRef(null);
  const toolRef = useRef({ id: 'eraser', kind: 'eraser' });
  const optsRef = useRef({ flip: false, respawnable: false, gems: 3 });
  const didInitRef = useRef(false);

  const [tab, setTab] = useState('tiles');
  const [tool, setTool] = useState({ id: 'eraser', kind: 'eraser' });
  const [opts, setOpts] = useState({ flip: false, respawnable: false, gems: 3 });
  const [showImport, setShowImport] = useState(false);
  const [importText, setImportText] = useState('');
  const [importErr, setImportErr] = useState('');
  const [toast, setToast] = useState('');

  toolRef.current = tool;
  optsRef.current = opts;

  const icons = useMemo(() => buildIcons(assets), [assets]);
  const tools = tabTools(tab);

  const toastTimer = useRef(null);
  const showToast = useCallback((msg) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 1800);
  }, []);

  // ---- view helpers ----
  const fit = useCallback(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const w = cv.clientWidth || 320, h = cv.clientHeight || 240;
    const scale = clampScale(Math.min(w / SCREEN_W, h / SCREEN_H));
    viewRef.current = { scale, x: (w - SCREEN_W * scale) / (2 * scale), y: (h - SCREEN_H * scale) / (2 * scale) };
  }, []);

  const zoomAt = useCallback((clientX, clientY, factor) => {
    const cv = canvasRef.current;
    if (!cv) return;
    const rect = cv.getBoundingClientRect();
    const px = clientX - rect.left, py = clientY - rect.top;
    const v = viewRef.current;
    const s = clampScale(v.scale * factor);
    if (s === v.scale) return;
    const wx = v.x + px / v.scale, wy = v.y + py / v.scale;
    v.scale = s;
    v.x = wx - px / s;
    v.y = wy - py / s;
  }, []);

  const zoomBy = useCallback((factor) => {
    const cv = canvasRef.current;
    if (!cv) return;
    const rect = cv.getBoundingClientRect();
    zoomAt(rect.left + rect.width / 2, rect.top + rect.height / 2, factor);
  }, [zoomAt]);

  const worldToCell = useCallback((clientX, clientY) => {
    const cv = canvasRef.current;
    if (!cv) return null;
    const rect = cv.getBoundingClientRect();
    const px = clientX - rect.left, py = clientY - rect.top;
    const v = viewRef.current;
    const wx = px / v.scale + v.x, wy = py / v.scale + v.y;
    const cx = Math.floor(wx / 16), cy = Math.floor(wy / 16);
    if (cx < 0 || cy < 0 || cx >= model.COLS || cy >= model.ROWS) return null;
    return [cx, cy];
  }, []);

  const paintAt = useCallback((cell) => {
    const t = toolRef.current;
    const cx = cell[0], cy = cell[1];
    if (t.kind === 'eraser') model.eraseAt(draftRef.current, cx, cy);
    else if (t.kind === 'tile') model.setTileAt(draftRef.current, cx, cy, t.tileId);
    else if (t.kind === 'entity') model.paintEntity(draftRef.current, t.type, cx, cy, optsRef.current);
    else if (t.kind === 'prop') model.paintProp(draftRef.current, cx, cy, optsRef.current);
  }, []);

  // ---- pointer handlers ----
  const onPointerDown = useCallback((e) => {
    if (!canvasRef.current) return;
    try { canvasRef.current.setPointerCapture(e.pointerId); } catch (_) {}
    e.preventDefault();
    pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    const t = toolRef.current;
    if (t.kind === 'pan' || e.button === 1) { gestureRef.current = { mode: 'pan' }; return; }
    if (pointersRef.current.size >= 2) {
      const pts = [...pointersRef.current.values()];
      gestureRef.current = {
        mode: 'pinch',
        base: {
          dist: Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y),
          mid: { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 },
          scale: viewRef.current.scale,
          view: { x: viewRef.current.x, y: viewRef.current.y },
        },
      };
      return;
    }
    if (e.button !== 0) return;
    const cell = worldToCell(e.clientX, e.clientY);
    highlightRef.current = cell;
    if (!cell) return;
    if (t.kind === 'entity') {
      const match = model.entitiesAt(draftRef.current, cell[0], cell[1], t.type)[0];
      if (match) {
        gestureRef.current = { mode: 'move', entity: match, lastCell: cell };
        return;
      }
    }
    gestureRef.current = { mode: 'paint', lastCell: cell };
    paintAt(cell);
  }, [paintAt, worldToCell]);

  const onPointerMove = useCallback((e) => {
    const prev = pointersRef.current.get(e.pointerId);
    pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const g = gestureRef.current;
    if (!g) return;
    const cell = worldToCell(e.clientX, e.clientY);
    if (cell) highlightRef.current = cell;

    if (g.mode === 'pan') {
      if (!prev) return;
      const v = viewRef.current;
      v.x -= (e.clientX - prev.x) / v.scale;
      v.y -= (e.clientY - prev.y) / v.scale;
      return;
    }
    if (g.mode === 'pinch') {
      const pts = [...pointersRef.current.values()];
      if (pts.length < 2) return;
      const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      const mid = { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 };
      const b = g.base;
      const s = clampScale(b.scale * (b.dist ? dist / b.dist : 1));
      const wx = b.view.x + mid.x / b.scale, wy = b.view.y + mid.y / b.scale;
      viewRef.current.scale = s;
      viewRef.current.x = wx - mid.x / s;
      viewRef.current.y = wy - mid.y / s;
      return;
    }
    if (!cell) return;
    if (g.mode === 'move') {
      if (g.lastCell && g.lastCell[0] === cell[0] && g.lastCell[1] === cell[1]) return;
      model.moveEntityTo(draftRef.current, g.entity, cell[0], cell[1]);
      g.lastCell = cell;
      return;
    }
    if (g.mode === 'paint') {
      if (g.lastCell && g.lastCell[0] === cell[0] && g.lastCell[1] === cell[1]) return;
      g.lastCell = cell;
      paintAt(cell);
    }
  }, [paintAt, worldToCell]);

  const endPointer = useCallback((e) => {
    pointersRef.current.delete(e.pointerId);
    const g = gestureRef.current;
    if (g && g.mode === 'pinch' && pointersRef.current.size === 1) {
      gestureRef.current = { mode: 'pan' };
      return;
    }
    if (pointersRef.current.size === 0) {
      gestureRef.current = null;
      highlightRef.current = null;
    }
  }, []);

  const onWheel = useCallback((e) => {
    e.preventDefault();
    zoomAt(e.clientX, e.clientY, Math.exp(-e.deltaY * 0.0015));
  }, [zoomAt]);

  // ---- drawing loop + sizing ----
  useEffect(() => {
    setEditorKeyboardLock(true);
    return () => setEditorKeyboardLock(false);
  }, []);

  useEffect(() => {
    const cv = canvasRef.current;
    const stage = stageRef.current;
    if (!cv || !stage) return;
    const dpr = Math.min(3, window.devicePixelRatio || 1);

    const size = () => {
      const w = stage.clientWidth, h = stage.clientHeight;
      cv.width = Math.max(1, Math.round(w * dpr));
      cv.height = Math.max(1, Math.round(h * dpr));
      if (!didInitRef.current) {
        didInitRef.current = true;
        fit();
      }
    };
    size();
    const ro = new ResizeObserver(size);
    ro.observe(stage);

    let raf;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const ctx = cv.getContext('2d');
      const v = viewRef.current;
      const scale = v.scale * (cv.width / Math.max(1, stage.clientWidth));
      ctx.setTransform(scale, 0, 0, scale, -v.x * scale, -v.y * scale);
      ctx.imageSmoothingEnabled = false;
      drawEditorLevel(ctx, draftRef.current, tilesetMeta, assets, { highlight: highlightRef.current });
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [assets, tilesetMeta, fit]);

  // ---- keyboard ----
  useEffect(() => {
    const onKey = (e) => {
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
      const cursor = highlightRef.current || [10, 7];
      const move = (dx, dy) => {
        e.preventDefault();
        const nx = Math.max(0, Math.min(model.COLS - 1, cursor[0] + dx));
        const ny = Math.max(0, Math.min(model.ROWS - 1, cursor[1] + dy));
        highlightRef.current = [nx, ny];
        gestureRef.current = { mode: 'cursor', lastCell: [nx, ny] };
      };
      if (e.code === 'ArrowLeft') move(-1, 0);
      else if (e.code === 'ArrowRight') move(1, 0);
      else if (e.code === 'ArrowUp') move(0, -1);
      else if (e.code === 'ArrowDown') move(0, 1);
      else if (e.code === 'Enter' || e.code === 'Space') { e.preventDefault(); if (highlightRef.current) paintAt(highlightRef.current); }
      else if (e.code === 'Backspace' || e.code === 'Delete' || e.code === 'KeyX') { e.preventDefault(); if (highlightRef.current) model.eraseAt(draftRef.current, highlightRef.current[0], highlightRef.current[1]); }
      else if (e.code === 'Equal' || e.code === 'NumpadAdd') { e.preventDefault(); zoomBy(1.25); }
      else if (e.code === 'Minus' || e.code === 'NumpadSubtract') { e.preventDefault(); zoomBy(0.8); }
      else if (e.code === 'Escape') onClose(draftRef.current);
      else if (e.code === 'KeyP') setTool((t) => (t.kind === 'pan' ? { id: 'eraser', kind: 'eraser' } : { id: 'pan', kind: 'pan' }));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [paintAt, zoomBy, onClose]);

  // ---- import / export ----
  const doExport = useCallback(() => {
    const json = JSON.stringify(model.serialize(draftRef.current), null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'stomper-level.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast('Level exported');
  }, [showToast]);

  const doNew = useCallback(() => {
    draftRef.current = model.blankLevel();
    model.paintEntity(draftRef.current, 'player', 10, 7);
    didInitRef.current = true;
    fit();
    showToast('New blank level');
  }, [fit, showToast]);

  const loadText = useCallback((text) => {
    try {
      const d = model.parseLevel(text);
      draftRef.current = d;
      setShowImport(false);
      setImportErr('');
      showToast('Level loaded');
    } catch (err) {
      setImportErr(err.message || 'Invalid JSON');
    }
  }, [showToast]);

  const fileRef = useRef(null);
  const onFile = useCallback((e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => loadText(String(reader.result));
    reader.onerror = () => setImportErr('Could not read file');
    reader.readAsText(f);
    e.target.value = '';
  }, [loadText]);

  // ---- render ----
  const tileStyle = (id) => {
    const r = tilesetMeta.tiles[id];
    if (!r) return {};
    const s = 28 / 16;
    return {
      backgroundImage: `url('assets/tiles/tileset.png')`,
      backgroundSize: `${128 * s}px ${64 * s}px`,
      backgroundPosition: `${-r.x * s}px ${-r.y * s}px`,
    };
  };

  const chipLabel = (t) => (t.kind === 'tile' ? '' : t.label || '');
  const chipContent = (t) => {
    if (t.kind === 'tile') return html`<span class="tile-chip-img" style=${tileStyle(t.tileId)}></span>`;
    if (t.kind === 'entity') return html`<img class="chip-icon" src=${icons[t.type]} alt=${t.label} draggable="false" />`;
    if (t.kind === 'prop') return html`<img class="chip-icon" src=${icons.plant} alt=${t.label} draggable="false" />`;
    if (t.kind === 'eraser') return html`<span class="chip-text">✕</span>`;
    return html`<span class="chip-text">✋</span>`;
  };

  const showOpts =
    (tool.kind === 'entity' && ['walkingEnemy', 'flyingEnemy', 'spikes', 'spikesBlock', 'shootingBlock', 'crate'].includes(tool.type)) ||
    (tool.kind === 'prop' && tool.type === 'plant');

  return html`
    <div class="editor-overlay" role="dialog" aria-label="Level editor">
      <header class="editor-header">
        <button class="editor-btn" aria-label="Back to game" title="Back (Esc)" onPointerDown=${() => onClose(draftRef.current)}>←</button>
        <span class="editor-title">EDITOR</span>
        <div class="editor-actions">
          <button class="editor-btn" aria-label="Import level" title="Import" onPointerDown=${() => setShowImport(true)}>↧</button>
          <button class="editor-btn" aria-label="Export level" title="Export" onPointerDown=${doExport}>↥</button>
          <button class="editor-btn" aria-label="New blank level" title="New" onPointerDown=${doNew}>＋</button>
          <button class="editor-btn editor-test" aria-label="Test play level" title="Test play" onPointerDown=${() => onTest(draftRef.current)}>▶ TEST</button>
        </div>
      </header>

      <div class="editor-stage" ref=${stageRef}>
        <canvas
          ref=${canvasRef}
          class="editor-canvas"
          style=${{ touchAction: 'none' }}
          onPointerDown=${onPointerDown}
          onPointerMove=${onPointerMove}
          onPointerUp=${endPointer}
          onPointerCancel=${endPointer}
          onLostPointerCapture=${endPointer}
          onWheel=${onWheel}
          onContextMenu=${(e) => e.preventDefault()}
        ></canvas>
      </div>

      <div class="editor-toolbar">
        <div class="editor-toolrow">
          <div class="editor-toolgroup">
            <button class=${'editor-mini ' + (tool.kind === 'pan' ? 'active' : '')} aria-label="Pan tool (P)" title="Pan (P)" onPointerDown=${() => setTool({ id: 'pan', kind: 'pan' })}>✋</button>
            <button class=${'editor-mini ' + (tool.kind === 'eraser' ? 'active' : '')} aria-label="Eraser (X)" title="Eraser (X)" onPointerDown=${() => setTool({ id: 'eraser', kind: 'eraser' })}>✕</button>
          </div>
          <div class="editor-tabs">
            ${TABS.map((tb) => html`<button class=${'editor-tab ' + (tab === tb.id ? 'active' : '')} key=${tb.id} onPointerDown=${() => { setTab(tb.id); setTool(tabTools(tb.id)[0]); }}>${tb.label}</button>`)}
          </div>
          <div class="editor-toolgroup">
            <button class="editor-mini" aria-label="Zoom out" title="Zoom out" onPointerDown=${() => zoomBy(0.8)}>−</button>
            <button class="editor-mini" aria-label="Fit level" title="Fit" onPointerDown=${fit}>⤢</button>
            <button class="editor-mini" aria-label="Zoom in" title="Zoom in" onPointerDown=${() => zoomBy(1.25)}>＋</button>
          </div>
        </div>
        <div class="editor-strip" role="toolbar" aria-label="Brush palette">
          ${tools.map((t) => html`
            <button
              class=${'editor-chip ' + (tool.id === t.id ? 'active' : '')}
              key=${t.id}
              aria-label=${t.label || ('Tile ' + t.tileId)}
              title=${t.label || ('Tile ' + t.tileId)}
              onPointerDown=${() => setTool(t)}
            >${chipContent(t)}${chipLabel(t) && html`<span class="chip-label">${chipLabel(t)}</span>`}</button>
          `)}
        </div>
        ${showOpts && html`
          <div class="editor-opts">
            ${(tool.type === 'spikes' || tool.type === 'spikesBlock' || tool.type === 'shootingBlock' || tool.type === 'walkingEnemy' || tool.type === 'flyingEnemy' || tool.type === 'plant') && html`
              <button class=${'editor-mini ' + (opts.flip ? 'active' : '')} aria-label="Flip direction" title="Flip" onPointerDown=${() => setOpts({ ...opts, flip: !opts.flip })}>FLIP</button>
            `}
            ${(tool.type === 'walkingEnemy' || tool.type === 'flyingEnemy') && html`
              <button class=${'editor-mini ' + (opts.respawnable ? 'active' : '')} aria-label="Respawnable" title="Respawnable" onPointerDown=${() => setOpts({ ...opts, respawnable: !opts.respawnable })}>RESPAWN</button>
            `}
            ${tool.type === 'crate' && html`
              <span class="editor-opt-group">
                <span class="editor-opt-label">GEMS</span>
                <button class="editor-mini" aria-label="Fewer gems" onPointerDown=${() => setOpts({ ...opts, gems: Math.max(0, opts.gems - 1) })}>−</button>
                <span class="editor-opt-val">${opts.gems}</span>
                <button class="editor-mini" aria-label="More gems" onPointerDown=${() => setOpts({ ...opts, gems: Math.min(5, opts.gems + 1) })}>＋</button>
              </span>
            `}
            <span class="editor-opt-hint">tap or drag on the grid to place</span>
          </div>
        `}
        ${!showOpts && html`<div class="editor-hint">tap or drag on the grid to paint · two fingers drag to pan · pinch or wheel to zoom</div>`}
      </div>

      ${toast && html`<div class="editor-toast" role="status">${toast}</div>`}

      ${showImport && html`
        <div class="editor-modal" role="dialog" aria-label="Import level">
          <div class="editor-modal-box">
            <h3>IMPORT LEVEL</h3>
            <p class="editor-modal-note">Paste a level JSON below, or choose a file.</p>
            <textarea class="editor-textarea" value=${importText} placeholder='{"tiles":[],"entities":[],...}' onInput=${(e) => setImportText(e.target.value)}></textarea>
            ${importErr && html`<p class="editor-import-err">${importErr}</p>`}
            <div class="editor-modal-actions">
              <input ref=${fileRef} type="file" accept=".json,application/json" class="editor-file" onchange=${onFile} />
              <button class="editor-mini editor-wide" onPointerDown=${() => loadText(importText)}>LOAD</button>
              <button class="editor-mini" onPointerDown=${() => fileRef.current && fileRef.current.click()}>FILE…</button>
              <button class="editor-mini" onPointerDown=${() => { setShowImport(false); setImportErr(''); }}>CANCEL</button>
            </div>
          </div>
        </div>
      `}
    </div>
  `;
}
