// Unified input: keyboard, on-screen touch buttons, and mouse (via the same buttons)
// all funnel into one held-key set. Per-frame edge detection (justPressed/justReleased)
// is computed once per fixed physics step by calling update().

const KEY_MAP = {
  ArrowLeft: 'left', KeyA: 'left',
  ArrowRight: 'right', KeyD: 'right',
  ArrowUp: 'up', KeyW: 'up',
  ArrowDown: 'down', KeyS: 'down',
  Space: 'jump', KeyZ: 'jump', KeyJ: 'jump',
  KeyR: 'reload',
  KeyM: 'mute',
  Escape: 'pause',
};

export class InputManager {
  constructor() {
    this.held = new Set();
    this._prevHeld = new Set();
    this._justPressed = new Set();
    this._justReleased = new Set();
    this._pendingPress = new Set();
    this._pendingRelease = new Set();

    this.axisX = 0;
    this.down = false;
    this.jumpJustPressed = false;
    this.jumpJustReleased = false;
    this.downJustPressed = false;
    this.downJustReleased = false;
    this.reloadJustPressed = false;
    this.muteJustPressed = false;
    this.pauseJustPressed = false;

    this._onKeyDown = (e) => {
      const action = KEY_MAP[e.code];
      if (!action) return;
      if (['Space', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.code)) e.preventDefault();
      this.press(action);
    };
    this._onKeyUp = (e) => {
      const action = KEY_MAP[e.code];
      if (!action) return;
      this.release(action);
    };
    window.addEventListener('keydown', this._onKeyDown, { passive: false });
    window.addEventListener('keyup', this._onKeyUp);
    this._onBlur = () => this.reset();
    window.addEventListener('blur', this._onBlur);
    document.addEventListener('visibilitychange', this._onBlur);
  }

  // Clear every held key (window blur / tab switch can eat the keyup).
  reset() {
    this.held.clear();
    this._pendingPress.clear();
    this._pendingRelease.clear();
    this._justPressed.clear();
    this._justReleased.clear();
    this.jumpJustPressed = false;
    this.jumpJustReleased = false;
    this.downJustPressed = false;
    this.downJustReleased = false;
    this.reloadJustPressed = false;
    this.muteJustPressed = false;
    this.pauseJustPressed = false;
    this.axisX = 0;
    this.down = false;
  }

  press(action) {
    if (!this.held.has(action)) this._pendingPress.add(action);
    this.held.add(action);
  }
  release(action) {
    if (this.held.has(action)) this._pendingRelease.add(action);
    this.held.delete(action);
  }

  // Called once per fixed physics step.
  update() {
    this._justPressed = this._pendingPress;
    this._justReleased = this._pendingRelease;
    this._pendingPress = new Set();
    this._pendingRelease = new Set();

    const L = this.held.has('left');
    const R = this.held.has('right');
    this.axisX = (R ? 1 : 0) - (L ? 1 : 0);
    this.down = this.held.has('down');

    this.jumpJustPressed = this._justPressed.has('jump');
    this.jumpJustReleased = this._justReleased.has('jump');
    this.downJustPressed = this._justPressed.has('down');
    this.downJustReleased = this._justReleased.has('down');
    this.reloadJustPressed = this._justPressed.has('reload');
    this.muteJustPressed = this._justPressed.has('mute');
    this.pauseJustPressed = this._justPressed.has('pause');
  }

  destroy() {
    window.removeEventListener('keydown', this._onKeyDown);
    window.removeEventListener('keyup', this._onKeyUp);
    window.removeEventListener('blur', this._onBlur);
    document.removeEventListener('visibilitychange', this._onBlur);
  }
}
