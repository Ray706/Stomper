import { TILE, SCREEN_W, SCREEN_H } from './constants.js';

function drawSheetFrame(ctx, sheet, frameIndex, cx, cy, offsetY) {
  if (!sheet || !sheet.img) return;
  const { img, fw, fh } = sheet;
  ctx.drawImage(img, frameIndex * fw, 0, fw, fh, Math.round(cx - fw / 2), Math.round(cy - fh + offsetY), fw, fh);
}

function drawImgCentered(ctx, img, cx, cy, flipX = false, flipY = false) {
  if (!img) return;
  const w = img.naturalWidth, h = img.naturalHeight;
  ctx.save();
  ctx.translate(Math.round(cx), Math.round(cy));
  ctx.scale(flipX ? -1 : 1, flipY ? -1 : 1);
  ctx.drawImage(img, -w / 2, -h / 2, w, h);
  ctx.restore();
}

function drawTopLeft(ctx, img, x, y, flipH = false) {
  if (!img) return;
  const w = img.naturalWidth, h = img.naturalHeight;
  if (!flipH) { ctx.drawImage(img, Math.round(x), Math.round(y)); return; }
  ctx.save();
  ctx.translate(Math.round(x) + w, Math.round(y));
  ctx.scale(-1, 1);
  ctx.drawImage(img, 0, 0);
  ctx.restore();
}

export function renderLevel(ctx, level, assets, bgFrame) {
  ctx.imageSmoothingEnabled = false;
  ctx.save();
  ctx.translate(Math.round(level.shakeOffset.x), Math.round(level.shakeOffset.y));

  // background
  const bgImgs = [assets.img('assets/bg/back-animated1.png'), assets.img('assets/bg/back-animated2.png'), assets.img('assets/bg/back-animated3.png')];
  const bg = bgImgs[bgFrame % 3];
  if (bg) ctx.drawImage(bg, 0, 0, SCREEN_W, SCREEN_H);

  // tiles
  const tileset = assets.img('assets/tiles/tileset.png');
  const meta = level.tilesetMeta.tiles;
  for (const [key, tileId] of level.grid.tileAt) {
    const [x, y] = key.split(',').map(Number);
    const region = meta[tileId];
    if (!region || !tileset) continue;
    ctx.drawImage(tileset, region.x, region.y, region.w, region.h, x * TILE, y * TILE, TILE, TILE);
  }

  // props (background plants)
  for (const pr of level.data.props) {
    drawTopLeft(ctx, assets.img('assets/misc/plant.png'), pr.x, pr.y, pr.flip_h);
  }

  // slippery blocks
  for (const sl of level.slipperyBlocks) drawTopLeft(ctx, assets.img('assets/misc/slime-block.png'), sl.spriteX, sl.spriteY);

  // spikes (flat hazard)
  const spikesImg = assets.sheet('spikes');
  for (const s of level.spikes) {
    if (spikesImg && spikesImg.img) {
      ctx.save();
      if (s.flip) {
        // ceiling spike: hang from the top of the tile, points pointing down
        ctx.translate(Math.round(s.spriteX), Math.round(s.spriteY + spikesImg.fh));
        ctx.scale(1, -1);
        ctx.drawImage(spikesImg.img, spikesImg.fw, 0, spikesImg.fw, spikesImg.fh, 0, 0, spikesImg.fw, spikesImg.fh);
      } else {
        ctx.drawImage(spikesImg.img, spikesImg.fw, 0, spikesImg.fw, spikesImg.fh, Math.round(s.spriteX), Math.round(s.spriteY), spikesImg.fw, spikesImg.fh);
      }
      ctx.restore();
    }
  }

  // spikes blocks
  const headImg = assets.img('assets/misc/spike-block.png');
  for (const sb of level.spikesBlocks) {
    ctx.save();
    if (sb.flip) { ctx.translate(sb.spriteX, sb.spriteY + 16); ctx.scale(1, -1); ctx.drawImage(headImg, 0, 0); }
    else { ctx.drawImage(headImg, sb.spriteX, sb.spriteY); }
    ctx.restore();
    const spSheet = assets.sheet('spikes');
    const frame = sb.out ? 1 : 0;
    const dy = sb.flip ? 8 : -24;
    drawSheetHFrame(ctx, spSheet, frame, sb.pos.x, sb.pos.y + dy, sb.flip ? -0.5 : 0.5, sb.flip);
  }

  // shooting blocks
  const shootHead = assets.sheet('shootingHead');
  for (const sh of level.shootingBlocks) {
    drawSheetXFrame(ctx, shootHead, sh.frame, sh.pos.x, sh.pos.y - 8, sh.shootSpeed < 0);
  }
  for (const s of level.shots) {
    const f = assets.seq('shoot')[s.anim.frame];
    drawImgCentered(ctx, f, s.pos.x, s.pos.y, s.speed < 0);
  }

  // door
  if (level.door) {
    const seq = assets.seq(level.door.open ? 'doorActive' : 'doorOff');
    const img = seq[level.door.anim.frame % seq.length];
    drawImgCentered(ctx, img, level.door.pos.x, level.door.pos.y - 12);
  }

  // crates
  for (const c of level.crates) {
    if (c.dead) continue;
    drawTopLeft(ctx, assets.img('assets/misc/brick.png'), c.spriteX, c.spriteY);
  }
  for (const b of level.bricks) {
    ctx.save();
    ctx.translate(Math.round(b.pos.x), Math.round(b.pos.y));
    ctx.rotate(b.rotation);
    const img = assets.img('assets/misc/brick.png');
    if (img) ctx.drawImage(img, 0, 0, 10, 5, -5, -2.5, 10, 5);
    ctx.restore();
  }

  // boxes
  for (const b of level.boxes) drawImgCentered(ctx, assets.img('assets/misc/box.png'), b.pos.x, b.pos.y);

  // gems
  for (const g of level.gems) {
    const seq = assets.seq('gemSpin');
    const img = seq[g.anim.frame % seq.length];
    drawImgCentered(ctx, img, g.pos.x, g.pos.y);
  }

  // star
  if (level.star) {
    const seq = assets.seq('star');
    const img = seq[level.star.anim.frame % seq.length];
    drawImgCentered(ctx, img, level.star.pos.x, level.star.pos.y);
  }

  // enemies
  for (const en of level.enemies) {
    const key = en.type === 'walkingEnemy' ? (en.killed ? 'walkerWalk' : (en.stunt ? 'walkerStunt' : 'walkerWalk'))
      : (en.killed ? 'flyerFly' : (en.stunt ? 'flyerStunt' : 'flyerFly'));
    const seq = assets.seq(key);
    const img = seq[en.anim.frame % seq.length];
    const flip = en.facing < 0;
    ctx.save();
    ctx.translate(Math.round(en.pos.x), Math.round(en.pos.y - (en.type === 'walkingEnemy' ? 12 : 0)));
    if (en.killed) ctx.rotate(en.rotation);
    ctx.scale(flip ? -1 : 1, 1);
    if (img) ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
    ctx.restore();
  }

  // player
  drawPlayer(ctx, assets, level.player);

  // effects
  for (const ef of level.effects) {
    if (ef.kind === 'trace') {
      const img = assets.img('assets/fx/trace.png');
      if (img) {
        ctx.save();
        ctx.globalAlpha = Math.max(0, 1 - ef.t / ef.dur);
        drawImgCentered(ctx, img, ef.x, ef.y - 8);
        ctx.restore();
      }
    } else {
      drawSheetFrame(ctx, ef.sheet, ef.frameIndex(), ef.x, ef.y - ef.offsetY, 0);
    }
  }

  ctx.restore();
}

function drawSheetHFrame(ctx, sheet, frameIndex, cx, cy, dirY = 1, flipV = false) {
  if (!sheet || !sheet.img) return;
  const { img, fw, fh } = sheet;
  ctx.save();
  ctx.translate(Math.round(cx), Math.round(cy));
  if (flipV) ctx.scale(1, -1);
  ctx.drawImage(img, frameIndex * fw, 0, fw, fh, -fw / 2, dirY > 0 ? 0 : -fh, fw, fh);
  ctx.restore();
}

function drawSheetXFrame(ctx, sheet, frameIndex, cx, cy, flipX = false) {
  if (!sheet || !sheet.img) return;
  const { img, fw, fh } = sheet;
  ctx.save();
  ctx.translate(Math.round(cx), Math.round(cy));
  if (flipX) ctx.scale(-1, 1);
  ctx.drawImage(img, frameIndex * fw, 0, fw, fh, -fw / 2, 0, fw, fh);
  ctx.restore();
}

function drawPlayer(ctx, assets, p) {
  if (p.hidden) return;
  const frames = _playerFramesFor(assets, p.anim.name);
  if (!frames) return;
  const img = frames[p.anim.frame % frames.length];
  if (!img) return;
  ctx.save();
  ctx.translate(Math.round(p.pos.x), Math.round(p.pos.y + PLAYER_SPRITE_OFFSET_Y));
  ctx.scale(p.facing < 0 ? -1 : 1, 1);
  ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
  ctx.restore();
}
const PLAYER_SPRITE_OFFSET_Y = -11;

function _playerFramesFor(assets, name) {
  const map = {
    idle: 'playerIdle', run: 'playerRun', jump: 'playerJump', fall: 'playerFall',
    wall: 'playerWall', duck: 'playerDuck', duckCharged: 'playerDuckCharged', roll: 'playerRoll',
  };
  return assets.seq(map[name] || 'playerIdle');
}
