import { TILE, COLS, ROWS } from './constants.js';

// TileGrid: static level geometry (from the parsed Godot tilemap).
export class TileGrid {
  constructor(tiles, tilesetMeta) {
    this.solid = new Map(); // "x,y" -> {tileId, oneWay}
    this.tileAt = new Map(); // "x,y" -> tileId (for rendering, includes non-solid decoration)
    for (const [x, y, tileId] of tiles) {
      this.tileAt.set(`${x},${y}`, tileId);
      const isSolid = tilesetMeta.solid[tileId];
      if (isSolid) {
        this.solid.set(`${x},${y}`, { tileId, oneWay: !!tilesetMeta.oneway[tileId] });
      }
    }
  }

  cellSolid(cx, cy, { ignoreOneWay = false } = {}) {
    const s = this.solid.get(`${cx},${cy}`);
    if (!s) return false;
    if (s.oneWay && ignoreOneWay) return false;
    return true;
  }
}

// A dynamic rectangular solid (crate, box, spikes-block, etc.) that participates
// in tile-style collision alongside the static grid.
export class Solid {
  constructor(x, y, w, h, opts = {}) {
    this.x = x; this.y = y; this.w = w; this.h = h;
    this.oneWay = !!opts.oneWay;
    this.owner = opts.owner || null;
  }
  get left() { return this.x - this.w / 2; }
  get right() { return this.x + this.w / 2; }
  get top() { return this.y - this.h / 2; }
  get bottom() { return this.y + this.h / 2; }
}

function aabbOverlap(ax1, ay1, ax2, ay2, bx1, by1, bx2, by2) {
  return ax1 < bx2 && ax2 > bx1 && ay1 < by2 && ay2 > by1;
}

// Moves an axis-aligned box (center x/y, half-extents hw/hh) through the tile grid
// plus any extra dynamic solids, resolving axis-by-axis like a simple platformer
// kinematic body. Returns collision flags.
export function moveAABB(grid, extraSolids, pos, vel, hw, hh, dt, opts = {}) {
  const { fallingThroughOneWay = false, prevBottom = null } = opts;
  const result = { onFloor: false, onCeiling: false, onWallLeft: false, onWallRight: false };

  const collideTileRect = (x1, y1, x2, y2, ignoreOneWayFromBelow) => {
    const minCx = Math.floor(x1 / TILE);
    const maxCx = Math.floor((x2 - 0.01) / TILE);
    const minCy = Math.floor(y1 / TILE);
    const maxCy = Math.floor((y2 - 0.01) / TILE);
    const hits = [];
    for (let cy = minCy; cy <= maxCy; cy++) {
      for (let cx = minCx; cx <= maxCx; cx++) {
        if (grid.cellSolid(cx, cy)) {
          const s = grid.solid.get(`${cx},${cy}`);
          hits.push({ left: cx * TILE, right: cx * TILE + TILE, top: cy * TILE, bottom: cy * TILE + TILE, oneWay: s.oneWay });
        }
      }
    }
    for (const sol of extraSolids) {
      if (aabbOverlap(x1, y1, x2, y2, sol.left, sol.top, sol.right, sol.bottom)) {
        hits.push({ left: sol.left, right: sol.right, top: sol.top, bottom: sol.bottom, oneWay: sol.oneWay });
      }
    }
    return hits;
  };

  // --- Horizontal pass ---
  pos.x += vel.x * dt;
  {
    const x1 = pos.x - hw, x2 = pos.x + hw, y1 = pos.y - hh, y2 = pos.y + hh;
    const hits = collideTileRect(x1, y1, x2, y2).filter(h => !h.oneWay);
    for (const h of hits) {
      // Resolve against the shallowest obstacle in the travel direction so a
      // fast-moving body that penetrates several tiles in one step stops at the
      // first one instead of sinking past all of them.
      if (vel.x > 0) pos.x = Math.min(pos.x, h.left - hw);
      else if (vel.x < 0) pos.x = Math.max(pos.x, h.right + hw);
    }
    if (hits.length) {
      if (vel.x > 0) result.onWallRight = true;
      else if (vel.x < 0) result.onWallLeft = true;
      vel.x = 0;
    }
  }

  // --- Vertical pass ---
  pos.y += vel.y * dt;
  {
    const x1 = pos.x - hw, x2 = pos.x + hw;
    const prevY2 = prevBottom !== null ? prevBottom : (pos.y - vel.y * dt + hh);
    let hits = collideTileRect(x1, pos.y - hh, x2, pos.y + hh);
    hits = hits.filter(h => {
      if (!h.oneWay) return true;
      // one-way platforms only block when moving down and previously above the platform
      return vel.y >= 0 && prevY2 <= h.top + 0.5;
    });
    for (const h of hits) {
      if (vel.y > 0) pos.y = Math.min(pos.y, h.top - hh);
      else if (vel.y < 0) pos.y = Math.max(pos.y, h.bottom + hh);
    }
    if (hits.length) {
      if (vel.y > 0) result.onFloor = true;
      else if (vel.y < 0) result.onCeiling = true;
      vel.y = 0;
    }
  }

  return result;
}

export function screenWrap(pos, margin = 4) {
  if (pos.x > COLS * TILE) pos.x = -margin;
  else if (pos.x < -margin) pos.x = COLS * TILE;
  if (pos.y > ROWS * TILE - 32) pos.y = -margin;
  else if (pos.y < -margin) pos.y = ROWS * TILE;
}
