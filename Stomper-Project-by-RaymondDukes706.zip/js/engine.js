import { STEP, SCREEN_W, SCREEN_H } from './constants.js';
import { Level } from './level.js';
import { renderLevel } from './render.js';
import { InputManager } from './input.js';
import { AudioManager } from './audio.js';
import { Assets } from './assets.js';

const TOTAL_LEVELS = 15;

export class Engine {
  constructor(canvas, levelsData, tilesetMeta) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.levelsData = levelsData;
    this.tilesetMeta = tilesetMeta;
    this.assets = new Assets();
    this.audio = new AudioManager();
    this.input = new InputManager();

    this.mode = 'boot'; // boot | title | playing | transition | gameover
    this.scale = 3;
    this.levelIndex = 1;
    this.level = null;
    this.bgFrame = 0;
    this._bgAccum = 0;
    this._acc = 0;
    this._raf = null;
    this._transitionT = 0;
    this._transitionDir = 0; // 1 = fading out to next, -1 fading in
    this._pendingLevel = null;

    this.stats = { time: 0, stars: 0 };
    this.listeners = { gems: null, mode: null, complete: null };

    this._loop = this._loop.bind(this);
  }

  async boot(onProgress) {
    await this.assets.loadAll(onProgress);
    this.audio.init(this.assets);
    this.mode = 'title';
    this._emitMode();
    this._raf = requestAnimationFrame(this._loop);
  }

  _emitMode() { if (this.listeners.mode) this.listeners.mode(this.mode); }
  _emitGems(a, b) { if (this.listeners.gems) this.listeners.gems(a, b); }

  startGame() {
    this.stats = { time: 0, stars: 0 };
    this.levelIndex = 1;
    this._customData = null;
    this._loadLevel(1);
    this.mode = 'playing';
    this.audio.playBgm();
    this._emitMode();
  }

  goToTitle() {
    this.mode = 'title';
    this._customData = null;
    this.audio.stopBgm();
    this._emitMode();
  }

  _loadLevelData(data) {
    this.level = new Level(data, this.tilesetMeta, this.assets, this.audio, {
      onComplete: () => this._onLevelComplete(),
      onRestartRequest: () => this.restartLevel(),
      onGemsChanged: (a, b) => this._emitGems(a, b),
    });
    this._emitGems(0, data.gems_total);
  }

  _loadLevel(idx) { this._loadLevelData(this.levelsData[idx]); }

  restartLevel() {
    if (this._customData) this._loadLevelData(this._customData);
    else this._loadLevel(this.levelIndex);
  }

  loadLevel(idx) {
    this.levelIndex = idx;
    this._customData = null;
    this._loadLevel(idx);
    this.mode = 'playing';
    this.audio.playBgm();
    this._emitMode();
  }

  // Load an arbitrary level object (from the editor) for playtesting.
  testLevel(data) {
    this._customData = data;
    this._loadLevelData(data);
    this.mode = 'playing';
    this.audio.playBgm();
    this._emitMode();
  }

  _onLevelComplete() {
    this.stats.stars = this.level.starsTaken + (this._priorStars || 0);
    this._priorStars = this.stats.stars;
    if (this._customData) {
      // Finished a custom test level: return to the title screen.
      this._customData = null;
      this.mode = 'title';
      this.audio.stopBgm();
      this._emitMode();
      return;
    }
    this.mode = 'transition';
    this._transitionT = 0;
    this._emitMode();
  }

  _advanceLevel() {
    this.levelIndex++;
    if (this.levelIndex > TOTAL_LEVELS) {
      this.mode = 'gameover';
      this.audio.stopBgm();
      this._emitMode();
      return;
    }
    this._loadLevel(this.levelIndex);
    this.mode = 'playing';
    this._emitMode();
  }

  destroy() {
    if (this._raf) cancelAnimationFrame(this._raf);
    this.input.destroy();
  }

  setCanvasScale(scale) {
    this.scale = scale;
    this.canvas.width = Math.round(SCREEN_W * scale);
    this.canvas.height = Math.round(SCREEN_H * scale);
  }

  _loop(ts) {
    this._raf = requestAnimationFrame(this._loop);
    if (!this._last) this._last = ts;
    let frameDt = (ts - this._last) / 1000;
    this._last = ts;
    if (frameDt > 0.25) frameDt = 0.25; // clamp huge pauses (tab backgrounded)

    this._acc += frameDt;
    while (this._acc >= STEP) {
      this.input.update();
      this._fixedUpdate(STEP);
      this._acc -= STEP;
    }
    this._render();
  }

  _fixedUpdate(dt) {
    this._bgAccum += dt;
    if (this._bgAccum >= 1 / 12) { this._bgAccum = 0; this.bgFrame = (this.bgFrame + 1) % 3; }

    if (this.mode === 'playing' && this.level) {
      this.level.update(dt, this.input);
      this.stats.time += dt;
    } else if (this.mode === 'transition') {
      this._transitionT += dt;
      if (this._transitionT > 0.5) this._advanceLevel();
    }
  }

  _render() {
    const ctx = this.ctx;
    ctx.save();
    ctx.setTransform(this.scale, 0, 0, this.scale, 0, 0);
    ctx.clearRect(0, 0, SCREEN_W, SCREEN_H);
    ctx.fillStyle = '#0b0f1a';
    ctx.fillRect(0, 0, SCREEN_W, SCREEN_H);
    if ((this.mode === 'playing' || this.mode === 'transition') && this.level) {
      renderLevel(ctx, this.level, this.assets, this.bgFrame);
      if (this.mode === 'transition') {
        ctx.fillStyle = `rgba(0,0,0,${Math.min(1, this._transitionT / 0.5)})`;
        ctx.fillRect(0, 0, SCREEN_W, SCREEN_H);
      }
    }
    ctx.restore();
  }
}
