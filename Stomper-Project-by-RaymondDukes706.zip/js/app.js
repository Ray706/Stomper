import { h, render } from 'https://esm.sh/preact@10.19.6';
import { useEffect, useRef, useState, useCallback } from 'https://esm.sh/preact@10.19.6/hooks';
import htm from 'https://esm.sh/htm@3.1.1';
import { Engine } from './engine.js';
import { LevelEditor, isEditorKeyboardLocked } from './editor.js';
import * as levelModel from './editor-level.js';

const html = htm.bind(h);

function fmtTime(t) {
  const s = Math.floor(t % 60);
  const m = Math.floor(t / 60);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function useEngine(levelsData, tileset) {
  const [engine] = useState(() => null);
  const ref = useRef(null);
  const canvasRef = useRef(null);
  const [mode, setMode] = useState('boot');
  const [progress, setProgress] = useState(0);
  const [gems, setGems] = useState({ taken: 0, total: 0 });
  const [levelIndex, setLevelIndex] = useState(1);
  const [stats, setStats] = useState({ time: 0, stars: 0 });

  useEffect(() => {
    const eng = new Engine(canvasRef.current, levelsData, tileset);
    ref.current = eng;
    eng.listeners.mode = (m) => { setMode(m); setLevelIndex(eng.levelIndex); };
    eng.listeners.gems = (a, b) => setGems({ taken: a, total: b });

    const resize = () => {
      const dpr = Math.min(3, window.devicePixelRatio || 1);
      const target = Math.max(2, Math.min(4, Math.round(2 * dpr)));
      eng.setCanvasScale(target);
    };
    resize();
    window.addEventListener('resize', resize);

    eng.boot((done, total) => setProgress(done / total));

    const statTick = setInterval(() => {
      if (ref.current) setStats({ time: ref.current.stats.time, stars: ref.current.stats.stars });
    }, 200);

    return () => { window.removeEventListener('resize', resize); clearInterval(statTick); eng.destroy(); };
  }, []);

  return { engineRef: ref, canvasRef, mode, progress, gems, levelIndex, stats };
}

function TouchButton({ label, className, action, onDown, onUp, children }) {
  const handlers = {
    onPointerDown: (e) => {
      e.preventDefault();
      try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) {}
      onDown(e);
    },
    onPointerUp: (e) => { e.preventDefault(); onUp(e); },
    onPointerCancel: (e) => { onUp(e); },
    onLostPointerCapture: (e) => { onUp(e); },
    onContextMenu: (e) => e.preventDefault(),
  };
  return html`<button class=${className} aria-label=${label} ...${handlers}>${children}</button>`;
}

function TouchControls({ input }) {
  // pointerId -> Set of actions currently held by that pointer. Tracking the
  // mapping here (instead of per-button) means a release that never reaches the
  // button — lost pointer capture, a finger sliding off, or an unmount — can be
  // caught by the window-level handlers below instead of leaving the player stuck.
  const active = useRef(new Map());
  const inputRef = useRef(input);
  inputRef.current = input;

  const handleDown = useCallback((e, action) => {
    let set = active.current.get(e.pointerId);
    if (!set) { set = new Set(); active.current.set(e.pointerId, set); }
    set.add(action);
    inputRef.current.press(action);
  }, []);

  const handleUp = useCallback((e) => {
    const set = active.current.get(e.pointerId);
    if (!set) return;
    active.current.delete(e.pointerId);
    for (const action of set) {
      let stillHeld = false;
      for (const other of active.current.values()) {
        if (other.has(action)) { stillHeld = true; break; }
      }
      if (!stillHeld) inputRef.current.release(action);
    }
  }, []);

  useEffect(() => {
    const onUpAny = (e) => { if (active.current.has(e.pointerId)) handleUp(e); };
    const onTouchEnd = (e) => {
      // Failsafe for devices that drop pointerup/pointercancel: if every finger
      // is off the screen, release anything still marked active so the player
      // can never be left running in one direction.
      if (e.touches.length === 0 && active.current.size > 0) {
        for (const set of active.current.values()) for (const a of set) inputRef.current.release(a);
        active.current.clear();
      }
    };
    const onBlur = () => {
      for (const set of active.current.values()) for (const a of set) inputRef.current.release(a);
      active.current.clear();
    };
    window.addEventListener('pointerup', onUpAny);
    window.addEventListener('pointercancel', onUpAny);
    window.addEventListener('lostpointercapture', onUpAny);
    window.addEventListener('touchend', onTouchEnd);
    window.addEventListener('touchcancel', onTouchEnd);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('pointerup', onUpAny);
      window.removeEventListener('pointercancel', onUpAny);
      window.removeEventListener('lostpointercapture', onUpAny);
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('touchcancel', onTouchEnd);
      window.removeEventListener('blur', onBlur);
      // Unmounts during pauses/level transitions: if a finger is still down on a
      // button, no pointerup will ever reach it, so release every action here to
      // avoid the player "sticking" into the next level.
      for (const set of active.current.values()) for (const a of set) inputRef.current.release(a);
      active.current.clear();
      inputRef.current.release('left');
      inputRef.current.release('right');
      inputRef.current.release('down');
      inputRef.current.release('jump');
    };
  }, [handleUp]);

  return html`
    <div class="touch-controls" aria-hidden="false">
      <div class="dpad">
        <${TouchButton} label="Left" className="btn btn-dpad btn-left" onDown=${(e) => handleDown(e, 'left')} onUp=${handleUp}>◀<//>
        <${TouchButton} label="Down / Duck" className="btn btn-dpad btn-down" onDown=${(e) => handleDown(e, 'down')} onUp=${handleUp}>▼<//>
        <${TouchButton} label="Right" className="btn btn-dpad btn-right" onDown=${(e) => handleDown(e, 'right')} onUp=${handleUp}>▶<//>
      </div>
      <div class="action-buttons">
        <${TouchButton} label="Jump" className="btn btn-action btn-jump" onDown=${(e) => handleDown(e, 'jump')} onUp=${handleUp}>JUMP<//>
      </div>
    </div>
  `;
}

function HUD({ gems, levelIndex, stats, muted, onMute, onPause }) {
  const filled = Math.min(gems.taken, gems.total);
  const slots = [];
  for (let i = 0; i < gems.total; i++) slots.push(i < filled ? 'filled' : 'empty');
  return html`
    <div class="hud">
      <div class="hud-left">
        <div class="hud-row">
          <span class="hud-label">GEMS</span>
          <div class="gem-meter">
            ${slots.map((s, i) => html`<div class="gem-slot gem-${s}" key=${i}></div>`)}
          </div>
        </div>
        <div class="hud-row">
          <span class="hud-label">TIME</span>
          <span class="hud-value">${fmtTime(stats.time)}</span>
        </div>
      </div>
      <div class="hud-center">LEVEL ${levelIndex} / 15</div>
      <div class="hud-right">
        <div class="hud-level">L${levelIndex}</div>
        <button class="icon-btn" onPointerDown=${onMute} title="Mute (M)">${muted ? '🔇' : '🔊'}</button>
        <button class="icon-btn" onPointerDown=${onPause} title="Pause (Esc)">⏸</button>
      </div>
    </div>
  `;
}

function TitleScreen({ onPlay, onAbout, onEdit }) {
  const [sel, setSel] = useState(0);
  useEffect(() => {
    const onKey = (e) => {
      if (isEditorKeyboardLocked()) return;
      if (e.code === 'ArrowUp' || e.code === 'ArrowDown') setSel(s => (s + 1) % 3);
      if (e.code === 'Enter' || e.code === 'Space') (sel === 0 ? onPlay : sel === 1 ? onAbout : onEdit)();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [sel, onPlay, onAbout, onEdit]);
  return html`
    <div class="screen title-screen">
      <img class="title-img" src="assets/ui/title.png" alt="Stomper" />
      <div class="menu">
        <button class="menu-item ${sel === 0 ? 'sel' : ''}" onPointerDown=${onPlay} onMouseEnter=${() => setSel(0)}>▶ PLAY</button>
        <button class="menu-item ${sel === 1 ? 'sel' : ''}" onPointerDown=${onEdit} onMouseEnter=${() => setSel(1)}>🛠 EDITOR</button>
        <button class="menu-item ${sel === 2 ? 'sel' : ''}" onPointerDown=${onAbout} onMouseEnter=${() => setSel(2)}>ⓘ ABOUT</button>
      </div>
      <div class="title-hint">Arrow keys / WASD to move · Space to jump · Down to duck<br/>
        Double-tap a direction to dash-roll · Hold Down then Jump to blast<br/>
        Touch controls work on mobile · R to restart level</div>
    </div>
  `;
}

function AboutScreen({ onBack }) {
  useEffect(() => {
    const onKey = (e) => { if (e.code === 'Enter' || e.code === 'Escape') onBack(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onBack]);
  return html`
    <div class="screen about-screen">
      <h2>About</h2>
      <p>Stomper is a short gem-hunting platformer.<br/>Run, roll-dash, wall-jump, ground-pound, and duck-charge your way through 15 rooms.</p>
      <p class="small">Original Godot game & art by Ansimuz, converted to a no-build Preact + Canvas web build.</p>
      <button class="menu-item sel" onPointerDown=${onBack}>◀ BACK</button>
    </div>
  `;
}

function GameOverScreen({ stats, onReplay, onTitle }) {
  return html`
    <div class="screen gameover-screen">
      <h1>THANKS FOR PLAYING</h1>
      <img class="star-icon" src="assets/star/zaphire1.png" alt="" />
      <p>TOOK YOU TO COMPLETE: ${fmtTime(stats.time)}</p>
      <p>ZAPHIRE x ${stats.stars}</p>
      <div class="menu">
        <button class="menu-item sel" onPointerDown=${onReplay}>▶ PLAY AGAIN</button>
        <button class="menu-item" onPointerDown=${onTitle}>◀ TITLE</button>
      </div>
    </div>
  `;
}

function PauseOverlay({ onResume, onRestart, onTitle, onEdit, currentLevel, onSelectLevel }) {
  const levels = [];
  for (let i = 1; i <= 15; i++) levels.push(i);
  return html`
    <div class="screen pause-screen">
      <h2>PAUSED</h2>
      <div class="menu">
        <button class="menu-item sel" onPointerDown=${onResume}>▶ RESUME</button>
        <button class="menu-item" onPointerDown=${onRestart}>⟲ RESTART LEVEL</button>
        <button class="menu-item" onPointerDown=${onEdit}>🛠 LEVEL EDITOR</button>
        <button class="menu-item" onPointerDown=${onTitle}>◀ TITLE</button>
      </div>
      <div class="level-select">
        <span class="level-select-label">JUMP TO LEVEL</span>
        <div class="level-grid">
          ${levels.map(i => html`
            <button class="level-btn ${i === currentLevel ? 'sel' : ''}" onPointerDown=${() => onSelectLevel(i)}>${i}</button>
          `)}
        </div>
      </div>
    </div>
  `;
}

function LoadingScreen({ progress }) {
  return html`
    <div class="screen loading-screen">
      <img class="title-img" src="assets/ui/title.png" alt="Stomper" />
      <div class="progress-track"><div class="progress-fill" style=${{ width: `${Math.round(progress * 100)}%` }}></div></div>
      <p class="small">Loading assets…</p>
    </div>
  `;
}

function App({ levelsData, tileset }) {
  const { engineRef, canvasRef, mode, progress, gems, levelIndex, stats } = useEngine(levelsData, tileset);
  const [paused, setPaused] = useState(false);
  const [muted, setMuted] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editorDraft, setEditorDraft] = useState(null);

  const withInput = useCallback((fn) => () => { if (engineRef.current) fn(engineRef.current); }, [engineRef]);

  const openEditor = () => {
    const engine = engineRef.current;
    if (!engine) return;
    engine.audio.unlock();
    // Start from the stored draft if one exists, otherwise copy the current level.
    if (!editorDraft) {
      const src = engine.levelsData[engine.levelIndex] || engine.levelsData['1'];
      setEditorDraft(levelModel.parseLevel(levelModel.deepCopy(src)));
    }
    setPaused(false);
    setEditorOpen(true);
  };
  const closeEditor = () => setEditorOpen(false);
  const commitEditor = (draft) => setEditorDraft(levelModel.deepCopy(draft));
  const testEditor = (draft) => {
    setEditorDraft(levelModel.deepCopy(draft));
    setEditorOpen(false);
    engineRef.current?.audio.unlock();
    engineRef.current?.testLevel(levelModel.serialize(draft));
  };

  useEffect(() => {
    const onKey = (e) => {
      if (e.code === 'Escape' && mode === 'playing') setPaused(p => !p);
      if (e.code === 'KeyM') setMuted(m => { engineRef.current?.audio.setEnabled(m); return !m; });
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [mode]);

  const play = () => {
    const engine = engineRef.current;
    if (engine) { engine.audio.unlock(); engine.startGame(); }
    setPaused(false);
  };
  const toTitle = () => { setPaused(false); engineRef.current?.goToTitle(); };
  const restart = () => { setPaused(false); engineRef.current?.restartLevel(); };
  const selectLevel = (n) => { setPaused(false); engineRef.current?.loadLevel(n); };

  return html`
    <div class="app-root">
      <div class="game-frame">
        <canvas ref=${canvasRef} class="game-canvas"></canvas>
        ${mode === 'boot' && html`<${LoadingScreen} progress=${progress} />`}
        ${mode === 'title' && html`<${TitleScreen} onPlay=${play} onAbout=${() => setPaused('about')} onEdit=${openEditor} />`}
        ${paused === 'about' && html`<${AboutScreen} onBack=${() => setPaused(false)} />`}
        ${mode === 'gameover' && html`<${GameOverScreen} stats=${stats} onReplay=${play} onTitle=${toTitle} />`}
        ${(mode === 'playing' || mode === 'transition') && html`
          <${HUD} gems=${gems} levelIndex=${levelIndex} stats=${stats} muted=${muted}
            onMute=${() => setMuted(m => { engineRef.current?.audio.setEnabled(m); return !m; })}
            onPause=${() => setPaused(true)} />
        `}
        ${paused === true && html`<${PauseOverlay} onResume=${() => setPaused(false)} onRestart=${restart} onTitle=${toTitle} onEdit=${openEditor} currentLevel=${levelIndex} onSelectLevel=${selectLevel} />`}
      </div>
      ${editorOpen && engineRef.current && html`<${LevelEditor} initialDraft=${editorDraft} assets=${engineRef.current.assets} tilesetMeta=${tileset} onClose=${(d) => { commitEditor(d); closeEditor(); }} onTest=${testEditor} />`}
      ${(mode === 'playing' && !paused && !editorOpen) && engineRef.current && html`<${TouchControls} input=${engineRef.current.input} />`}
    </div>
  `;
}

async function main() {
  const [levelsData, tileset] = await Promise.all([
    fetch('data/levels.json').then(r => r.json()),
    fetch('data/tileset.json').then(r => r.json()),
  ]);
  render(html`<${App} levelsData=${levelsData} tileset=${tileset} />`, document.getElementById('root'));
}

main();
